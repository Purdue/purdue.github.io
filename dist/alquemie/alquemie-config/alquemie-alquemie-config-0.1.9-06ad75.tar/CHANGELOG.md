# Changelog

Relevant changes to the Alquemie Config project are documented below as a resource for users.
## [0.1.9] - 2020-03-29
### Added
- Force Non-Production emails to route to Purdue Digital Marketing Team

## [0.1.8] - 2020-03-20
### Added
- Plugin Control for Pantheon Environments

### Changed
- New Holiday Messages

## [0.1.8] - 2019-06-07
### Changed
- New Holiday Messages
- Force IE to Edge

## [0.1.2] - 2018-10-19
### Changed
- Context Fixes

## [0.1.1] - 2018-10-19
### Added
- Admin Settings Page

### Changed
- Functionality can be disabled based on setting
- Messages can be customized 

## [0.1.0] - 2018-10-01
### Added
- Remove Author URLs
- Change "Howdy" to "Logged in as" 
- Delay posts from RSS by 12 hours
- Remove "Generator" header
- Customized Dashboard Footer text

### Changed
- N/A
