# Purdue Blocks Plugin

Adds Purdue University branded Gutenberg blocks to the editor

## Changelog

Relevant changes are documented below.

### [1.1.0] - 2020-05-13
#### Added
- Initial public release

### [1.2.0] - 2020-05-18
#### Added
- Add CTA Hero block
- Add Title Hero block
