# Bulma Blocks Plugin

Adds Gutenberg blocks based on Bulma.io CSS framework

## Changelog

Relevant changes are documented below.

### [1.1.0] - 2020-05-13
#### Added
- Initial public release
