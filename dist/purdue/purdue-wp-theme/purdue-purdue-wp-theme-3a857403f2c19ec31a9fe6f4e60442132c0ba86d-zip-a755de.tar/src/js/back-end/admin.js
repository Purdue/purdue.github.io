//Hide/show footer layout options






