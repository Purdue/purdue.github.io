# purdue-wp-theme
WordPress theme based on Purdue University digital brand standards
