<?php
/**
 * WP File Download Addon
 *
 * @package WP File Download
 * @author  Joomunited
 * @version 1.0
 */

use Joomunited\WPFramework\v1_0_5\Application;
use Joomunited\WPFramework\v1_0_5\Utilities;
use Joomunited\WPFramework\v1_0_5\Model;
use Joomunited\WPFramework\v1_0_5\Form;

defined('ABSPATH') || die();


/**
 * Config page
 */
// New ux
add_filter('wpfd_admin_ui_configuration_menu_get_items', function ($items) {
    $items['cloud-config'] = array(
        esc_html__('Cloud connection', 'wpfdAddon'),
        '',
        51,
        plugins_url('assets/images/icon-cloud-config.svg', __FILE__)
    );
    $items['social-locker'] = array(
        esc_html__('Social locker', 'wpfdAddon'),
        '',
        52,
        plugins_url('assets/images/icon-social-locker.svg', __FILE__)
    );
    return $items;
});

// Add cloud config content
add_action('wpfd_admin_ui_configuration_content', function () {
    $name = 'cloud-config';
//    $html = '<h2>' . esc_html__('Cloud connection', 'wpfdAddon') . '</h2>';
    $html = '';
    ob_start();
    displayGoogleDriveConfigurationContent();
    $googleHtml = ob_get_contents();
    ob_end_clean();

    ob_start();
    displayDropboxConfigurationContent();
    $dropboxHtml = ob_get_contents();
    ob_end_clean();

    ob_start();
    displayOneDriveConfigurationContent();
    $onedriveHtml = ob_get_contents();
    ob_end_clean();
    $tabs = array(
        'google_drive' => $googleHtml,
        'dropbox' => $dropboxHtml,
        'onedrive_personal' => $onedriveHtml,
    );
    $tabs = apply_filters('wpfda_after_cloud_configuration_content', $tabs);
    $html .= wpfd_admin_ui_configuration_build_tabs($tabs);
//    ob_start();
//    displayGoogleDriveConfigurationContent();
//    displayDropboxConfigurationContent();
//    displayOneDriveConfigurationContent();
//    do_action('wpfda_after_cloud_configuration_content');
//    $html .= ob_get_contents();
//    ob_end_clean();

    // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- print html content
    echo wpfd_admin_ui_configuration_build_content($name, $html);

    // Social locker
    $name = 'social-locker';
    $html = '<h2>' . esc_html__('Social locker', 'wpfdAddon') . '</h2>';
    ob_start();
    wpfd_addon_display_social_content();
    $html .= ob_get_contents();
    ob_end_clean();

    // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- print html content
    echo wpfd_admin_ui_configuration_build_content($name, $html);
}, 20);

// TODO: DELETE THIS LATE
add_action('wpfd_addon_configuration_tab', 'wpfd_addon_display_cloud_configuration_tab');
add_action('wpfd_addon_configuration_content', 'displayGoogleDriveConfigurationContent', 10);
add_action('wpfd_addon_configuration_content', 'displayDropboxConfigurationContent', 20);
add_action('wpfd_addon_configuration_content', 'displayOneDriveConfigurationContent', 30);

add_action('wpfdAddonAfterTap', 'wpfd_addon_display_social_tab');
add_action('wpfdAddonAfterContent', 'wpfd_addon_display_social_content');
// END DELETE THIS

/**
 * Cloud global hooks
 */

add_action('admin_menu', 'wpfdAddon_menu', 100);
add_action('admin_init', 'wpfdAddonInit');
add_filter('wpfdAddonCategoryFrom', 'wpfdAddonCategoryFrom', 10, 1);
add_filter('wpfdAddon_check_cloud_exist', 'check_cloud_exist');

/**
 * Google Drive hooks
 */
add_action('wpfd_addon_dropdown', 'displayDropDownCreateCloud', 10);

add_action('wp_ajax_googleSync', 'wpfdAddonGoogleSync_callback');
add_action('wp_ajax_nopriv_googleSync', 'wpfdAddonGoogleSync_callback');
// Push notifications ajax
add_action('wp_ajax_googleWatchChanges', 'wpfdAddonGoogleWatchChanges_callback');
add_action('wp_ajax_nopriv_googleWatchChanges', 'wpfdAddonGoogleWatchChanges_callback');

add_action('wp_ajax_googlePushListener', 'wpfdAddonGooglePushListener_callback');
add_action('wp_ajax_nopriv_googlePushListener', 'wpfdAddonGooglePushListener_callback');

add_action('wp_ajax_wpfdAddonDeleteCategory', 'wpfdAddonDeleteCategory_callback');
add_action('wp_ajax_wpfdAddonAddCategory', 'wpfdAddonAddCategory_callBack');

add_action('wpfd_addon_sync_buttons', 'displayButtonSync', 10);
add_action('wpfd_addon_auto_sync', 'wpfdAddonGoogleDriveSync', 10);

add_filter('wpfdAddonShowCategoryCloud', 'displayCategoriesGoogleCloud', 10, 1);

add_filter('wpfdAddonGoogleDriveUpload', 'wpfdAddonGoogleDriveUpload', 10, 2);
add_filter('wpfdAddonGoogleDriveChangeOrder', 'wpfdAddonGoogleDriveChangeOrder', 10, 1);
add_filter('wpfdAddonDownloadGoogleDriveInfo', 'wpfdAddonDownloadGoogleDriveInfo', 10, 2);
add_filter('wpfdAddonDownloadGoogleDriveData', 'wpfdAddonDownloadGoogleDriveData', 10, 2);

add_action('wpfdAddonCopyGoogleGoogle', 'wpfdAddonCopyGoogleGoogle', 10, 2);
add_action('wpfdAddonMoveGoogleGoogle', 'wpfdAddonMoveGoogleGoogle', 10, 2);

add_filter('wpfdAddonGetListVersions', 'wpfdAddonGetListVersions', 10, 2);
add_filter('wpfdAddonUploadVersion', 'wpfdAddonUploadVersion', 10, 2);
add_filter('wpfdAddonDeleteVersion', 'wpfdAddonDeleteVersion', 10, 3);
add_filter('wpfd_level_category', 'wpfdAddonLevelCategory', 9, 1);

/**
 * Dropbox hooks
 */
add_action('admin_menu', 'wpfdDropboxAddon_menu'); // Not in use

add_action('wpfd_addon_dropdown', 'displayDropDownCreateDropbox', 20);

add_action('wp_ajax_dropboxSync', 'wpfdAddonDropboxSync_callback');
add_action('wp_ajax_nopriv_dropboxSync', 'wpfdAddonDropboxSync_callback');
add_action('wp_ajax_wpfdAddonDeleteDropboxCategory', 'wpfdAddonDeleteDropboxCategory_callback');
add_action('wp_ajax_wpfdAddonAddDropCategory', 'wpfdAddonAddDropCategory_callBack');

add_action('wpfd_addon_sync_buttons', 'displayButtonSyncDropbox', 20);
add_action('wpfd_addon_auto_sync', 'wpfdAddonDropboxAutoSync', 20);

add_filter('wpfdAddonShowCategoryDropbox', 'displayCategoriesDropbox', 10, 1);

add_filter('wpfdAddonDropboxUpload', 'wpfdAddonDropboxUpload', 10, 2);
add_filter('wpfdAddonDropboxChangeOrder', 'wpfdAddonDropboxChangeOrder', 10, 2);
add_filter('wpfdAddonDownloadDropboxInfo', 'wpfdAddonDownloadDropboxInfo', 10, 1);

add_action('wpfdAddonCopyDropboxDropbox', 'wpfdAddonCopyDropboxDropbox', 10, 2);
add_action('wpfdAddonMoveDropboxDropbox', 'wpfdAddonMoveDropboxDropbox', 10, 2);

add_filter('wpfdAddonUploadDropboxVersion', 'wpfdAddonUploadDropboxVersion', 10, 2);
add_filter('wpfdAddonDropboxVersionInfo', 'wpfdAddonDropboxVersionInfo', 10, 2);
add_filter('wpfd_level_category_dropbox', 'wpfdAddonLevelCategoryDropbox', 9, 1);

/**
 * Onedrive hooks
 */

add_action('admin_menu', 'wpfdOneDriveAddon_menu');  // Not in use

add_action('wpfd_addon_dropdown', 'displayDropDownCreateOneDrive', 30);

add_action('wp_ajax_wpfdAddonAddOneDriveCategory', 'wpfdAddonAddOneDriveCategory_callBack');
add_action('wp_ajax_wpfdAddonDeleteOneDriveCategory', 'wpfdAddonDeleteOneDriveCategory_callback');
add_action('wp_ajax_onedriveSync', 'wpfdAddonOneDriveSync_callback');
add_action('wp_ajax_nopriv_onedriveSync', 'wpfdAddonOneDriveSync_callback');

add_action('wpfd_addon_sync_buttons', 'displayOneDriveButtonSync', 30);
add_action('wpfd_addon_auto_sync', 'wpfdAddonOneDriveSync', 30);

add_filter('wpfdAddonShowCategoryOneDrive', 'displayCategoriesOneDrive', 10, 1);

add_filter('wpfdAddonOneDriveUpload', 'wpfdAddonOneDriveUpload', 10, 2);
add_filter('wpfdAddonOneDriveChangeOrder', 'wpfdAddonOneDriveChangeOrder', 10, 1);
add_filter('wpfdAddonDownloadOneDriveInfo', 'wpfdAddonDownloadOneDriveInfo', 10, 1);

add_action('wpfdAddonCopyOneDrive', 'wpfdAddonCopyOneDrive', 10, 2);
add_action('wpfdAddonMoveFileOneDriver', 'wpfdAddonMoveFileOneDriver', 10, 2);

add_filter('wpfdAddonUploadOneDriveVersion', 'wpfdAddonUploadOneDriveVersion', 10, 2);
add_filter('wpfd_level_category_onedrive', 'wpfdAddonLevelCategoryOneDrive', 9, 1);
add_action('admin_init', function () {
    $state = Utilities::getInput('state', 'GET', 'string');
    if ($state === 'wpfd-onedrive') {
        $onedrive = new WpfdAddonOneDrive();
        $onedrive->authenticate();
    }
});
// Improve Hooks
add_filter('wpfd_addon_restore_version', 'wpfd_addon_restore_version', 10, 3);
/**
 * Restore version
 *
 * @param string $id_file      File id
 * @param string $vid          Version id
 * @param string $categoryFrom Category from
 *
 * @return boolean true on success
 *                 false on error
 */
function wpfd_addon_restore_version($id_file, $vid, $categoryFrom)
{
    switch ($categoryFrom) {
        case 'googleDrive':
            Application::getInstance('WpfdAddon');
            $google = Model::getInstance('cloudfiles');
            return $google->updateRevision($id_file, $vid);
        case 'dropbox':
            Application::getInstance('WpfdAddon');
            $dropFile = Model::getInstance('dropboxfiles');
            return $dropFile->restoreVersion($id_file, $vid);
        case 'onedrive':
            // todo: made download version for onedrive too
        default:
            return false;
    }
}
add_filter('wpfd_addon_download_version', 'wpfd_addon_download_version', 10, 3);
/**
 * Download version
 *
 * @param string $id_file      File id
 * @param string $vid          Version id
 * @param string $categoryFrom Category from
 *
 * @return boolean false on error
 *                 download file on success
 */
function wpfd_addon_download_version($id_file, $vid, $categoryFrom)
{
    switch ($categoryFrom) {
        case 'googleDrive':
            Application::getInstance('WpfdAddon');
            $google = Model::getInstance('cloudfiles');
            return $google->downloadRevision($id_file, $vid);
        case 'dropbox':
            Application::getInstance('WpfdAddon');
            $dropFile = Model::getInstance('dropboxfiles');
            return $dropFile->downloadVersion($id_file, $vid);
        case 'onedrive':
            // todo: made download version for onedrive too
        default:
            return false;
    }
}

add_filter('wpfd_addon_save_file_info', 'wpfd_addon_save_file_info', 10, 3);
/**
 * Save addon file info callback
 *
 * @param array          $data         File data
 * @param string|boolean $categoryFrom Category from
 * @param integer        $categoryId   Category term id
 *
 * @return boolean|string
 */
function wpfd_addon_save_file_info($data, $categoryFrom, $categoryId)
{
    switch ($categoryFrom) {
        case 'googleDrive':
            return wpfdAddonSaveFileInfo($data);
        case 'dropbox':
            return wpfdAddonSaveDropboxFileInfo($data, $categoryId);
        case 'onedrive':
            return wpfdAddonSaveOneDriveFileInfo($data, $categoryId);
        case 'onedrive_business':
            return wpfdAddonSaveOneDriveBusinessFileInfo($data, $categoryId);
        default:
            return false;
    }
}

add_filter('wpfd_addon_get_file_info', 'wpfd_addon_get_file_info', 10, 3);
/**
 * Get cloud file info callback
 *
 * @param string  $fileId       File id
 * @param integer $categoryId   Category term id
 * @param string  $categoryFrom Category from
 *
 * @return array|boolean
 */
function wpfd_addon_get_file_info($fileId, $categoryId, $categoryFrom)
{
    switch ($categoryFrom) {
        case 'googleDrive':
            return wpfdAddonGetFileInfo($fileId, $categoryId);
        case 'dropbox':
            return wpfdAddonDropboxGetFileInfo($fileId, $categoryId);
        case 'onedrive':
            return wpfdAddonOneDriveGetFileInfo($fileId, $categoryId);
        case 'onedrive_business':
            return wpfdAddonOneDriveBusinessGetFileInfo($fileId, $categoryId);
        default:
            return false;
    }
}

add_action('wpfd_update_category_name', 'wpfd_addon_update_category_name', 10, 2);
/**
 * Update addon category name callback
 *
 * @param integer $categoryId Category term id
 * @param string  $name       New category name
 *
 * @return void
 */
function wpfd_addon_update_category_name($categoryId, $name)
{
    $categoryFrom = wpfdAddonCategoryFrom($categoryId);
    switch ($categoryFrom) {
        case 'googleDrive':
            wpfdAddonSetCategoryGoogleDriveTitle($categoryId, $name);
            break;
        case 'dropbox':
            wpfdAddonSetCategoryDropboxTitle($categoryId, $name);
            break;
        case 'onedrive':
            wpfdAddonSetCategoryOneDriveTitle($categoryId, $name);
            break;
        case 'onedrive_business':
            wpfdAddonSetCategoryOneDriveBusinessTitle($categoryId, $name);
            break;
        default:
            break;
    }
}

add_filter('wpfd_addon_delete_file', 'wpfd_addon_delete_file', 10, 3);
/**
 * Delete addon file callback
 *
 * @param integer $categoryId   Category term id
 * @param string  $fileId       Cloud file id
 * @param string  $categoryFrom Category from
 *
 * @return boolean
 */
function wpfd_addon_delete_file($categoryId, $fileId, $categoryFrom)
{
    switch ($categoryFrom) {
        case 'googleDrive':
            return wpfdAddonDeleteGoogleCloudFiles($categoryId, $fileId);
        case 'dropbox':
            return wpfdAddonDeleteDropboxFiles($categoryId, $fileId);
        case 'onedrive':
            return wpfdAddonDeleteOneDriveFiles($categoryId, $fileId);
        case 'onedrive_business':
            return wpfdAddonDeleteOneDriveBusinessFiles($categoryId, $fileId);
        default:
            return false;
    }
}

add_filter('wpfd_addon_get_files', 'wpfd_addon_get_files', 10, 3);
/**
 * Get addon files list from category id callback
 *
 * @param integer $categoryId    Category term id
 * @param string  $categoryFrom  Category from
 * @param boolean $list_id_files List id files
 *
 * @return array|boolean
 */
function wpfd_addon_get_files($categoryId, $categoryFrom, $list_id_files)
{
    if (!isset($list_id_files)) {
        $list_id_files = false;
    }

    switch ($categoryFrom) {
        case 'googleDrive':
            return wpfdAddonDisplayGoogleDriveCategories($categoryId, $list_id_files);
        case 'dropbox':
            return wpfdAddonDisplayDropboxCategories($categoryId, $list_id_files);
        case 'onedrive':
            return wpfdAddonDisplayOneDriveCategories($categoryId, $list_id_files);
        case 'onedrive_business':
            return wpfdAddonDisplayOneDriveBusinessCategories($categoryId, $list_id_files);
        default:
            return false;
    }
}

add_action('wpfd_addon_upload_file', 'wpfd_addon_upload_file', 10, 4);
/**
 * Upload file to cloud callback
 *
 * @param array   $item         File object
 * @param string  $file_current File name
 * @param integer $id_category  Category term id
 * @param string  $categoryFrom Category from
 *
 * @return void
 */
function wpfd_addon_upload_file($item, $file_current, $id_category, $categoryFrom)
{
    switch ($categoryFrom) {
        case 'googleDrive':
            wpfdAddonUploadGoogleFile($item, $file_current, $id_category);
            break;
        case 'dropbox':
            wpfdAddonUploadDropboxFile($item, $file_current, $id_category);
            break;
        case 'onedrive':
            wpfdAddonUploadOneDriveFile($item, $file_current, $id_category);
            break;
        case 'onedrive_business':
            wpfdAddonUploadOneDriveBusinessFile($item, $file_current, $id_category);
            break;
        default:
            break;
    }
}

add_action('wpfd_addon_update_version_description', 'wpfd_addon_update_version_description', 10, 4);

/**
 * Update version and description on copy
 *
 * @param string  $version      Version
 * @param string  $description  Description
 * @param string  $categoryFrom Category from
 * @param integer $categoryId   Category term id
 *
 * @return void
 */
function wpfd_addon_update_version_description($version, $description, $categoryFrom, $categoryId)
{
    switch ($categoryFrom) {
        case 'googleDrive':
            wpfdAddonGoogleUpdateVersionDescription($version, $description);
            break;
        case 'dropbox':
            wpfdAddonDropboxUpdateVersionDescription($version, $description, $categoryId);
            break;
        case 'onedrive':
            wpfdAddonOnedriveUpdateVersionDescription($version, $description, $categoryId);
            break;
        case 'onedrive_business':
            wpfdAddonOnedriveBusinessUpdateVersionDescription($version, $description, $categoryId);
            break;
        default:
            break;
    }
}

/**
 * WpfdAddon Init
 *
 * @return void
 */
function wpfdAddonInit()
{
    $app = Application::getInstance('WpfdAddon');
    load_plugin_textdomain('wpfdAddon', null, $app->getPath(true) . DIRECTORY_SEPARATOR . 'languages');
    $path_wpfdhelper = $app->getPath() . DIRECTORY_SEPARATOR . 'admin' . DIRECTORY_SEPARATOR . 'helpers';
    $path_wpfdhelper .= DIRECTORY_SEPARATOR . 'WpfdHelper.php';
    require_once $path_wpfdhelper;
    $path_wpfda_class = $app->getPath() . DIRECTORY_SEPARATOR . $app->getType() . DIRECTORY_SEPARATOR . 'classes';
    require_once $path_wpfda_class . DIRECTORY_SEPARATOR . 'WpfdCloudCache.php';
    require_once $path_wpfda_class . DIRECTORY_SEPARATOR . 'WpfdAddonGoogle.php';
    require_once $path_wpfda_class . DIRECTORY_SEPARATOR . 'WpfdAddonDropbox.php';
    require_once $path_wpfda_class . DIRECTORY_SEPARATOR . 'WpfdAddonOneDrive.php';
    require_once $path_wpfda_class . DIRECTORY_SEPARATOR . 'WpfdAddonOneDriveBusiness.php';
    require_once $path_wpfda_class . DIRECTORY_SEPARATOR . 'WpfdAddonOneDriveBusinessAdmin.php';
    require_once $path_wpfda_class . DIRECTORY_SEPARATOR . 'WpfdAddonWoocommerce.php';
    new WpfdAddonWoocommerce();
    new WpfdAddonOneDriveBusinessAdmin();
    add_action('admin_enqueue_scripts', 'wpfdAddonScriptsAndStyles');
}


/**
 * Register Addons Scripts and Styles
 *
 * @return void
 */
function wpfdAddonScriptsAndStyles()
{
    wp_enqueue_style(
        'wpfdAddon-style',
        plugins_url('assets/css/wpfdAddonMainStyle.css', __FILE__),
        array(),
        WPFDA_VERSION
    );
    wp_enqueue_style(
        'wpfdAddon-modal',
        plugins_url('assets/css/leanmodal.css', __FILE__),
        array(),
        WPFDA_VERSION
    );
    wp_enqueue_script(
        'wpfdAddon-modal',
        plugins_url('assets/js/jquery.leanModal.min.js', __FILE__),
        array('jquery'),
        WPFDA_VERSION
    );
    wp_enqueue_script(
        'wpfdAddon-script',
        plugins_url('assets/js/wpFileDownloadJsMain.js', __FILE__),
        array(),
        WPFDA_VERSION
    );
}

/**
 * Delete Google Drive category callback
 *
 * @return void
 */
function wpfdAddonDeleteCategory_callback()
{
    wpfdAddon_call('category.deleteCategory');
}

/**
 * Add Google Drive category callBack
 *
 * @return void
 */
function wpfdAddonAddCategory_callBack()
{
    wpfdAddon_call('category.addCategory');
}

/**
 * Add Dropbox category callBack
 *
 * @return void
 */
function wpfdAddonAddDropCategory_callBack()
{
    wpfdAddon_call('category.addDropCategory');
}

/**
 * Google drive auto sync callback
 *
 * @return void
 */
function wpfdAddonGoogleDriveSync()
{
    $cloudConfig = WpfdAddonHelper::getAllCloudConfigs();
    $sync_time = (int) $cloudConfig['googleSyncTime'];
    $sync_method = (string) $cloudConfig['googleSyncMethod'];
    if ($sync_time > 0 && $sync_method !== 'setup_on_server') {
        $curSyncInterval = WpfdAddonHelper::curSyncInterval();
        if ($curSyncInterval >= $sync_time && $sync_method === 'sync_page_curl') {
            wp_remote_get(
                admin_url('admin-ajax.php') . '?action=googleSync',
                array(
                    'timeout' => 1,
                    'blocking' => false,
                    'sslverify' => false,
                )
            );
        }
        if ($curSyncInterval >= $sync_time && $sync_method === 'sync_page_curl_ajax') {
            wpfdAddonGoogleSync_callback();
        }
    }
}

/**
 * Function googleSync callback
 *
 * @return void
 */
function wpfdAddonGoogleSync_callback()
{
    wpfdAddon_call('googledrive.googlesync');
}

/**
 * Toggle watch changes
 *
 * @return void
 */
function wpfdAddonGoogleWatchChanges_callback()
{
    wpfdAddon_call('googledrive.googleStopWatchChanges');
}

/**
 * Webhook to listen changes form Google Drive
 *
 * @return void
 */
function wpfdAddonGooglePushListener_callback()
{
    wpfdAddon_call('googledrive.listener');
}

/**
 * Check where category come from
 *
 * @param integer $termId Term Id
 *
 * @return boolean|string
 */
function wpfdAddonCategoryFrom($termId)
{
    if (WpfdAddonHelper::getGoogleDriveIdByTermId($termId)) {
        return 'googleDrive';
    } elseif (WpfdAddonHelper::getDropboxIdByTermId($termId)) {
        return 'dropbox';
    } elseif (WpfdAddonHelper::getOneDriveIdByTermId($termId)) {
        return 'onedrive';
    } elseif (WpfdAddonHelper::getOneDriveBusinessIdByTermId($termId)) {
        return 'onedrive_business';
    } else {
        return false;
    }
}

/**
 * Gooogle drive change order callback
 *
 * @param integer $pk Pk
 *
 * @return void
 */
function wpfdAddonGoogleDriveChangeOrder($pk)
{
    Application::getInstance('WpfdAddon');
    $cloudCategory = Model::getInstance('cloudcategory');
    $cloudCategory->changeOrder($pk);
}

/**
 * Delete version
 *
 * @param integer $termId    Term Id
 * @param string  $fileId    File id
 * @param string  $versionId Version Id
 *
 * @return boolean
 */
function wpfdAddonDeleteVersion($termId, $fileId, $versionId)
{
    Application::getInstance('WpfdAddon');
    $cloudFile = Model::getInstance('cloudfiles');
    return $cloudFile->deleteVersion(WpfdAddonHelper::getGoogleDriveIdByTermId($termId), $fileId, $versionId);
}

/**
 * Upload version
 *
 * @param array   $data   File Data
 * @param integer $termId Term id
 *
 * @return boolean
 */
function wpfdAddonUploadVersion($data, $termId)
{
    Application::getInstance('WpfdAddon');
    $cloudFile = Model::getInstance('cloudfiles');
    return $cloudFile->uploadVersion($data, WpfdAddonHelper::getGoogleDriveIdByTermId($termId));
}

/**
 * Save file info google drive
 *
 * @param array $data File data
 *
 * @return boolean
 */
function wpfdAddonSaveFileInfo($data)
{
    Application::getInstance('WpfdAddon');
    $cloudFile = Model::getInstance('cloudfiles');
    return $cloudFile->saveFileInfo($data);
}
/**
 * Get level category google drive
 *
 * @param WP_Term $category Term
 *
 * @return WP_Term
 */
function wpfdAddonLevelCategory($category)
{
    $cloud_id = WpfdAddonHelper::getGoogleDriveIdByTermId($category->term_id);
    if ($cloud_id) {
        $category->wp_term_id = $category->term_id;
        $category->wp_parent = $category->parent;
        $category->term_id = $cloud_id;
        $category->parent = WpfdAddonHelper::getGoogleDriveIdByTermId($category->parent);
    }
    return $category;
}
/**
 * Get list version
 *
 * @param string  $fileId File Id
 * @param integer $termId Term Id
 *
 * @return boolean|array
 */
function wpfdAddonGetListVersions($fileId, $termId)
{
    Application::getInstance('WpfdAddon');
    $cloudFile = Model::getInstance('cloudfiles');
    $result = $cloudFile->getListVersions($fileId, WpfdAddonHelper::getGoogleDriveIdByTermId($termId), $termId);
    return $result;
}

/**
 * Delete google cloud files
 *
 * @param integer $idCategory Term Id
 * @param string  $idFile     File Id
 *
 * @return boolean
 */
function wpfdAddonDeleteGoogleCloudFiles($idCategory, $idFile)
{
    Application::getInstance('WpfdAddon');
    $cloudFile = Model::getInstance('cloudfiles');
    return $cloudFile->deleteGoogleCloudFile($idCategory, $idFile);
}

/**
 * Display google drive category
 *
 * @param integer $termId      Term Id
 * @param boolean $listIdFlies List id files
 *
 * @return boolean|array
 */
function wpfdAddonDisplayGoogleDriveCategories($termId, $listIdFlies = false)
{
    if (WpfdAddonHelper::getGoogleDriveIdByTermId($termId)) {
        Application::getInstance('WpfdAddon');
        $cloudFile = Model::getInstance('cloudfiles');
        return $cloudFile->getListGoogleDriveFiles($termId, $listIdFlies);
    }
    return false;
}

/**
 * Get a file google drive info
 *
 * @param string  $fileId     File Id
 * @param integer $categoryId Category term id
 *
 * @return boolean|array
 */
function wpfdAddonGetFileInfo($fileId, $categoryId)
{
    Application::getInstance('WpfdAddon');
    $cloudFile = Model::getInstance('cloudfiles');
    return $cloudFile->getFileInfo($fileId, $categoryId);
}

/**
 * Upload google drive
 *
 * @param integer $termId Term id
 * @param array   $file   Upload file info
 *
 * @return array
 */
function wpfdAddonGoogleDriveUpload($termId, $file)
{
    Application::getInstance('WpfdAddon');
    $cloudFile = Model::getInstance('cloudfiles');
    return $cloudFile->googleDriveUpload($termId, $file);
}

/**
 * Get leve category OneDrive
 *
 * @param WP_Term $category Category
 *
 * @return mixed
 */
//function wpfdAddonLevelCategoryOneDrive($category)
//{
//    $onedrive_id = WpfdAddonHelper::getOneDriveIdByTermId($category->term_id);
//    if ($onedrive_id) {
//        $category->wp_term_id = $category->term_id;
//        $category->wp_parent = $category->parent;
//        $category->term_id = $onedrive_id;
//        $category->parent = WpfdAddonHelper::getOneDriveIdByTermId($category->parent);
//    }
//    return $category;
//}
/**
 * Set title category google drive
 *
 * @param integer $termId Term id
 * @param string  $title  Title
 *
 * @return boolean
 */
function wpfdAddonSetCategoryGoogleDriveTitle($termId, $title)
{
    Application::getInstance('WpfdAddon');
    $cloudCategory = Model::getInstance('cloudcategory');
    return $cloudCategory->changeCategoryName(WpfdAddonHelper::getGoogleDriveIdByTermId($termId), $title);
}

/**
 * Get all config google drive
 *
 * @return array
 */
function getAlldata()
{
    return WpfdAddonHelper::getAllCloudConfigs();
}

/**
 * Display drop down create google drive
 *
 * @return void
 */
function displayDropDownCreateCloud()
{
    $data = getAlldata();
    $google = new WpfdAddonGoogleDrive();
    $checkAuth = $google->checkAuth();
    if (isset($data['googleCredentials']) && (!empty($data['googleCredentials'])) && $checkAuth) {
        echo '<li>
                <a href="#" class="button googleCreate">
                <span class="googledrive-icon" style="line-height: inherit;"></span> '
            . esc_html__('Google Drive', 'wpfdAddon') . '</a>
             </li>';
    }
}

/**
 * Display Categories GoogleCloud
 *
 * @param integer $termId Term Id
 *
 * @return string
 */
function displayCategoriesGoogleCloud($termId)
{
    $dataParams = WpfdAddonHelper::getGoogleDriveParams();
    if ($dataParams) {
        foreach ($dataParams as $key => $val) {
            if ((int) $val['termId'] === (int) $termId) {
                return '<i class="google-drive-icon"></i>&nbsp';
            }
        }
    }
    return '';
}

/**
 * Display Button Google Sync
 *
 * @return void
 */
function displayButtonSync()
{
    $data = getAlldata();
    $google = new WpfdAddonGoogleDrive();
    $checkAuth = $google->checkAuth();
    if (isset($data['googleCredentials']) && (!empty($data['googleCredentials'])) && $checkAuth) {
        echo ' <a href="#" title="' . esc_html__('Sync with Google Drive', 'wpfdAddon') . '" id="btn-sync-gg"  
                data-loading-text="<i class=\'wpfd-svg-icon-sync-loading\'></i>"  
                data-complete-text="<i class=\'wpfd-svg-icon-sync-googledrive\'></i>" class="ju-button">
                 <i class="wpfd-svg-icon-sync-googledrive"></i>
               </a>';
    }
}


/**
 * Display Cloud taps
 *
 * @return void
 */
function wpfd_addon_display_cloud_configuration_tab()
{
    echo '<a id="tab-cloudconnection" class="nav-tab" data-tab-id="cloudconnection" href="#cloudconnection">'
        . esc_html__('Cloud connection', 'wpfdAddon') .
        '</a>';
}

/**
 * Display Social taps
 *
 * @return void
 */
function wpfd_addon_display_social_tab()
{
    echo '<a id="tab-social" class="nav-tab" data-tab-id="social" href="#social">'
        . esc_html__('Social locker', 'wpfdAddon') . '</a>';
}

/**
 * Print social locker content
 *
 * @return void
 */
function wpfd_addon_display_social_content()
{
    Application::getInstance('WpfdAddon');
    $modelConf = Model::getInstance('config');
    $file_form = new Form();
    $formFile = Application::getInstance('WpfdAddon')->getPath() . DIRECTORY_SEPARATOR . 'admin';
    $formFile .= DIRECTORY_SEPARATOR . 'forms' . DIRECTORY_SEPARATOR . 'config.xml';
    $configform = null;
    if ($file_form->load($formFile, $modelConf->getSocialConfig())) {
        $configform = $file_form->render();
    }
    echo '<div id="wpfd-social-config" class="tab-pane ">';
    // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Form render we can not use esc here
    echo $configform;
    echo '</div>';
}

/**
 * Display cloud tap content
 *
 * @return void
 */
function displayGoogleDriveConfigurationContent()
{
    $data = getAlldata();
    $cloudConfigform = new Form();
    $formFile = Application::getInstance('WpfdAddon')->getPath() . DIRECTORY_SEPARATOR . 'admin';
    $formFile .= DIRECTORY_SEPARATOR . 'forms' . DIRECTORY_SEPARATOR . 'cloud_config.xml';
    if ($cloudConfigform->load($formFile, $data)) {
        $cloudConfigform = $cloudConfigform->render();
    }
    echo '<div id="wpfd-theme-cloud" class="">';
    echo '<div id="wpfd-btnconnect-ggd">';
    do_action('cloudconnector_display_ggd_settings');
    showButtonConnectToCloud();
    echo '</div>';
    wpfdShowPushNotification();
    // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Form render we can not use esc here
    echo $cloudConfigform;
    echo '<a class="ju-button orange-outline-button ju-button-inline ggd-documentation" 
            href="https://www.joomunited.com/wordpress-documentation/wp-file-download/296-wp-file-download-addon-google-drive-integration" target="_blank">
            <span>' . esc_html__('Read the online support documentation', 'wpfdAddon') . '</span>
            </a>
            <div style="clear:both">&nbsp</div>
            ';
    echo '</div>';
}

/**
 * Display button connect to cloud when exist cloud config data
 *
 * @return boolean
 */
function hasButton()
{
    $dataGoogle = WpfdAddonHelper::getDataConfigBySeverName('google');
    $displayButton = true;
    if (isset($dataGoogle) && (!empty($dataGoogle))) {
        if ((empty($dataGoogle['googleClientId'])) || (empty($dataGoogle['googleClientSecret']))) {
            $displayButton = false;
        }
    } else {
        $displayButton = false;
    }
    return $displayButton;
}

/**
 * Parse origin url
 *
 * @param string $url Input url
 *
 * @return string
 */
function wpfd_parse_origin_url($url)
{
    $raw_url = parse_url($url);
    $scheme  = isset($raw_url['scheme']) ? $raw_url['scheme'] . '://' : '';
    $host    = isset($raw_url['host']) ? $raw_url['host'] : '';
    $port    = isset($raw_url['port']) ? ':' . $raw_url['port'] : '';
    $user    = isset($raw_url['user']) ? $raw_url['user'] : '';
    $pass    = isset($raw_url['pass']) ? ':' . $raw_url['pass'] : '';
    $pass    = ($user || $pass) ? $pass . '@' : '';

    return esc_url($scheme . $user . $pass . $host . $port);
}

/**
 * Display button connect google drive
 *
 * @return void
 */
function showButtonConnectToCloud()
{
    $app = Application::getInstance('WpfdAddon');
    $path_wpfdaddongoogle = $app->getPath() . DIRECTORY_SEPARATOR . $app->getType() . DIRECTORY_SEPARATOR . 'classes';
    $path_wpfdaddongoogle .= DIRECTORY_SEPARATOR . 'WpfdAddonGoogle.php';
    require_once $path_wpfdaddongoogle;
    $googleDrive = new WpfdAddonGoogleDrive();
    $javascript_origins = wpfd_parse_origin_url(site_url());
    if (hasButton()) {
        if (!$googleDrive->checkAuth()) {
            $url = $googleDrive->getAuthorisationUrl();
            ?>
            <a id="ggconnect" class="ju-button" href="#"
               onclick="window.open('<?php echo esc_url($url); ?>','foo','width=600,height=600');return false;">
                <img src="<?php echo esc_url(plugins_url('assets/images/drive-icon-colored.png', __FILE__)); ?>" alt=""/>
                <?php esc_html_e('Connect Google Drive', 'wpfdAddon') ?>
            </a>
            <?php
        } else { ?>
            <a id="gg_disconnect" class="ju-button" href="admin.php?page=wpfdAddon-cloud&task=googledrive.logout">
                <img style="vertical-align: middle;"
                     src="<?php echo esc_url(plugins_url('assets/images/drive-icon-colored.png', __FILE__)); ?>" alt=""/>
                <?php esc_html_e('Disconnect Google Drive', 'wpfdAddon') ?>
            </a>
            <?php
        }
    }
    ?>
    <div id="gg_setup">
        <div class="ju-settings-option full-width">
            <label class="ju-setting-label" for=""><?php esc_html_e('JavaScript origins', 'wpfdAddon') ?></label>
                <input title="" class="ju-input ju-large-text" type="text" readonly="true"
                       value="<?php echo esc_url($javascript_origins); ?>"/>
        </div>
        <div class="ju-settings-option full-width">
            <label class="ju-setting-label" for=""><?php esc_html_e('Redirect URIs', 'wpfdAddon') ?></label>
                <?php
                $url_ggd_authenticate = site_url() . '/wp-admin/admin.php?page=wpfdAddon-cloud';
                $url_ggd_authenticate .= '&task=googledrive.authenticate';
                ?>
                <input title="" class="ju-input ju-large-text" type="text" readonly="true"
                       value="<?php echo esc_url($url_ggd_authenticate); ?>"/>
        </div>
    </div>
    <?php
}

/**
 * Show push notification elements in config tab
 *
 * @return void
 */
function wpfdShowPushNotification()
{
    if (!class_exists('WpfdAddonGoogleDrive')) {
        $app = Application::getInstance('WpfdAddon');
        $path_wpfdaddongoogle = $app->getPath() . DIRECTORY_SEPARATOR . $app->getType() . DIRECTORY_SEPARATOR . 'classes';
        $path_wpfdaddongoogle .= DIRECTORY_SEPARATOR . 'WpfdAddonGoogle.php';
        require_once $path_wpfdaddongoogle;
    }

    $googleDrive = new WpfdAddonGoogleDrive();
    if (!$googleDrive->checkAuth()) {
        return;
    }

    $automatic_mode = apply_filters('cloudconnector_ggd_filter_connect_mode', false);
    if ($automatic_mode) {
        return;
    }

    // Display error
    $googlePush = get_option('_wpfd_google_watch_changes', 0);
    $watchData = get_option('_wpfd_google_watch_data', '');
    $errorMessage = '';
    if ($watchData !== '') {
        $watchData = json_decode($watchData, true);
        if (is_array($watchData) && isset($watchData['error'])) {
            if ((int) $watchData['error'] === 401) {
                // Unauthorized domain
                $errorMessage = esc_html__('Google push notifications are activated but are not authorized on this domain, please check that this domain is validated on the Google Search console and the Google Cloud Platform', 'wpfdAddon');
            } else {
                // Site not used https
                $errorMessage = esc_html($watchData['message']);
            }
        }
    }
    $errorBgColor = '';
    if ($errorMessage !== '') {
        $errorBgColor = ' error';
    }

    if ($googlePush) {
        $text = esc_html__('Stop watching changes from Google Drive', 'wpfdAddon');
    } else {
        $text = esc_html__('Watch changes from Google Drive', 'wpfdAddon');
    }

    // Nonce field for ajax request
    $security = wp_create_nonce('wpfd-google-push');
    ?>
    <button id="wpfd-btnpush-ggd"
       data-security="<?php echo esc_attr($security); ?>"
       class="ju-button orange-outline-button<?php echo $errorBgColor; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- This place dont need to escaped?>"
       style="display: inline-block;float: right;"
       title="<?php esc_html_e('Enable/Disable the push notification for file synchronization. Allows you to make instant file synchronization (require domain validation on the Google Search Console)', 'wpfdAddon'); ?>"
    >
        <?php
        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped above
        echo $text;
        ?>
    </button>
    <?php
    $displayError = get_option('_wpfd_google_display_push_error', 1);
    if ($errorMessage !== '' && $displayError) : ?>
    <div class="wpfd-float-message wpfd-ggd-watch-change-message">
        <div class="wpfd-alert-message"><strong>Warning: </strong><?php echo $errorMessage; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped above ?></div>
    </div>
    <?php endif;
}
/**
 * Registry menu WPFD addon
 *
 * @return void
 */
function wpfdAddon_menu()
{
    add_submenu_page(
        'options.php',
        'WPFD Addon page',
        'WPFD Addon Submenu Page',
        'manage_options',
        'wpfdAddon-cloud',
        'wpfdAddon_call_controller'
    );
}

/**
 * Call controller
 *
 * @return void
 */
function wpfdAddon_call_controller()
{
    $task = Utilities::getInput('task');
    wpfdAddon_call($task);
}


/**
 * Wpfd addon call
 *
 * @param string $default_task Task defaulr
 *
 * @return void
 */
function wpfdAddon_call($default_task = 'wpfdAddon.display')
{
    $application = Application::getInstance('WpfdAddon');
    wpfdAddonInit();
    $application->execute($default_task);
}


/**
 * Get Dropbox configs
 *
 * @return array
 */
function getDropboxData()
{
    return WpfdAddonHelper::getAllDropboxConfigs();
}

/**
 * Display dropbox configuration tab
 *
 * @return void
 */
function displayDropboxConfigurationTab()
{
    echo '<a id="tab-dropbox" class="nav-tab" data-tab-id="dropbox" href="#dropbox">'
        . esc_html__('Dropbox', 'wpfdAddon') .
        '</a>';
}

/**
 * Display content configuration Dropbox
 *
 * @return void
 */
function displayDropboxConfigurationContent()
{
    $data = getDropboxData();
    $dropboxConfigform = new Form();
    $formFile = Application::getInstance('WpfdAddon')->getPath() . DIRECTORY_SEPARATOR . 'admin';
    $formFile .= DIRECTORY_SEPARATOR . 'forms' . DIRECTORY_SEPARATOR . 'dropbox_config.xml';
    if ($dropboxConfigform->load($formFile, $data)) {
        $dropboxConfigform = $dropboxConfigform->render();
    }
    echo '<div id="wpfd-theme-dropbox">';
    echo '<div id="wpfd-btnconnect-dropbox">';
    do_action('cloudconnector_display_dropbox_settings');
    showButtonConnectToDropbox();
    echo '</div>';
    // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Form render we can not use esc here
    echo $dropboxConfigform;
    echo '<a class="ju-button orange-outline-button ju-button-inline dropbox-documentation" href="https://www.joomunited.com/wordpress-documentation/wp-file-download/297-wp-file-download-addon-dropbox-integration"';
    echo ' target="_blank">' . esc_html__('Read the online support documentation', 'wpfdAddon') . '</span></a>';
    echo '<div style="clear:both">&nbsp</div>';
    echo '</div>';
}

/**
 * Registry menu dropbox
 *
 * @return void
 */
function wpfdDropboxAddon_menu()
{
    add_submenu_page(
        'options.php',
        'WPFD Dropbox Addon page',
        'WPFD Dropbox Addon Submenu Page',
        'manage_options',
        'wpfdAddon-dropbox',
        'wpfdAddon_call_controller'
    );
}

/**
 * Display button connect to cloud when exist cloud config data
 *
 * @return boolean
 */
function hasDropboxButton()
{
    $dataDropbox = WpfdAddonHelper::getDataConfigByDropbox('dropbox');
    $displayButton = true;
    if (isset($dataDropbox) && (!empty($dataDropbox))) {
        if ((empty($dataDropbox['dropboxKey'])) || (empty($dataDropbox['dropboxKey']))) {
            $displayButton = false;
        }
    } else {
        $displayButton = false;
    }
    return $displayButton;
}

/**
 * Show button connect dropbox if isset App key && App Secret
 *
 * @return void
 */
function showButtonConnectToDropbox()
{
    $app = Application::getInstance('WpfdAddon');
    $path_wpfdaddondropbox = $app->getPath() . DIRECTORY_SEPARATOR . $app->getType() . DIRECTORY_SEPARATOR . 'classes';
    $path_wpfdaddondropbox .= DIRECTORY_SEPARATOR . 'WpfdAddonDropbox.php';
    require_once $path_wpfdaddondropbox;
    $Dropbox = new WpfdAddonDropbox();
    if (hasDropboxButton()) {
        if ($Dropbox->checkAuth()) {
            $url = $Dropbox->getAuthorizeDropboxUrl();
            ?>
            <a id="drop_connect" class="ju-button" href="#"
               onclick="window.open('<?php echo esc_url($url); ?>','foo','width=600,height=600');return false;">
                <img style="vertical-align: middle;"
                     src="<?php echo esc_url(plugins_url('assets/images/dropbox_icon_colored.png', __FILE__)); ?>" alt=""/>
                <?php esc_html_e('Connect Dropbox', 'wpfdAddon') ?></a>
            <?php
        } else { ?>
            <a id="drop_disconnect" class="ju-button" href="admin.php?page=wpfdAddon-dropbox&task=dropbox.logout">
                <img style="vertical-align: middle;"
                     src="<?php echo esc_url(plugins_url('assets/images/dropbox_icon_colored.png', __FILE__)); ?>" alt=""/>
                <?php esc_html_e('Disconnect Dropbox', 'wpfdAddon') ?></a>
            <?php
            $listBaseFolders = $Dropbox->listChildrenFolders();
            $dropboxConfig = WpfdAddonHelper::getDataConfigByDropbox('dropbox');
            $baseFolderConfigId = isset($dropboxConfig['dropboxBaseFolderId']) ?
                $dropboxConfig['dropboxBaseFolderId'] : '';
            ?>
            <div class="ju-settings-option full-width dropboxBaseFolder-setup"><br/>
                <label class="ju-setting-label" for=""><?php esc_html_e('Select root folder', 'wpfdAddon') ?></label>
                <?php
                $content = '';
                $content .= '<select class="ju-input ju-large-text wpfd_dropboxBaseFolderId">';

                $content .= '<option value ="">— ' . esc_html__('Select root folder', 'wpfdAddon') . '—</option >';
                if (!empty($listBaseFolders)) {
                    foreach ($listBaseFolders as $fid => $f) {
                        if ($baseFolderConfigId === $f['id']) {
                            $content .= '<option selected ="selected" value = ' . esc_attr($f['id']) . '   > ' . esc_html($f['name']);
                            $content .= '</option >';
                        } else {
                            $content .= '<option value = ' . esc_attr($f['id']) . ' > ' . esc_html($f['name']) . '</option >';
                        }
                    }
                    $content .= '</select >';
                    // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escape above
                    echo $content;
                }
                ?>
                <div class="ju-settings-help">
                    <?php
                    $msg_wpfdaddon = 'Dropbox root folder selection for synchronization. Make sure to select the'
                        . ' right one as the synchronization may reflect the file changes on your live website!';
                    // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralText -- keep for short length of line
                    esc_html_e($msg_wpfdaddon, 'wpfdAddon');
                    ?>
                </div>
            </div>
            <?php
        }
    }
}

/**
 * Dropbox delete category
 *
 * @return void
 */
function wpfdAddonDeleteDropboxCategory_callback()
{
    wpfdAddon_call('category.deleteDropboxCategory');
}

/**
 * Drop down create dropbox
 *
 * @return void
 */
function displayDropDownCreateDropbox()
{
    $data = getDropboxData();
    $dropbox = new WpfdAddonDropbox();
    $checkAuth = $dropbox->checkAuth();
    if (isset($data['dropboxToken']) && (!empty($data['dropboxToken'])) && !$checkAuth) {
        ?>
        <li>
            <a href="#" class="button dropboxCreate">
                <i class="dropbox-icon"></i>
                <?php esc_html_e('Dropbox', 'wpfdAddon'); ?>
            </a>
        </li>
        <?php
    }
}
/**
 * Get category in dropbox
 *
 * @param WP_Term $category Category
 *
 * @return mixed
 */
//function wpfdAddonLevelCategoryDropbox($category)
//{
//    $drop_id = WpfdAddonHelper::getIdFolderByTermId($category->term_id);
//    if ($drop_id) {
//        $category->wp_term_id = $category->term_id;
//        $category->wp_parent = $category->parent;
//        $category->term_id = $drop_id;
//        $category->parent = WpfdAddonHelper::getIdFolderByTermId($category->parent);
//    }
//    return $category;
//}
/**
 * Display categories dropbox
 *
 * @param integer $termId Term id
 *
 * @return string
 */
function displayCategoriesDropbox($termId)
{
    $dataParams = WpfdAddonHelper::getDropboxParams();
    if ($dataParams) {
        foreach ($dataParams as $key => $val) {
            if ((int) $val['termId'] === (int) $termId) {
                return '<i class="dropbox-icon"></i>&nbsp';
            }
        }
    }
    return '';
}

/**
 * Set category dropbox title
 *
 * @param integer $termId Term id
 * @param string  $title  Titlte
 *
 * @return boolean
 */
function wpfdAddonSetCategoryDropboxTitle($termId, $title)
{
    Application::getInstance('WpfdAddon');
    $dropboxCategory = Model::getInstance('dropboxcategory');
    return $dropboxCategory->changeDropboxCategoryName(WpfdAddonHelper::getDropboxIdByTermId($termId), $title, $termId);
}

/**
 * Dropbox upload file
 *
 * @param integer $termId Term Id
 * @param array   $file   File info
 *
 * @return boolean
 */
function wpfdAddonDropboxUpload($termId, $file)
{
    Application::getInstance('WpfdAddon');
    $dropboxFile = Model::getInstance('dropboxfiles');
    return $dropboxFile->dropboxUpload($termId, $file);
}

/**
 * Get list file from dropbox
 *
 * @param integer $termId      Term id
 * @param boolean $listIdFlies List id files
 *
 * @return array|boolean
 */
function wpfdAddonDisplayDropboxCategories($termId, $listIdFlies = false)
{
    if (WpfdAddonHelper::getDropboxIdByTermId($termId)) {
        Application::getInstance('WpfdAddon');
        $dropFile = Model::getInstance('dropboxfiles');
        return $dropFile->getListDropboxFiles($termId, $listIdFlies);
    }
}

/**
 * Delete file from folder
 *
 * @param integer $idCategory Term id
 * @param string  $idFile     File id
 *
 * @return boolean
 */
function wpfdAddonDeleteDropboxFiles($idCategory, $idFile)
{
    Application::getInstance('WpfdAddon');
    $dropFile = Model::getInstance('dropboxfiles');
    return $dropFile->deleteDropboxFile($idCategory, $idFile);
}

/**
 * Get file info dropbox
 *
 * @param string  $idFile     File id
 * @param integer $idCategory Term id
 *
 * @return array
 */
function wpfdAddonDropboxGetFileInfo($idFile, $idCategory)
{
    Application::getInstance('WpfdAddon');
    $dropFile = Model::getInstance('dropboxfiles');
    return $dropFile->getDropboxFileInfo($idFile, $idCategory);
}

/**
 * Save dropbox file info
 *
 * @param aray    $data       File data
 * @param integer $idCategory Term id
 *
 * @return string File id
 */
function wpfdAddonSaveDropboxFileInfo($data, $idCategory)
{
    Application::getInstance('WpfdAddon');
    $dropFile = Model::getInstance('dropboxfiles');
    return $dropFile->saveDropboxFileInfo($data, $idCategory);
}


/**
 * Upload dropbox version
 *
 * @param array   $data   Version data
 * @param integer $termId Term id
 *
 * @return boolean
 */
function wpfdAddonUploadDropboxVersion($data, $termId)
{
    Application::getInstance('WpfdAddon');
    $dropFile = Model::getInstance('dropboxfiles');
    return $dropFile->uploadDropboxVersion($data, $termId);
}

/**
 * Dropbox version info
 *
 * @param string  $idFile     File id
 * @param integer $idCategory Term id
 *
 * @return array|boolean array when success
 *                       false when throw error
 */
function wpfdAddonDropboxVersionInfo($idFile, $idCategory)
{
    Application::getInstance('WpfdAddon');
    $dropFile = Model::getInstance('dropboxfiles');
    return $dropFile->displayDropboxVersionInfo($idFile, $idCategory);
}


/**
 * Change order dropbox
 *
 * @param integer $pk  Term id
 * @param integer $ref Ref term id
 *
 * @return void
 */
function wpfdAddonDropboxChangeOrder($pk, $ref)
{
    Application::getInstance('WpfdAddon');
    $dropCategory = Model::getInstance('dropboxcategory');
    $dropCategory->changeDropboxOrder($pk, $ref);
}

/**
 * Display Button sync dropbox
 *
 * @return void
 */
function displayButtonSyncDropbox()
{
    $data = getDropboxData();
    $dropbox = new WpfdAddonDropbox();
    $checkAuth = $dropbox->checkAuth();
    if (isset($data['dropboxToken']) && (!empty($data['dropboxToken'])) && !$checkAuth) {
        echo ' <a href="#" id="btn-sync-drop" title="' . esc_html__('Sync with Dropbox', 'wpfdAddon') . '"  
                    data-loading-text="<i class=\'wpfd-svg-icon-sync-loading\'></i>"  
                    data-complete-text="<i class=\'wpfd-svg-icon-sync-dropbox\'></i>" class="ju-button">
                 <i class="wpfd-svg-icon-sync-dropbox"></i>
               </a>';
    }
}

/**
 * Dropbox sync callback
 *
 * @return void
 */
function wpfdAddonDropboxSync_callback()
{
    wpfdAddon_call('dropbox.dropboxsync');
}

/**
 * Dropbox auto sync callback
 *
 * @return void
 */
function wpfdAddonDropboxAutoSync()
{
    $app = Application::getInstance('WpfdAddon');
    $path_wpfdaddondropbox = $app->getPath() . DIRECTORY_SEPARATOR . $app->getType() . DIRECTORY_SEPARATOR . 'classes';
    $path_wpfdaddondropbox .= DIRECTORY_SEPARATOR . 'WpfdAddonDropbox.php';
    require_once $path_wpfdaddondropbox;
    $dropbox = new WpfdAddonDropbox();
    if (!$dropbox->checkAuth()) {
        $cloudConfig = WpfdAddonHelper::getAllDropboxConfigs();
        $sync_time = (int) $cloudConfig['dropboxSyncTime'];
        $sync_method = (string) $cloudConfig['dropboxSyncMethod'];
        if ($sync_time > 0 && $sync_method !== 'setup_on_server') {
            $curSyncInterval = WpfdAddonHelper::curSyncIntervalDropbox();
            if ($curSyncInterval >= $sync_time && $sync_method === 'sync_page_curl') {
                wp_remote_get(
                    admin_url('admin-ajax.php') . '?action=dropboxSync',
                    array(
                        'timeout' => 1,
                        'blocking' => false,
                        'sslverify' => false,
                    )
                );
            }
            if ($curSyncInterval >= $sync_time && $sync_method === 'sync_page_curl_ajax') {
                wpfdAddonDropboxSync_callback();
            }
        }
    }
}

/**
 * Check cloud exist
 *
 * @return boolean
 */
function check_cloud_exist()
{
    $dropData = getDropboxData();
    $googleData = getAlldata();
    $oneDrive = getOneDriveData();
    $onedriveBusiness = get_option('_wpfdAddon_onedrive_business_config', '');
    $onedriveConnected = isset($oneDrive['onedriveConnected']) ? $oneDrive['onedriveConnected'] : 0;
    $onedriveBusinessConnected = isset($onedriveBusiness['connected']) ? $onedriveBusiness['connected'] : 0;
    if (!empty($dropData['dropboxToken']) || !empty($googleData['googleCredentials']) || $onedriveConnected || $onedriveBusinessConnected) {
        return true;
    } else {
        return false;
    }
}

/**
 * Download Google Drive Info
 *
 * @param string  $id_file     File id
 * @param integer $id_category Term id
 *
 * @return array|boolean
 */
function wpfdAddonDownloadGoogleDriveInfo($id_file, $id_category)
{
    $googleCate = new WpfdAddonGoogleDrive;
    $file = $googleCate->download($id_file, WpfdAddonHelper::getGoogleDriveIdByTermId($id_category), false, 0, false);
    $uploadDir = wp_upload_dir();
    $uploadDirTmp = $uploadDir['basedir'] . DIRECTORY_SEPARATOR . 'wpfd' . DIRECTORY_SEPARATOR . 'tmp' . DIRECTORY_SEPARATOR;
    if (!file_exists($uploadDirTmp)) {
        mkdir($uploadDirTmp, 0777, true);
        $data = '<html><body bgcolor="#FFFFFF"></body></html>';
        $tmpFile = fopen($uploadDirTmp . 'index.html', 'w');
        fwrite($tmpFile, $data);
        fclose($tmpFile);
        $data = 'deny from all';
        $tmpFile = fopen($uploadDirTmp . '.htaccess', 'w');
        fwrite($tmpFile, $data);
        fclose($tmpFile);
    }

    $tmpFilePath = $uploadDirTmp . md5(time()) . '.tmp';
    $googleCate->downloadLargeFile($file, $file->mimeType, $tmpFilePath);
    if (!file_exists($tmpFilePath)) {
        return false;
    }
    // todo: not working
    return array($googleCate, $file, $tmpFilePath);
}

/**
 * Upload google file
 *
 * @param array   $file         File info
 * @param string  $file_current File path
 * @param integer $id_category  Term id
 *
 * @return void
 */
function wpfdAddonUploadGoogleFile($file, $file_current, $id_category)
{
    $google = new WpfdAddonGoogleDrive;
    $fileSize = filesize($file_current);
    $fileName = $file['title'] . '.' . $file['ext'];
    $fileMime = WpfdHelperFile::mimeType($file['ext']);
    $fileParentCloudId = WpfdAddonHelper::getGoogleDriveIdByTermId($id_category);

    if ($fileSize > 10 * 1024 * 1024) {
        $result = $google->uploadLargeFile($fileName, $file_current, $fileMime, $fileParentCloudId);
    } else {
        $result = $google->uploadFile(
            $file['title'] . '.' . $file['ext'],
            file_get_contents($file_current),
            WpfdHelperFile::mimeType($file['ext']),
            WpfdAddonHelper::getGoogleDriveIdByTermId($id_category)
        );
    }

    add_filter('wpfd_addon_googledrive_uploaded_result', function () use ($result) {
        return $result;
    });
}

/**
 * Update Version and Description of Google File on copy
 *
 * @param string $version     Version
 * @param string $description Description
 *
 * @return void
 */
function wpfdAddonGoogleUpdateVersionDescription($version, $description)
{
    $uploadedFile = array();
    /**
     * Filter to get uploaded google drive file
     *
     * @param array|WPFDGoogle_Service_Drive_DriveFile
     */
    $uploadedFile = apply_filters('wpfd_addon_googledrive_uploaded_result', $uploadedFile);

    if (!($uploadedFile instanceof WPFDGoogle_Service_Drive_DriveFile)) {
        return;
    }

    // Update file version
    $google = new WpfdAddonGoogleDrive;
    $google->saveVersionNumber($uploadedFile->getId(), $version);
    // Update file description
    $google->updateDescription($uploadedFile->getId(), $description);
}
/**
 * Update Version and Description of Dropbox on copy
 *
 * @param string  $version     Version
 * @param string  $description Description
 * @param integer $catId       Category term id
 *
 * @return void
 */
function wpfdAddonDropboxUpdateVersionDescription($version, $description, $catId)
{
    $uploadedFile = array();
    /**
     * Filter to get uploaded dropbox file params
     *
     * @param array
     */
    $uploadedFile = apply_filters('wpfd_addon_dropbox_uploaded_result', $uploadedFile);

    if (empty($uploadedFile) || !isset($uploadedFile['id'])) {
        return;
    }

    $new_file_id = $uploadedFile['id'];
    // Update file version and description
    $fileInfos = WpfdAddonHelper::getDropboxFileInfos();

    if (!empty($fileInfos)) {
        if (isset($fileInfos[$catId]) && isset($fileInfos[$catId][$new_file_id])) {
            $fileInfos[$catId][$new_file_id]['version'] = isset($version) ? $version : '';
            $fileInfos[$catId][$new_file_id]['description'] = isset($description) ? $description : '';
        } else {
            $fileInfos[$catId] = array(
                $new_file_id => array(
                    'version'     => isset($version) ? $version : '',
                    'description' => isset($description) ? $description : ''
                )
            );
        }
    }
    WpfdAddonHelper::setDropboxFileInfos($fileInfos);
}

/**
 * Update Version and Description of Onedrive on copy
 *
 * @param string  $version     Version
 * @param string  $description Description
 * @param integer $catId       Category term id
 *
 * @return void
 */
function wpfdAddonOnedriveUpdateVersionDescription($version, $description, $catId)
{
    $uploadedFile = array();
    /**
     * Filter to get uploaded dropbox file params
     *
     * @param array
     */
    $uploadedFile = apply_filters('wpfd_addon_onedrive_uploaded_result', $uploadedFile);

    if (empty($uploadedFile) || !isset($uploadedFile['id'])) {
        return;
    }

    $new_file_id = $uploadedFile['id'];
    // Update file version and description
    $fileInfos = WpfdAddonHelper::getOnedriveFileInfos();

    if (!empty($fileInfos)) {
        if (isset($fileInfos[$catId]) && isset($fileInfos[$catId][$new_file_id])) {
            $fileInfos[$catId][$new_file_id]['version'] = isset($version) ? $version : '';
            $fileInfos[$catId][$new_file_id]['description'] = isset($description) ? $description : '';
        } else {
            $fileInfos[$catId] = array(
                $new_file_id => array(
                    'version'     => isset($version) ? $version : '',
                    'description' => isset($description) ? $description : ''
                )
            );
        }
    }

    WpfdAddonHelper::setOneDriveFileInfos($fileInfos);
}

/**
 * Copy google to google category
 *
 * @param string  $id_file     File id
 * @param integer $id_category Term id
 *
 * @return void
 */
function wpfdAddonCopyGoogleGoogle($id_file, $id_category)
{
    $google = new WpfdAddonGoogleDrive;
    $google->copyFile($id_file, WpfdAddonHelper::getGoogleDriveIdByTermId($id_category));
}

/**
 * Move file google in google drive
 *
 * @param string  $id_file     File id
 * @param integer $id_category Term id
 *
 * @return void
 */
function wpfdAddonMoveGoogleGoogle($id_file, $id_category)
{
    $google = new WpfdAddonGoogleDrive;
    $google->moveFile($id_file, WpfdAddonHelper::getGoogleDriveIdByTermId($id_category));
}

/**
 * Download dropbox info
 *
 * @param string $id_file File id
 *
 * @return array
 */
function wpfdAddonDownloadDropboxInfo($id_file)
{
    $dropbox = new WpfdAddonDropbox();
    return $dropbox->downloadDropbox($id_file);
}

/**
 * Upload dropbox file
 *
 * @param array   $file         File info
 * @param string  $file_current File path
 * @param integer $id_category  Term id
 *
 * @return void
 */
function wpfdAddonUploadDropboxFile($file, $file_current, $id_category)
{
    $dropbox = new WpfdAddonDropbox();

    $result = $dropbox->uploadFile(
        $file['title'] . '.' . $file['ext'],
        $file_current,
        filesize($file_current),
        WpfdAddonHelper::getDropboxIdByTermId($id_category)
    );

    // Fix conflict file name for dropbox
    $i = 1;
    while ($result === false) {
        $newFileTitle = $file['title'] . ' (' . $i . ')';
        $result = $dropbox->uploadFile(
            $newFileTitle . '.' . $file['ext'],
            $file_current,
            filesize($file_current),
            WpfdAddonHelper::getDropboxIdByTermId($id_category)
        );
        $i++;
    }

    add_filter('wpfd_addon_dropbox_uploaded_result', function () use ($result) {
        return $result;
    });
}

/**
 * Copy file in dropbox
 *
 * @param string  $id_file     File id
 * @param integer $id_category Term Id
 *
 * @return void
 */
function wpfdAddonCopyDropboxDropbox($id_file, $id_category)
{
    $dropbox = new WpfdAddonDropbox();
    $file = $dropbox->getDropboxFile($id_file);
    $newFileName = strtolower($file['name']);
    $result = false;
    $i = 1;
    // Fix conflict file name for dropbox
    while (!$result) {
        $result = $dropbox->copyFileDropbox(
            $file['path_lower'],
            WpfdAddonHelper::getDropboxIdByTermId($id_category) . '/' . $newFileName
        );
        if (false === $result) {
            $newFileName = '(' . $i . ')' . strtolower($file['name']);
            $i++;
        }
    }

    add_filter('wpfd_addon_dropbox_uploaded_result', function () use ($result) {
        return $result;
    });
}

/**
 * Move file in dropbox
 *
 * @param string  $id_file     File id
 * @param integer $id_category Term id
 *
 * @return void
 */
function wpfdAddonMoveDropboxDropbox($id_file, $id_category)
{
    $dropbox = new WpfdAddonDropbox();
    $file = $dropbox->getDropboxFile($id_file);
    $dropbox->moveFile(
        $file['path_lower'],
        WpfdAddonHelper::getDropboxIdByTermId($id_category) . '/' . strtolower($file['name'])
    );
}


/**
 * Display One Drive tap content
 *
 * @return void
 */
function wpfdOneDriveAddon_menu()
{
    add_submenu_page(
        'options.php',
        'WPFD OneDrive Addon page',
        'WPFD OneDrive Addon Submenu Page',
        'manage_options',
        'wpfdAddon-onedrive',
        'wpfdAddon_call_controller'
    );
}

/**
 * OneDrive configuration content
 *
 * @return void
 */
function displayOneDriveConfigurationContent()
{
    $data = getOneDriveData();
    $oneDriveConfigform = new Form();
    $formPath = Application::getInstance('WpfdAddon')->getPath() . DIRECTORY_SEPARATOR . 'admin';
    $formPath .= DIRECTORY_SEPARATOR . 'forms' . DIRECTORY_SEPARATOR;
    $formFile = $formPath . 'onedrive_config.xml';

    echo '<div id="wpfd-theme-onedrive" class="">';
    echo '<div id="wpfd-btnconnect-onedrive">';
    do_action('cloudconnector_display_onedrive_settings');
    showButtonConnectToOneDrive();
    echo '</div>';
    if ($oneDriveConfigform->load($formFile, $data)) {
        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Form render we can not use esc here
        echo $oneDriveConfigform->render();
    }
    echo '</div><div style="clear:both">&nbsp;</div>';
}

/**
 * Get OneDrive configs
 *
 * @return array
 */
function getOneDriveData()
{
    return WpfdAddonHelper::getAllOneDriveConfigs();
}

/**
 *  Display OneDrive taps
 *
 * @return void
 */
function displayOneDriveConfigurationTab()
{
    echo '<a id="tab-onedrive" class="nav-tab" data-tab-id="onedrive" href="#onedrive">'
        . esc_html__('One Drive', 'wpfdAddon')
        . '</a>';
}

/**
 * Show button connect OneDrive if isset App key && App Secret
 *
 * @return void
 */
function showButtonConnectToOneDrive()
{
    $app = Application::getInstance('WpfdAddon');
    $path_wpfdaddononedrive = $app->getPath() . DIRECTORY_SEPARATOR . $app->getType() . DIRECTORY_SEPARATOR . 'classes';
    $path_wpfdaddononedrive .= DIRECTORY_SEPARATOR . 'WpfdAddonOneDrive.php';
    require_once $path_wpfdaddononedrive;
    $onedrive = new WpfdAddonOneDrive();
    if (hasOneDriveButton()) {
        if (!checkConnectOnedrive()) {
            $url = $onedrive->getAuthorisationUrl();
            ?>
            <a id="onedrive_connect" class="ju-button" href="#"
               onclick="window.open('<?php echo esc_url($url); ?>','foo','width=600,height=600');return false;">
                <img style="vertical-align: middle;"
                     src="<?php echo esc_url(plugins_url('assets/images/onedrive_white.png', __FILE__)); ?>" alt=""/>
                <?php esc_html_e('Connect OneDrive', 'wpfdAddon') ?></a>
            <?php
        } else { ?>
            <a id="onedrive_disconnect" class="ju-button" href="admin.php?page=wpfdAddon-onedrive&task=onedrive.logout">
                <img style="vertical-align: middle;"
                     src="<?php echo esc_url(plugins_url('assets/images/onedrive.png', __FILE__)); ?>" alt=""/>
                <?php esc_html_e('Disconnect OneDrive', 'wpfdAddon') ?></a>
            <?php
        }
    } ?>
    <?php ?>
    <div id="onedriver_setup">
        <div class="ju-settings-option full-width">
            <label class="ju-setting-label" for=""><?php esc_html_e('Redirect URIs Server', 'wpfdAddon') ?></label>

                <input title="" class="ju-input ju-large-text" style="width:100%" type="text" readonly="true"
                       value="<?php echo esc_url(get_admin_url()); ?>admin.php"/>
        </div>
        <div class="ju-settings-option full-width">
            <label class="ju-setting-label" for=""><?php esc_html_e('Redirect URIs', 'wpfdAddon') ?></label>

                <?php
                $url_onedriveAuth = '/wp-admin/admin.php?page=wpfdAddon-onedrive&task=onedrive.authenticate';
                ?>
                <input title="" class="ju-input ju-large-text" style="width:100%" type="text" readonly="true"
                       value="<?php echo esc_url(site_url() . $url_onedriveAuth); ?>"/>
        </div>
            <a class="ju-button orange-outline-button ju-button-inline onedrive-documentation" href="https://www.joomunited.com/wordpress-documentation/wp-file-download/298-wp-file-download-addon-onedrive-integration"
               target="_blank"><?php esc_html_e('Read the online support documentation', 'wpfdAddon') ?></span></a>

    </div>
    <?php
}

/**
 * Display button connect to cloud when exist cloud config data
 *
 * @return boolean
 */
function hasOneDriveButton()
{
    $dataOneDrive = WpfdAddonHelper::getDataConfigByOneDrive('onedrive');
    $displayButton = true;
    if (isset($dataOneDrive) && (!empty($dataOneDrive))) {
        if ((empty($dataOneDrive['onedriveKey'])) || (empty($dataOneDrive['onedriveSecret']))) {
            $displayButton = false;
        }
    } else {
        $displayButton = false;
    }
    return $displayButton;
}

/**
 * Check connect onedrive
 *
 * @return boolean
 */
function checkConnectOnedrive()
{
    $dataOneDrive = WpfdAddonHelper::getAllOneDriveConfigs();
    $displayButton = true;
    if (isset($dataOneDrive) && (!empty($dataOneDrive))) {
        if ((empty($dataOneDrive['onedriveConnected'])) || (empty($dataOneDrive['onedriveConnected']))) {
            $displayButton = false;
        }
    } else {
        $displayButton = false;
    }
    return $displayButton;
}


/**
 * Display drop down create onedrive
 *
 * @return void
 */
function displayDropDownCreateOneDrive()
{
    $data = getOneDriveData();
    $onedriveConnected = isset($data['onedriveConnected']) ? $data['onedriveConnected'] : 0;
    if ($onedriveConnected) {
        echo '<li><a href="#" class="button onedriveCreate">
                <span class="onedrive-icon" style="line-height: inherit;"></span> '
            . esc_html__('OneDrive', 'wpfdAddon') . '</a>
              </li>';
    }
}

/**
 * Display OneDrive Button Sync
 *
 * @return void
 */
function displayOneDriveButtonSync()
{
    $data = getOneDriveData();
    $onedriveConnected = isset($data['onedriveConnected']) ? $data['onedriveConnected'] : 0;
    if ($onedriveConnected) {
        echo ' <a href="#" title="' . esc_html__('Sync with OneDrive', 'wpfdAddon') . '" id="btn-sync-onedrive"  
                data-loading-text="<i class=\'wpfd-svg-icon-sync-loading\'></i>"  
                data-complete-text="<i class=\'wpfd-svg-icon-sync-onedrive\'></i>" class="ju-button">
                 <i class="wpfd-svg-icon-sync-onedrive"></i>
               </a>';
    }
}

/**
 * OneDrive category callBack
 *
 * @return void
 */
function wpfdAddonAddOneDriveCategory_callBack()
{
    wpfdAddon_call('category.addOneDriveCategory');
}

/**
 * Delete OneDrive category callback
 *
 * @return void
 */
function wpfdAddonDeleteOneDriveCategory_callback()
{
    wpfdAddon_call('category.deleteOneDriveCategory');
}

/**
 * Display Categories OneDrive
 *
 * @param integer $termId Term id
 *
 * @return string
 */
function displayCategoriesOneDrive($termId)
{
    $dataParams = WpfdAddonHelper::getOneDriveParams();
    if ($dataParams) {
        foreach ($dataParams as $key => $val) {
            if ((int) $val['termId'] === (int) $termId) {
                return '<i class="onedrive-icon"></i>&nbsp';
            }
        }
    }
    return '';
}

/**
 * Set category oneDrive title
 *
 * @param integer $termId Term id
 * @param string  $title  Title
 *
 * @return boolean true if success
 *                 false if error
 */
function wpfdAddonSetCategoryOneDriveTitle($termId, $title)
{
    Application::getInstance('WpfdAddon');
    $onedriveCategory = Model::getInstance('onedrivecategory');
    return $onedriveCategory->changeCategoryName(WpfdAddonHelper::getOneDriveIdByTermId($termId), $title);
}

/**
 * OneDrive sync
 *
 * @return void
 */
function wpfdAddonOneDriveSync()
{
    $onedriveConfig = WpfdAddonHelper::getAllOneDriveConfigs();
    $sync_time = (int)$onedriveConfig['onedriveSyncTime'];
    $sync_method = (string) $onedriveConfig['onedriveSyncMethod'];

    if ($sync_time > 0 && $sync_method !== 'setup_on_server') {
        $curSyncInterval = WpfdAddonHelper::curSyncIntervalOneDrive();
        if ($curSyncInterval >= $sync_time && $sync_method === 'sync_page_curl') {
            wp_remote_get(
                admin_url('admin-ajax.php') . '?action=onedriveSync',
                array(
                    'timeout' => 1,
                    'blocking' => false,
                    'sslverify' => false,
                )
            );
        }
        if ($curSyncInterval >= $sync_time && $sync_method === 'sync_page_curl_ajax') {
            wpfdAddonOneDriveSync_callback();
        }
    }
}


/**
 * OneDrive Sync callback
 *
 * @return void
 */
function wpfdAddonOneDriveSync_callback()
{
    wpfdAddon_call('onedrive.onedrivesync');
}

/**
 * Get list file from onedriver
 *
 * @param integer $termId      Term Id
 * @param boolean $listIdFlies List id Files?
 *
 * @return array
 */
function wpfdAddonDisplayOneDriveCategories($termId, $listIdFlies = false)
{
    if (WpfdAddonHelper::getOneDriveIdByTermId($termId)) {
        Application::getInstance('WpfdAddon');
        $onedriveFile = Model::getInstance('onedrivefiles');

        return $onedriveFile->getListOneDriveFiles($termId, $listIdFlies);
    }
}

/**
 * Save OneDrive file Info
 *
 * @param array   $data       File data
 * @param integer $idCategory Term id
 *
 * @return string File id
 */
function wpfdAddonSaveOneDriveFileInfo($data, $idCategory)
{
    Application::getInstance('WpfdAddon');
    $onedriveFile = Model::getInstance('onedrivefiles');
    return $onedriveFile->saveOneDriveFileInfo($data, $idCategory);
}

/**
 * Get OneDrive file info
 *
 * @param string  $idFile     File id
 * @param integer $idCategory Term id
 *
 * @return boolean|array array File if success
 *                       false if error
 */
function wpfdAddonOneDriveGetFileInfo($idFile, $idCategory)
{
    Application::getInstance('WpfdAddon');
    $onedriveFile = Model::getInstance('onedrivefiles');
    /* @var $onedriveFile wpfdAddonModelOnedriveFiles */
    return $onedriveFile->getOneDriveFileInfo($idFile, $idCategory);
}

/**
 * OneDrive upload file
 *
 * @param integer $termId Term id
 * @param array   $file   File data
 *
 * @return array
 */
function wpfdAddonOneDriveUpload($termId, $file)
{
    Application::getInstance('WpfdAddon');
    $onedriveFile = Model::getInstance('onedrivefiles');
    return $onedriveFile->oneDriveUpload($termId, $file);
}

/**
 * Delete file from folder
 *
 * @param integer $idCategory Term id
 * @param string  $idFile     File id
 *
 * @return boolean true if success
 *                 false on error
 */
function wpfdAddonDeleteOneDriveFiles($idCategory, $idFile)
{
    Application::getInstance('WpfdAddon');
    $onedriveFile = Model::getInstance('onedrivefiles');
    return $onedriveFile->deleteOneDriveFile($idCategory, $idFile);
}

/**
 * Download OneDrive info
 *
 * @param string $id_file File id
 *
 * @return boolean|stdClass|WP_Error false on response code other than 200
 *                             stdClass File info when success
 *                             WP_Error on Exception
 */
function wpfdAddonDownloadOneDriveInfo($id_file)
{
    $onedriveFile = new WpfdAddonOneDrive();
    return $onedriveFile->downloadFile($id_file);
}

/**
 * Upload OneDrive file
 *
 * @param array   $file         File info
 * @param string  $file_current File path
 * @param integer $id_category  Term id
 *
 * @return void
 */
function wpfdAddonUploadOneDriveFile($file, $file_current, $id_category)
{
    $onedrive = new WpfdAddonOneDrive();
    $pic = array();
    $pic['error'] = 0;
    $pic['name'] = $file['title'] . '.' . $file['ext'];
    $pic['type'] = '';
    $pic['size'] = $file['size'];
    $result = $onedrive->uploadFile(
        $file['title'] . '.' . $file['ext'],
        $pic,
        $file_current,
        WpfdAddonHelper::getOneDriveIdByTermId($id_category)
    );

    add_filter('wpfd_addon_onedrive_uploaded_result', function () use ($result) {
        return $result['file'];
    });
}

/**
 * Copy onedrive
 *
 * @param string  $id_file     File id
 * @param integer $id_category Term id
 *
 * @return void
 */
function wpfdAddonCopyOneDrive($id_file, $id_category)
{
    $oneDrive = new WpfdAddonOneDrive();
    $result = $oneDrive->copyFile($id_file, WpfdAddonHelper::getOneDriveIdByTermId($id_category));

    add_filter('wpfd_addon_onedrive_uploaded_result', function () use ($result) {
        return $result;
    });
}

/**
 * Move file onedrive
 *
 * @param string  $id_file     File id
 * @param integer $id_category Term id
 *
 * @return void
 */
function wpfdAddonMoveFileOneDriver($id_file, $id_category)
{
    $oneDrive      = new WpfdAddonOneDrive();
    $newCategoryId = WpfdAddonHelper::getOneDriveIdByTermId($id_category);
    $oldCategoryId = WpfdAddonHelper::getOneDriveTermIdByCloudId($id_file);
    $success       = $oneDrive->moveFile($id_file, $newCategoryId);
    if (!is_wp_error($success)) {
        // Move File params to new category
        $fileInfos = WpfdAddonHelper::getOneDriveFileInfos();
        $newFileInfos = array();
        foreach ($fileInfos as $catId => $fileInfo) {
            if ((int) $catId === (int) $oldCategoryId) {
                foreach ($fileInfo as $fileId => $fileParam) {
                    if ((string) $fileId === (string) $id_file) {
                        $newFileInfos[$id_category][$fileId] = $fileParam;
                    } else {
                        $newFileInfos[$catId][$fileId] = $fileParam;
                    }
                }
            } else {
                $newFileInfos[$catId] = $fileInfo;
            }
        }
        WpfdAddonHelper::setOneDriveFileInfos($newFileInfos);
    }
}

/**
 * OndDrive change order
 *
 * @param integer $pk Term move order
 *
 * @return void
 */
function wpfdAddonOneDriveChangeOrder($pk)
{
    Application::getInstance('WpfdAddon');
    $OnedriveCat = Model::getInstance('onedrivecategory');
    $OnedriveCat->changeOrder($pk);
}

/**
 * Uplaod onedrive version
 *
 * @param array   $data   File data
 * @param integer $termId Term id
 *
 * @return boolean
 */
function wpfdAddonUploadOneDriveVersion($data, $termId)
{
    Application::getInstance('WpfdAddon');
    $dropFile = Model::getInstance('onedrivefiles');
    return $dropFile->uploadOneDriveVersion($data, $termId);
}

include_once 'onedrive_business.init.php';
include_once WPFDA_PLUGIN_DIR_PATH . 'app/site/onedrive_business.init.php';
include_once WPFDA_PLUGIN_DIR_PATH . 'app/site/onedrive.init.php';
include_once WPFDA_PLUGIN_DIR_PATH . 'app/site/google.init.php';
include_once WPFDA_PLUGIN_DIR_PATH . 'app/site/dropbox.init.php';
