<li class="alm-layout alm-3-col <?php alm_is_last($alm_current); ?>">
   <!-- Enter your design here -->
</li>