<div class="hookname" v-show="filter.hookname">
	<p>
		<i class="fa fa-lightbulb-o" aria-hidden="true"></i>
		<?php _e( 'The unique id for this filter is:', 'ajax-load-more-filters' ); ?> <span>{{filter.hookname}}</span>
	</p>
</div>
