<li>
	<a style="border-bottom: none;" href="javascript:void(0);" class="layout" data-type="standard">
		<i class="fa fa-file-code-o" aria-hidden="true"></i>
		<?php _e('Default', 'ajax-load-more'); ?>
	</a>
</li>
<li>
	<a style="border-bottom: none;" href="javascript:void(0);" class="layout" data-type="blog-card">
		<i class="fa fa-file-code-o" aria-hidden="true"></i>
		<?php _e('Blog Card', 'ajax-load-more'); ?>
	</a>
</li>
<li>
	<a style="border-bottom: none;" href="javascript:void(0);" class="layout" data-type="blog-card-two">
		<i class="fa fa-file-code-o" aria-hidden="true"></i>
		<?php _e('Blog Card #2', 'ajax-load-more'); ?>
	</a>
</li>
<li>
	<a style="border-bottom: none;" href="javascript:void(0);" class="layout" data-type="blog-card-three">
		<i class="fa fa-file-code-o" aria-hidden="true"></i>
		<?php _e('Blog Card #3', 'ajax-load-more'); ?>
	</a>
</li>
<li>
	<a style="border-bottom: none;" href="javascript:void(0);" class="layout" data-type="cta">
		<i class="fa fa-file-code-o" aria-hidden="true"></i>
		<?php _e('Call to Action', 'ajax-load-more'); ?>
	</a>
</li>
<li>
	<a style="border-bottom: none;" href="javascript:void(0);" class="layout" data-type="card-flip">
		<i class="fa fa-file-code-o" aria-hidden="true"></i>
		<?php _e('Card Flip', 'ajax-load-more'); ?>
	</a>
</li>
<li>
	<a style="border-bottom: none;" href="javascript:void(0);" class="layout" data-type="grid">
		<i class="fa fa-file-code-o" aria-hidden="true"></i>
		<?php _e('Column Grid', 'ajax-load-more'); ?>
	</a>
</li>

<li>
   <a style="border-bottom: none;" href="https://connekthq.com/plugins/ajax-load-more/add-ons/layouts/#layouts" class="external" target="_blank"><i class="fa fa-picture-o"></i>
      <?php _e('View Designs', 'ajax-load-more'); ?>
   </a>
</li>
