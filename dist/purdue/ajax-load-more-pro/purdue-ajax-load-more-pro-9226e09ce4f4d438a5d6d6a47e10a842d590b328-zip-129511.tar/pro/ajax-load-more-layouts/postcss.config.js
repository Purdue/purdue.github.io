module.exports = {
  map: false,
  plugins: {
    'autoprefixer': {browsers: ['last 10 versions']},
  }
}
