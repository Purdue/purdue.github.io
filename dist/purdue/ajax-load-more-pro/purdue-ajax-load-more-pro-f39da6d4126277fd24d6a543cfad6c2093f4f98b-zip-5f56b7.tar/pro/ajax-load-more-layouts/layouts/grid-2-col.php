<li class="alm-layout alm-2-col <?php alm_is_odd($alm_current); ?>">
	<!-- Enter your design here -->
</li>