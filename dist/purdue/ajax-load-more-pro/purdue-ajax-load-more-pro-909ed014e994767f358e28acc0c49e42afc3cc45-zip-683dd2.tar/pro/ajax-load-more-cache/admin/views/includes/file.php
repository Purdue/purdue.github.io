<li class="file">
	<i class="fa fa-file-text-o"></i>
	<a href="<?php echo ALMCache::alm_get_cache_url() . $filepath . '/'. $file; ?>" target="_blank"><?php echo $file; ?></a>
</li>
