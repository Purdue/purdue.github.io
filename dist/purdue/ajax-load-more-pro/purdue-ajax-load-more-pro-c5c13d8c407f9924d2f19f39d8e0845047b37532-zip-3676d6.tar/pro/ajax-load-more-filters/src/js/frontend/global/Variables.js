module.exports = {
	url: "",
	alm_filtering: false,
	alm_filtering_popstate: false,
	almFilters: document.querySelector(".alm-filters-container"),
	isIE: navigator.appVersion.indexOf("MSIE 10") !== -1 ? true : false,
	pushstate: false,
};
