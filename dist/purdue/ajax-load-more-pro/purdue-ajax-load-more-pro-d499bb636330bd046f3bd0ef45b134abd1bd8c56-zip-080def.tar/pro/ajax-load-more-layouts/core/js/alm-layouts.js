jQuery(document).ready(function ($) { 
   
   // Maybe one day ¯\_(ツ)_/¯
      
});