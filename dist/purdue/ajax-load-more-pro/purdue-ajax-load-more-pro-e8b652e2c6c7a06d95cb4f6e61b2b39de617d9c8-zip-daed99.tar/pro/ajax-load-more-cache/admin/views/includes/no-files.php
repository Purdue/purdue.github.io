<?php
/**
 * No files display.
 *
 * @package ajax-load-more-cache
 */

?>
<li class="file full">
	<i class="fa fa-file-text-o"></i> <?php esc_attr_e( 'No cached files in this directory', 'ajax-load-more-cache' ); ?>
</li>
