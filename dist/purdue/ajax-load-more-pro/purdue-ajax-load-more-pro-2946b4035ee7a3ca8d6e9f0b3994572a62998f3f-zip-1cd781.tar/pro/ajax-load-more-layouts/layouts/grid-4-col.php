<li class="alm-layout alm-4-col <?php alm_is_4col_last($alm_current); ?>">
   <!-- Enter your design here -->
</li>