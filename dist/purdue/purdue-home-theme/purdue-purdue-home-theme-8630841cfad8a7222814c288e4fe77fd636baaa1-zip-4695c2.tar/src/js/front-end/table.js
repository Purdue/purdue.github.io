const tables = document.querySelectorAll("figure.wp-block-table");

tables.forEach((table) => {
  const thead = [...table.getElementsByTagName("thead")];
  const tfoot = [...table.getElementsByTagName("tfoot")];
  const tbody = [...table.getElementsByTagName("tbody")];
  let tableRowlength;
  const tableRows = [...tbody[0].getElementsByTagName("tr")];

  let tableHead;
  
  if (thead.length > 0) {
    headerCell = [...thead[0].getElementsByTagName("th")];
  }

  if (tableRows.length > 0) {
    tableRowlength = tableRows[0].getElementsByTagName("td").length;
  }

  tableRows.forEach((tableRow) => {

    let mobileTable = document.createElement("div");
    mobileTable.classList.add("wp-block-table-mobile");

    for (i = 0; i < tableRowlength; i++) {

      let mobileRow = document.createElement("div");
      const tableCell = tableRow.getElementsByTagName("td");

      if (tableCell[i] != null) {
        let mobileTableHead = document.createElement("b");
        mobileRow.classList.add("table-body");

        if (thead && thead.length > 0 && headerCell[i].innerText !== "") {
          mobileTableHead.innerHTML = headerCell[i].innerHTML;
          mobileRow.appendChild(mobileTableHead);
          mobileRow.insertAdjacentText("beforeend", ": ");
        }

        let newContent = tableCell[i].innerHTML;
        mobileRow.insertAdjacentHTML("beforeend", newContent);
        mobileTable.appendChild(mobileRow);

      }else{

      }

      table.parentElement.insertBefore(mobileTable, table);

    }
  });
});
