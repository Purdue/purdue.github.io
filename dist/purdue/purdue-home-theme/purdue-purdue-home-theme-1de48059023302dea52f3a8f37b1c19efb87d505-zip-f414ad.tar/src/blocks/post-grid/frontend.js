document.addEventListener("DOMContentLoaded", () => {
  const postGrids = document.querySelectorAll(".purdue-home-post-grid");
  const url = window.location.href;
  const regex = /[?&]([^=#]+)=([^&#]*)/g;
  if (postGrids.length > 0) {
    postGrids.forEach((grid) => {
      const forms = grid.querySelectorAll(".purdue-home-post-grid__filter");
      const selectedTermsContainer = grid.querySelector(
        ".purdue-home-cta-grid__grid__filters-selected"
      );
      const postsContainer = grid.querySelector(
        ".purdue-home-cta-grid__cards .columns"
      );
      const paginationContainer = grid.querySelector(
        ".purdue-home-pagination .nav-links"
      );
      const message = grid.querySelector(".purdue-home-cta-grid__message");
      const width = window.innerWidth;
      const queryArg = JSON.parse(
        grid.querySelector(".purdue-home-cta-grid__grid").dataset.args
      );
      let args = JSON.parse(JSON.stringify(queryArg));

      const excludeCat = args["excludeCat"];
      

      args["requestURL"] = window.location.href;
      const fields = grid.querySelectorAll(
        ".purdue-home-post-grid__filter-field"
      );
      const buttonContainer = grid.querySelector(
        ".purdue-home-post-grid__filter-button"
      );
      const submitButton = grid.querySelector(
        ".purdue-home-post-grid__filter-button .purdue-home-button"
      );
      const clearButton = grid.querySelector(
        ".purdue-home-post-grid__filter-button .form-clear-button"
      );
      // const filterButton=grid.querySelector('.purdue-home-post-grid__filter-control')
      const controlButtons = grid.querySelectorAll(".field-control");
      if (forms && forms.length > 0) {
        let match;
        let urlPara = [];
        while ((match = regex.exec(url))) {
          args = updateArgsFromURL(match[1], match[2], grid, args, 1);
          urlPara.push(match[1]);
        }
        if (urlPara.length > 0) {
          getPosts(
            postsContainer,
            paginationContainer,
            message,
            queryArg,
            args,
            grid
          );
        }
        if (fields.length > 0) {
          selectItems(
            grid,
            postsContainer,
            paginationContainer,
            message,
            fields,
            queryArg,
            args,
            selectedTermsContainer,
            buttonContainer
          );
          fields.forEach((field) => {
            field.addEventListener("change", () => {
              if (
                field.classList.contains("search-field") ||
                field.classList.contains("order-field")
              ) {
                args = updateArgs(grid, fields, queryArg, args, 1);
                getPosts(
                  postsContainer,
                  paginationContainer,
                  message,
                  queryArg,
                  args,
                  grid
                );
              }
              checkClearButton(grid, buttonContainer);
            });
            if (field.classList.contains("search-field")) {
              // Add event listener for the 'keyup' event
              field.addEventListener("keyup", function (event) {
                // Check if the 'Enter' key is pressed
                if (event.keyCode === 13) {
                  // Blur the focus from the input field to hide the keyboard
                  field.blur();
                }
              });
            }
          });
          if (submitButton) {
            submitButton.addEventListener("click", () => {
              args = updateArgs(grid, fields, queryArg, args, 1);
              getPosts(
                postsContainer,
                paginationContainer,
                message,
                queryArg,
                args,
                grid
              );
              selectItems(
                grid,
                postsContainer,
                paginationContainer,
                message,
                fields,
                queryArg,
                args,
                selectedTermsContainer,
                buttonContainer
              );
            });
          }
          if (grid.querySelector(".search-button")) {
            grid
              .querySelector(".search-button")
              .addEventListener("click", () => {
                args = updateArgs(grid, fields, queryArg, args, 1);
                getPosts(
                  postsContainer,
                  paginationContainer,
                  message,
                  queryArg,
                  args,
                  grid
                );
              });
          }
          if (grid.querySelector(".clear-button")) {
            grid
              .querySelector(".clear-button")
              .addEventListener("click", () => {
                args = updateArgs(grid, fields, queryArg, args, 1);
                getPosts(
                  postsContainer,
                  paginationContainer,
                  message,
                  queryArg,
                  args,
                  grid
                );
              });
          }
          if (clearButton) {
            clearButton.addEventListener("click", () => {
              const checkedFields = grid.querySelectorAll(
                `input[type=checkbox]:checked`
              );
              const selects = grid.querySelectorAll("select");
              if (checkedFields.length > 0) {
                checkedFields.forEach((field) => {
                  field.checked = false;
                });
              }
              if (selects.length > 0) {
                selects.forEach((field) => {
                  field.value = "";
                });
              }
              args = updateArgs(grid, fields, queryArg, args, 1);
              getPosts(
                postsContainer,
                paginationContainer,
                message,
                queryArg,
                args,
                grid
              );
              selectItems(
                grid,
                postsContainer,
                paginationContainer,
                message,
                fields,
                queryArg,
                args,
                selectedTermsContainer,
                buttonContainer
              );
            });
          }

          if (controlButtons.length > 0) {
            controlButtons.forEach((button) => {
              if (width < 1024) {
                button.setAttribute("aria-diabled", "false");
                button.setAttribute("aria-expanded", "false");
                if (button.nextElementSibling) {
                  button.nextElementSibling.classList.add("hide");
                }
              }
              button.addEventListener("click", () => {
                const width = window.innerWidth;
                if (width < 1024) {
                  toggleAccordion(button);
                }
              });
            });
          }

          window.addEventListener("resize", () => {
            const width = window.innerWidth;
            if (width >= 1024) {
              if (controlButtons.length > 0) {
                controlButtons.forEach((button) => {
                  button.setAttribute("aria-disabled", "true");
                  button.setAttribute("aria-expanded", "true");
                  if (button.nextElementSibling) {
                    button.nextElementSibling.classList.remove("hide");
                  }
                  button.classList.remove("is-open");
                });
              }
            } else {
              if (controlButtons.length > 0) {
                controlButtons.forEach((button) => {
                  button.setAttribute("aria-disabled", "false");
                  button.setAttribute("aria-expanded", "false");
                  if (button.nextElementSibling) {
                    button.nextElementSibling.classList.add("hide");
                  }
                  button.classList.remove("is-open");
                });
              }
            }
          });
        }
        forms.forEach((form) => {
          if (
            form.parentElement.classList.contains(
              "purdue-home-cta-grid__grid__filters-checkbox"
            ) &&
            form.offsetHeight + 150 > window.innerHeight
          ) {
            form.style.position = "relative";
            form.style.top = "0";
          }
        });
      }
      if (paginationContainer) {
        const paginationLinks = paginationContainer.querySelectorAll("a");
        if (paginationLinks.length > 0) {
          const current = parseInt(
            paginationContainer.querySelector(".current").innerHTML,
            10
          );
          paginationLinks.forEach((link) => {
            link.addEventListener("click", (e) => {
              e.preventDefault();
              let paged = 1;
              if (link.classList.contains("prev")) {
                paged = current - 1;
              } else if (link.classList.contains("next")) {
                paged = current + 1;
              } else {
                paged = parseInt(link.innerHTML, 10);
              }
              args = updateArgs(grid, fields, queryArg, args, paged);
              getPosts(
                postsContainer,
                paginationContainer,
                message,
                queryArg,
                args,
                grid
              );
              let sectionTop = grid.offsetTop;
              scrollTo(sectionTop, 300);
            });
          });
        }
      }
    });
  }
});



const updateArgs = (grid, fields, queryArg, args, paged) => {
  const oldArgs = JSON.parse(JSON.stringify(queryArg));
  const newArgs = JSON.parse(JSON.stringify(args));
  if (fields) {
    fields.forEach((field) => {
      const value = field.value;
      const name = field.name;
      if (value) {
        if (field.classList.contains("search-field")) {
          newArgs["p"] = value;
        } else if (field.classList.contains("postType-field")) {
          if (field.checked) {
            if (!newArgs["post_type"].includes(value)) {
              newArgs["post_type"].push(value);
            }
          } else {
            if (
              grid.querySelectorAll(
                `input[type=checkbox][name=${name}]:checked`
              ).length === 0
            ) {
              if (oldArgs["post_type"] !== "") {
                newArgs["post_type"] = [...oldArgs["post_type"]];
              } else {
                newArgs["post_type"] = "";
              }
            } else {
              if (newArgs["post_type"].includes(value)) {
                newArgs["post_type"] = newArgs["post_type"].filter(
                  (item) => item !== value
                );
              }
            }
          }
        } else if (field.classList.contains("tax-field")) {
          if (field.checked) {
            let hasCat = false;
            let count = 0;
            for (const prop in newArgs["tax_query"]) {
              if (
                newArgs["tax_query"][prop]["taxonomy"] &&
                newArgs["tax_query"][prop]["taxonomy"] === name
              ) {
                if (!newArgs["tax_query"][prop]["terms"].includes(value)) {
                  newArgs["tax_query"][prop]["terms"].push(value);
                }
                hasCat = true;
              }
              count++;
            }
            if (!hasCat) {
              newArgs["tax_query"][count] = {
                taxonomy: name,
                field: "slug",
                terms: [value],
              };
            }
          } else {
            if (
              grid.querySelectorAll(
                `input[type=checkbox][name=${name}]:checked`
              ).length === 0
            ) {
              let hasCat = false;
              for (const prop in oldArgs["tax_query"]) {
                if (
                  oldArgs["tax_query"][prop]["taxonomy"] &&
                  oldArgs["tax_query"][prop]["taxonomy"] === name
                ) {
                  for (const newprop in newArgs["tax_query"]) {
                    if (
                      newArgs["tax_query"][newprop]["taxonomy"] &&
                      newArgs["tax_query"][newprop]["taxonomy"] === name
                    ) {
                      newArgs["tax_query"][newprop] = {
                        ...oldArgs["tax_query"][prop],
                      };
                    }
                  }
                  hasCat = true;
                }
              }
              if (!hasCat) {
                for (const newprop in newArgs["tax_query"]) {
                  if (
                    newArgs["tax_query"][newprop]["taxonomy"] &&
                    newArgs["tax_query"][newprop]["taxonomy"] === name
                  ) {
                    newArgs["tax_query"][newprop] = {};
                  }
                }
              }
            } else {
              for (const prop in newArgs["tax_query"]) {
                if (
                  newArgs["tax_query"][prop]["taxonomy"] &&
                  newArgs["tax_query"][prop]["taxonomy"] === name
                ) {
                  if (newArgs["tax_query"][prop]["terms"].includes(value)) {
                    newArgs["tax_query"][prop]["terms"] = newArgs["tax_query"][
                      prop
                    ]["terms"].filter((item) => item !== value);
                  }
                }
              }
            }
          }
        } else if (field.classList.contains("order-field")) {
          if (field.checked) {
            newArgs["order"] = value;
          }
        } else if (field.classList.contains("year-field")) {
          if (value) {
            newArgs["year"] = value;
          }
        } else if (field.classList.contains("month-field")) {
          if (value) {
            newArgs["month"] = value;
          }
        }
      } else {
        if (field.classList.contains("search-field")) {
          newArgs["p"] = "";
        } else if (field.classList.contains("year-field")) {
          newArgs["year"] = "";
        } else if (field.classList.contains("month-field")) {
          newArgs["month"] = "";
        }
      }
    });
  }
  newArgs["paged"] = paged ? paged : 1;
  return newArgs;
};

const updateArgsFromURL = (name, value, grid, args, paged) => {
  const newArgs = JSON.parse(JSON.stringify(args));

  if (name === "p") {
    const searchField = grid.querySelector(
      ".purdue-home-post-grid__filter-field.search-field"
    );
    if (searchField) {
      searchField.value = value;
      newArgs["p"] = value;
    }
  } else if (name === "custom_post_type") {
    const postTypeField = grid.querySelectorAll(
      ".purdue-home-post-grid__filter-field.postType-field"
    );
    const post_types = value.replace(/%2C/g, ",").split(",");
    if (postTypeField.length > 0) {
      postTypeField.forEach((field) => {
        field.checked = false;
        post_types.forEach((type) => {
          if (field.value === type) {
            field.checked = true;
          }
        });
      });
      newArgs["post_type"] = post_types;
    }
  } else if (name === "order") {
    const orderField = grid.querySelectorAll(
      ".purdue-home-post-grid__filter-field.order-field"
    );
    if (orderField.length > 0) {
      orderField.forEach((field) => {
        if (field.value === value) {
          field.checked = true;
        } else {
          field.checked = false;
        }
      });
      newArgs["order"] = value;
    }
  } else if (name === "filter_year") {

    const yearField = grid.querySelector(`select[name=year-field]`);
    if (yearField) {
      yearField.value = value;
      newArgs["year"] = value;
    }
  } else if (name === "filter_month") {
    const monthField = grid.querySelector(`select[name=month-field]`);
    if (monthField) {
      monthField.value = convertToMonth(value);
      newArgs["month"] = convertToMonth(value);
    }
  } else {
    const elements = grid.querySelectorAll(`input[name=${name}]`);
    if (elements && elements.length > 0) {
      const tax_terms = value.replace(/%2C/g, ",").split(",");
      elements.forEach((field) => {
        field.checked = false;
        tax_terms.forEach((type) => {
          if (field.value === type) {
            field.checked = true;
          }
        });
      });
      let hasTax = false;
      let count = 0;
      for (const prop in newArgs["tax_query"]) {
        if (newArgs["tax_query"][prop]["taxonomy"] === name) {
          newArgs["tax_query"][prop]["terms"] = tax_terms;
          hasTax = true;
        }
        count++;
      }
      if (!hasTax) {
        newArgs["tax_query"][count] = {
          taxonomy: name,
          field: "slug",
          terms: tax_terms,
        };
      }
    }
  }

  newArgs["paged"] = paged ? paged : 1;
  return newArgs;
};

const getPosts = async (
  postsContainer,
  paginationContainer,
  message,
  queryArg,
  args,
  grid
) => {

  const excludeCats = queryArg.excludeCat;
  let queryArgs = JSON.parse(JSON.stringify(args));

  queryArgs.excludeCat = excludeCats;
 

  const response = await fetch(
    siteHomeURL + "/wp-json/purdue-home/v1/post-select/",
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(queryArgs),
    }
  );

 

  const result = await response
    .json()
    .catch((error) => console.error("Error parsing JSON:", error));
  const html = result["html"] || "";
  const pagination = result.pagination || "";
  const newURL = result.url || false;
  const excludeCatResult = result.excludeCat;
  postsContainer.innerHTML = html;

  if (!html) {
    message.classList.remove("hide");
  } else {
    message.classList.add("hide");
  }

  if (paginationContainer) {
    paginationContainer.innerHTML = pagination;
    const paginationLinks = paginationContainer.querySelectorAll("a");
    if (paginationLinks.length > 0) {
      const current = parseInt(
        paginationContainer.querySelector(".current").innerHTML,
        10
      );
      const fields = grid.querySelectorAll(
        ".purdue-home-post-grid__filter-field"
      );
      paginationLinks.forEach((link) => {
        link.addEventListener("click", (e) => {
          e.preventDefault();
          let paged = 1;
          if (link.classList.contains("prev")) {
            paged = current - 1;
          } else if (link.classList.contains("next")) {
            paged = current + 1;
          } else {
            paged = parseInt(link.innerHTML, 10);
          }
          args = updateArgs(grid, fields, queryArg, args, paged);
          args["requestURL"] = window.location.href;
          getPosts(
            postsContainer,
            paginationContainer,
            message,
            queryArg,
            args,
            grid
          );
          let sectionTop = grid.offsetTop;
          scrollTo(sectionTop, 300);
        });
      });
    }
  }
  history.pushState(null, "post archive", newURL);
  return response;
};

const toggleAccordion = (header) => {
  const content = header.nextElementSibling;
  header.classList.toggle("is-open");
  if (header.getAttribute("aria-expanded") === "false") {
    header.setAttribute("aria-expanded", "true");
  } else {
    header.setAttribute("aria-expanded", "false");
  }
  if (content) {
    content.classList.toggle("hide");
  }
};

const selectItems = (
  grid,
  postsContainer,
  paginationContainer,
  message,
  fields,
  queryArg,
  args,
  selectedTermsContainer,
  clearButton
) => {
  const checkboxes = Array.from(
    grid.querySelectorAll("input[type=checkbox]:checked")
  );
  const selects = Array.from(grid.querySelectorAll("select")).filter(
    (select) => select.value !== ""
  );

  const terms = [...checkboxes, ...selects];

  const buttons = selectedTermsContainer
    ? selectedTermsContainer.querySelectorAll("button")
    : [];
  if (buttons && buttons.length > 0) {
    buttons.forEach((button) => button.remove());
  }
  if (terms && terms.length > 0) {
    terms.forEach((term) => {
      let newButton = document.createElement("button");
      newButton.classList.add("filter-elected-term");
      newButton.setAttribute("data-value", term.value);
      if (term.tagName === "SELECT") {
        newButton.innerHTML = term.value;
      } else {
        newButton.innerHTML = term.parentElement.textContent;
      }
      newButton.addEventListener("click", () => {
        if (term.tagName === "SELECT") {
          term.value = "";
        } else {
          term.checked = false;
        }
        newButton.remove();
        args = updateArgs(grid, fields, queryArg, args, 1);
        getPosts(
          postsContainer,
          paginationContainer,
          message,
          queryArg,
          args,
          grid
        );
        checkClearButton(grid, clearButton);
      });
      selectedTermsContainer.appendChild(newButton);
    });
  }
  checkClearButton(grid, clearButton);
};
const checkClearButton = (grid, clearButton) => {
  const checkboxes = Array.from(
    grid.querySelectorAll("input[type=checkbox]:checked")
  );
  const selects = Array.from(grid.querySelectorAll("select")).filter(
    (select) => select.value !== ""
  );

  const terms = [...checkboxes, ...selects];

  if (terms && terms.length > 0) {
    clearButton ? clearButton.classList.remove("hide") : "";
  } else {
    clearButton ? clearButton.classList.add("hide") : "";
  }
};


// Helper function for smooth scrolling
function scrollTo(to, duration) {
  var start = window.scrollY || window.pageYOffset;
  var change = to - start;
  var startTime = new Date().getTime();

  function easeInOutQuad(t, b, c, d) {
    t /= d / 2;
    if (t < 1) return (c / 2) * t * t + b;
    t--;
    return (-c / 2) * (t * (t - 2) - 1) + b;
  }

  function animateScroll() {
    var currentTime = new Date().getTime();
    var elapsed = currentTime - startTime;

    window.scrollTo(0, easeInOutQuad(elapsed, start, change, duration));

    if (elapsed < duration) {
      requestAnimationFrame(animateScroll);
    }
  }

  animateScroll();
}
function convertToMonth(monthNumber) {
  const months = {
    "01": "January",
    "02": "February",
    "03": "March",
    "04": "April",
    "05": "May",
    "06": "June",
    "07": "July",
    "08": "August",
    "09": "September",
    10: "October",
    11: "November",
    12: "December",
  };

  return months[monthNumber];
}
