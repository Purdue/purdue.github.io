<?php
/**
 * Blocks Initializer
 *
 * @since   1.0.0
 * @package purdue-home-theme
 */
function register_layout_category( $categories ) {	
	$categories[] = array(
		'slug'  => 'purdue',
		'title' => 'Purdue'
	);
	return $categories;
}


if ( version_compare( get_bloginfo( 'version' ), '5.8', '>=' ) ) {
	add_filter( 'block_categories_all', 'register_layout_category' );
} else {
	add_filter( 'block_categories', 'register_layout_category' );
}

function purdue_load_block_init() {
	
	$blocks = array();
	
	$blocks[] = 'accordion';
	$blocks[] = 'alert-page';
	$blocks[] = 'button-bar';
	$blocks[] = 'color-hero';
	$blocks[] = 'cta-banner';
	$blocks[] = 'cta-card';
	$blocks[] = 'cta-carousel';
	$blocks[] = 'cta-grid';
	$blocks[] = 'cta-hero';
	$blocks[] = 'cta-stack';
	$blocks[] = 'cta-strap';
	$blocks[] = 'custom-container';
	$blocks[] = 'diagonal-hero';
	$blocks[] = 'featured-story';
	$blocks[] = 'hot-spot';
	$blocks[] = 'image-slider';
	$blocks[] = 'instagram-feed';
	$blocks[] = 'intro-text';
	$blocks[] = 'left-banner-layout';
	$blocks[] = 'link-cards-new';
	$blocks[] = 'link-hero';
	$blocks[] = 'media-grid';
	$blocks[] = 'mixed-rtb';
	$blocks[] = 'news-and-events';
	$blocks[] = 'path-way';
	$blocks[] = 'rtb-hero';
	$blocks[] = 'rtb-row';
	$blocks[] = 'search-block';
	$blocks[] = 'tabs-block';
	$blocks[] = 'tab-block';
	$blocks[] = 'two-column-cta';
	$blocks[] = 'video-embed';
	$blocks[] = 'post-grid';
	$blocks[] = 'content-block';
	$blocks[] = 'teritary-header';
	$blocks[] = 'purdue-quote';
	$blocks[] = 'quick-links';

	foreach($blocks as $block){
		register_block_type( __DIR__ . '/../build/blocks/' . $block);
	}
	$current_site_url = get_site_url();

	if (!function_exists('str_contains')) {
		function str_contains(string $haystack, string $needle): bool
		{
			return '' === $needle || false !== strpos($haystack, $needle);
		}
	}
	if (str_contains($current_site_url,"purdue-home-test.lndo.site") || str_contains($current_site_url,"www.purdue.edu/home") ) {
		register_block_type( __DIR__ . '/../build/blocks/canopy-hero');
    }
}
add_action( 'init', 'purdue_load_block_init' );
