<?php
/**
 * rest api end points
 *
 * @since   1.0.0
 * @package purdue-home-theme
 */

 function post_list_endpoint() {
	$namespace = 'purdue-home/v1';
	$rest_base = '/post-select/';
    register_rest_route($namespace, $rest_base, array(
        'methods' => 'POST',
        'callback' => 'purdue_get_posts',
		'permission_callback' => '__return_true',
    ));
}
function purdue_get_posts($request) {

	$taxonomies = $request['tax_query'];
    $post_type = is_array($request['post_type'])&&sizeof($request['post_type'])>0 ?$request['post_type']:"nonexistent_post_type";
    $search_query = sanitize_text_field($request['p']);
    $page = $request['paged']?$request['paged']:1;
	$order = $request['order']?$request['order']:"DESC";
	$attributes['buttonText'] = $request['button_text']?$request['button_text']:"Read More";
	$attributes['selectedTax'] = $request['use_tag'];
	$url_parts = parse_url( $request['requestURL'] );
	$path      = $url_parts['path'] ?: '';

	if(site_url( '', 'relative')){
		$path         = str_replace( site_url( '', 'relative'), '', $path );
	}//subdirectory site
	if ( function_exists( 'get_blog_details' ) ) {
		$blog_details = get_blog_details();
		$path         = str_replace( $blog_details->path, '', $path );
	}//multisite
	
	$posts_per_page = 12; // Number of posts per page

	$args = array(
        'post_type' => $post_type,
        'posts_per_page' => $posts_per_page,
		'order' => $order,
		'paged' => $page,
    );
	$urlParameters=array(
		'order' => $order,
		'paged' => $page,
    );
	$urlParameters['custom_post_type']=implode(",", $post_type);

	$args['tax_query'] = [
		'relation' => 'AND'
	];
	if ( $taxonomies) {
		foreach ( $taxonomies as $taxonomy ) {
			$tax_field = $taxonomy['taxonomy'] ?? '';
			$query_var = $taxonomy['terms'] ?? '';

			if ( empty( $tax_field ) ) {
				continue;
			}

			if ( empty( $query_var )) {
				continue;
			}

			$field = $taxonomy['field'] ?? 'slug';
			$tax = array(
					'taxonomy' => $tax_field,
					'field' => $field,
					'terms' => $query_var,
			);
			array_push($args['tax_query'], $tax);

			$urlParameters[$taxonomy['taxonomy']]=implode(",", $query_var);

		}
	}
	if ( empty( $search_query ) ) {
		unset( $args['s'] );
	}else{
		$args['s'] = $search_query;
		$urlParameters["p"]=$search_query;
	}
	$url = add_query_arg( $urlParameters, home_url( $path ) );
	global $post;
    $query = new WP_Query($args);
	ob_start();
    while ($query->have_posts()) {
        $query->the_post();
		require __DIR__ . '../../src/blocks/post-grid/inc/grid.php';
    }
	wp_reset_postdata();
    $pagination = array(
        'current_page' => intval($query->query_vars['paged']),
        'max_pages' => $query->max_num_pages,
    );
	$big = 999999999;
	$pagination = paginate_links(
		array(
			'base' => str_replace($big, '%#%', esc_url(get_pagenum_link($big))),
			'format' => '?paged=%#%',
			'current' => max(
				1,
				intval($query->query_vars['paged'])
			),
			'prev_text' => __( 'Prev', 'textdomain' ),
			'next_text' => __( 'Next', 'textdomain' ),
			'total' => $query->max_num_pages
		)
	);

    $response = array(
        'html' => ob_get_clean(),
        'pagination' => $pagination,
		'url' => $url,
		'test'=>home_url( $path ),
		'test2'=>$args,
    );
	$filter_url = home_url( '/wp-json/purdue-home/v1/post-select/' );

	$response['pagination'] = preg_replace(
		'#(' . $filter_url . ')(page/[\d]+/?)?#',
		"#",
		$response['pagination']
	);
    return rest_ensure_response($response);
}
function get_items_permission_check( $request ) {
	return current_user_can( 'edit_posts' );
}


add_action('rest_api_init', 'post_list_endpoint');

