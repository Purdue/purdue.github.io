import { __ } from '@wordpress/i18n';

import {
  PanelBody,
  PanelRow,
  CheckboxControl,
  TextControl,
  ToggleControl,
  SelectControl,
  Button,
} from '@wordpress/components';

import { InspectorControls, useBlockProps } from '@wordpress/block-editor';
const { useEffect, useState } = wp.element;
import ServerSideRender from '@wordpress/server-side-render';
const { apiFetch } = wp;

const edit = ( props )=>{
  const { className, setAttributes } = props;
  const { background, 
    header, 
    hasSelectedPostType,
    hasSelectedTax,
    hasSelectedCatTerms,
    selectedPostType, 
    selectedTax, 
    selectedTaxTerms, 
    selectedTaxFilters,
    selectedCatTerms, 
    addTaxFilter, 
    addCatFilter, 
    addPostTypeFilter, 
    addOrderFilter,
    addSearch,
    postTypeFilterName,
    buttonText,
    paddingTop, 
    paddingBottom, 
    id} = props.attributes;
  const blockProps = useBlockProps();

  const fetchPath = '/wp/v2/';
  const [postType, setPostType] = useState([]);
  const [taxes, setTax] = useState([]);
  const [taxTerms, setTaxTerms] = useState([]);
  const [catTerms, setCatTerms] = useState([]);
  useEffect(()=>{
    Promise.all([
      apiFetch({ path: `${fetchPath}types` }),
    ])
      .then((terms) => {
        let options=[];
        for (const postType in terms[0]) {
          if (terms[0].hasOwnProperty(postType)) {
            if(postType != "page" 
            && postType != "attachment" 
            && postType != "nav_menu_item" 
            && postType != "wp_block" 
            && postType != "wp_template" 
            && postType != "wp_template_part" 
            && postType != "wp_navigation"){
              let term={
                label: terms[0][postType].name,
                value: postType,
              }
              options.push(term)
            }
          }
        }
        setPostType(options);
      })
      .catch((error) => {
        // eslint-disable-next-line no-console
        console.log(error);
      });  
  },[])
  useEffect(()=>{
    Promise.all([
      apiFetch({ path: `${fetchPath}taxonomies` }),
    ])
      .then((taxonomies) => {
        let taxes=[], taxTerms=[];
        for (const tax in taxonomies[0]) {
          if(tax != "category" && tax != "nav_menu" && tax != "post_tag"){
            let tempt={
              label: taxonomies[0][tax].name,
              value: tax,
            }
            taxes.push(tempt)
            apiFetch({ path: `${fetchPath}${tax}` })
            .then((terms)=>{
                terms.forEach((term)=>{
                  console.log(term)
                  let temptTerm={
                    label: term.name,
                    value: term.slug,
                    taxonomy: taxonomies[0][tax].name,
                    taxonomy_slug: taxonomies[0][tax].slug,
                  }
                  taxTerms.push(temptTerm)
                })      
              
            })
            .catch((error) => {
              // eslint-disable-next-line no-console
              console.log(error);
            });
          }
        }
        setTax(taxes);
        setTaxTerms(taxTerms);
        console.log(taxes)
      })
      .catch((error) => {
        // eslint-disable-next-line no-console
        console.log(error);
      });  
  },[]) 
  useEffect(()=>{
    Promise.all([
      apiFetch({ path: `${fetchPath}categories?per_page=100&page=1` }),
      apiFetch({ path: `${fetchPath}categories?per_page=100&page=2` }),
    ])
      .then((terms) => {
   
        const options = [...terms[0], ...terms[1]].map((p) => {
          return {
            label: p.name,
            value: p.slug,
          };
        });
        setCatTerms(options);
      })
      .catch((error) => {
        // eslint-disable-next-line no-console
        console.log(error);
      });
  },[])
  console.log(selectedTax)
  return [
    <InspectorControls key="1">
      <PanelBody>
      <PanelRow>
          <TextControl
            label={'Add a Header to this section'}
            onChange={(header) => {
              setAttributes( { header } )
            }}
            value={header}
          />
        </PanelRow>
        <PanelRow>
          <TextControl
            label={'Button Text Shown on the Cards'}
            onChange={(buttonText) => {
              setAttributes( { buttonText } )
            }}
            value={buttonText}
          />
        </PanelRow>
      <PanelRow>
          <SelectControl
            label="Choose the background"
            value={ background }
            options={ [
              { label: 'None', value: 'none' },
              { label: 'Gold', value: 'gold' },
              { label: 'Black', value: 'black' },
              { label: 'Gray', value: 'gray' },
            ] }
            onChange={ ( background ) => setAttributes( { background } ) }
          />
        </PanelRow>
        <PanelRow>
          <SelectControl
            label="Padding at the top"
            value={ paddingTop }
            options={
              [
                { value: 'has-padding-top-none', label: 'None' },
                { value: 'has-padding-top-small', label: 'Small' },
                { value: '', label: 'Medium' },
                { value: 'has-padding-top-large', label: 'Large' },
              ]
            }
            onChange={ ( paddingTop ) => {
              setAttributes( { paddingTop } )
            } }
          />
        </PanelRow>
        <PanelRow>
          <SelectControl
            label="Padding at the bottom"
            value={ paddingBottom }
            options={
              [
                { value: 'has-padding-bottom-none', label: 'None' },
                { value: 'has-padding-bottom-small', label: 'Small' },
                { value: '', label: 'Medium' },
                { value: 'has-padding-bottom-large', label: 'Large' },
              ]
            }
            onChange={ ( paddingBottom ) => {
              setAttributes( { paddingBottom } )
            } }
          />
        </PanelRow>
        <PanelRow>
          <TextControl
            label="HTML Anchor"
            help="Enter a word without spaces to make a unique web address just for this block, called an “anchor.” It must be unique from any other anchors on the page. Then, you’ll be able to link directly to this section of your page."
            value={ id }
            onChange={ ( id ) => setAttributes( { id } ) }
          />
        </PanelRow>
        </PanelBody>
        <PanelBody initialOpen={false} key="2" title={`Select Posts`}>
          <PanelRow>
						<ToggleControl
							label="Post Types"
							checked={hasSelectedPostType}
							help={hasSelectedPostType ? 'Choose by post types' : 'Include all post types'}
							onChange={(hasSelectedPostType) => {
                setAttributes({ hasSelectedPostType})
              }}
						/>
					</PanelRow>
          {
            hasSelectedPostType?<PanelRow>
            <SelectControl
              multiple
              label="Choose Post Types"
              value={ selectedPostType }
              options={ postType }
              onChange={ ( selectedPostType ) => {
                setAttributes( { selectedPostType})
              }}
            />
          </PanelRow>:""
          }
          <PanelRow>
						<ToggleControl
							label="Categories"
							checked={hasSelectedCatTerms}
							help={hasSelectedCatTerms ? 'Choose by categories' : 'Include all categories'}
							onChange={(hasSelectedCatTerms) => {
                setAttributes({ hasSelectedCatTerms})
              }}
						/>
					</PanelRow>
          {
            hasSelectedCatTerms?
            <PanelRow>
            <SelectControl
              multiple
              label="Choose Categories"
              value={ selectedCatTerms }
              options={ catTerms }
              onChange={ ( selectedCatTerms ) => {
                setAttributes( { selectedCatTerms } ) 
              }
              }
            />
          </PanelRow>:""
          }
          <PanelRow>
						<ToggleControl
							label="Taxonomies"
							checked={hasSelectedTax}
							help={hasSelectedTax ? 'Choose by taxonomies' : 'Include all taxonomies'}
							onChange={(hasSelectedTax) => {
                setAttributes({ hasSelectedTax})
              }}
						/>
					</PanelRow>
          {
          hasSelectedTax&&taxes.length===0?
          <p style={{fontSize:"14px", color:"red",marginBottom:"16px"}}>No taxonomy found!</p>:""
        }
          {
            hasSelectedTax?<PanelRow>
            <SelectControl
              multiple
              label="Choose Taxonomies"
              value={ selectedTaxTerms }
              options={ taxTerms.map((item=>{
                return {
                  label: `${item.taxonomy}: ${item.label}`,
                  value: `${item.taxonomy_slug}::${item.value}`,
                };
              })) }
              onChange={ ( selectedTaxTerms ) => {
                setAttributes( { selectedTaxTerms } ) 
                console.log(selectedTaxTerms)
              }}
            />
          </PanelRow>:""
          }

          <PanelRow>
            <SelectControl
              label="Choose the Tag shown on the card"
              value={ selectedTax }
              options={ [...[{label: "Category", value:"category"}],...taxes] }
              onChange={ ( selectedTax ) => {
                setAttributes( { selectedTax } );  
                console.log(selectedTax)}}
            />
          </PanelRow>
        </PanelBody>
        <PanelBody initialOpen={false} key="3" title={`Add Filters`}>
        <PanelRow>
          <CheckboxControl
            label="Add a Post Type filter?"
            checked={addPostTypeFilter}
            onChange={() => {
              setAttributes({addPostTypeFilter:!addPostTypeFilter});
            }}
          />
        </PanelRow>
        {addPostTypeFilter?
        <PanelRow>
          <TextControl
            label={'Add a name for the post type filter'}
            onChange={(postTypeFilterName) => {
              setAttributes( { postTypeFilterName } )
            }}
            value={postTypeFilterName}
          />
        </PanelRow>:""}
        <PanelRow>
          <CheckboxControl
            label="Add a Category filter?"
            checked={addCatFilter}
            onChange={() => {
              setAttributes({addCatFilter:!addCatFilter});
            }}
          />
        </PanelRow>
        <PanelRow>
          <CheckboxControl
            label="Add an order filter"
            checked={addOrderFilter}
            onChange={() => {
              setAttributes({addOrderFilter:!addOrderFilter});
            }}
          />
        </PanelRow>
        <PanelRow>
          <CheckboxControl
            label="Add a search box?"
            checked={addSearch}
            onChange={() => {
              setAttributes({addSearch:!addSearch});
            }}
          />
        </PanelRow>
        <PanelRow>
          <CheckboxControl
            label="Add taxonomy filters?"
            checked={addTaxFilter}
            onChange={() => {
              setAttributes({addTaxFilter:!addTaxFilter});
            }}
          />
        </PanelRow>
        {
          addTaxFilter&&taxes.length===0&&taxTerms.length===0?
          <p style={{fontSize:"14px", color:"red",marginBottom:"16px"}}>No taxonomy found!</p>:""
        }
        {
          addTaxFilter?
            <PanelRow>
              <SelectControl
                multiple
                label="Choose the Taxonomies filters"
                value={ selectedTaxFilters }
                options={ taxes }
                onChange={ ( selectedTaxFilters ) => setAttributes( { selectedTaxFilters } ) }
              />
            </PanelRow>:""
        }
        </PanelBody>
    </InspectorControls>,
      <div {...blockProps} key="2">
    			<ServerSideRender
          block="purdue/post-grid"
          attributes={{
            header, 
            hasSelectedPostType,
            hasSelectedTax,
            hasSelectedCatTerms,
            selectedPostType, 
            selectedTax, 
            selectedTaxTerms, 
            selectedTaxFilters,
            selectedCatTerms, 
            addTaxFilter, 
            addCatFilter, 
            addPostTypeFilter, 
            addOrderFilter,
            addSearch,
            postTypeFilterName,
            buttonText,
            background,
            paddingTop, 
            paddingBottom,
          }}
        />
        </div>,
  ];
};
export default edit;