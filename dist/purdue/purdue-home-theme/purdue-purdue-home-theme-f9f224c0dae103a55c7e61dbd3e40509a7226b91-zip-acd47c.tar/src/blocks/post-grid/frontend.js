const updateArgs=(fields, args, paged)=>{
    const newArgs=JSON.parse(JSON.stringify(args)); 
    console.log(args)

    if(fields){
        fields.forEach((field)=>{
            const value=field.value
            const name=field.name
            if(value){
                if(field.classList.contains("search-field")){                
                    newArgs["p"]=value                
                }else if(field.classList.contains("postType-field")){
             
                    if(field.checked){
                        if(!newArgs["post_type"].includes(value)){
                            newArgs["post_type"].push(value)
                        }
                    }else{
                        if(newArgs["post_type"].includes(value)){
                            newArgs["post_type"] = newArgs["post_type"].filter(item => item !== value)
                        }    
                    }
                }else if(field.classList.contains("tax-field")){
                    if(field.checked){
                        let hasCat=false
                        let count=0
                        for (const prop in newArgs["tax_query"]) {
                            if(newArgs["tax_query"][prop]["taxonomy"]&&newArgs["tax_query"][prop]["taxonomy"] === name){
                                if(!newArgs["tax_query"][prop]["terms"].includes(value)){
                                    newArgs["tax_query"][prop]["terms"].push(value)
                                }
                                hasCat=true
                            }
                            count++
                        }
                        if(!hasCat){
                            newArgs["tax_query"][count]={
                                "taxonomy":name,
                                "field":"slug",
                                "terms":[value]
                            }
                        }
                    }else{
                        for (const prop in newArgs["tax_query"]) {
                            if(newArgs["tax_query"][prop]["taxonomy"]&&newArgs["tax_query"][prop]["taxonomy"] === name){
                                if(newArgs["tax_query"][prop]["terms"].includes(value)){
                                    newArgs["tax_query"][prop]["terms"] = newArgs["tax_query"][prop]["terms"].filter(item => item !== value)
                                }
                            }
                        }
                    }
                }else if(field.classList.contains("order-field")){
                    if(field.checked){
                    newArgs["order"]=value
                    }
                }
            }    
        })
    }

    newArgs["paged"]=paged?paged:1;
    console.log(newArgs)
    return newArgs;
}
const updateArgsFromURL=(name, value, form, newArgs, paged)=>{
    console.log(name)
    if(name==="p"){
        const searchField=form.querySelector(".purdue-home-post-grid__filter-field.search-field")
        if(searchField){
            searchField.value=value
            newArgs["p"]=value
        }
    }else if(name==="custom_post_type"){
        const postTypeField=form.querySelectorAll(".purdue-home-post-grid__filter-field.postType-field")
        const post_types=value.replace(/%2C/g,",").split(",");
        if(postTypeField.length>0){
            if(postTypeField.length===post_types.length+1){
                postTypeField.forEach((field)=>{
                        field.checked=true
                })
            }else{
                postTypeField.forEach((field)=>{
                    field.checked=false
                    post_types.forEach((type)=>{
                        if(field.value===type){
                            field.checked=true
                        }
                    })
            })
                newArgs["post_type"]=post_types
            }

        }  
    }else if(name==="order"){
        const orderField=form.querySelectorAll(".purdue-home-post-grid__filter-field.order-field")
        if(orderField.length>0){
            orderField.forEach((field)=>{
                if(field.value===value){
                    field.checked=true
                }else{
                    field.checked=false
                }
            })
            newArgs["order"]=value
        }  
    }else{
        const elements = document.getElementsByName(name);
        if(elements.length>0){
            const tax_terms=value.replace(/%2C/g,",").split(",");
            if(elements.length===tax_terms.length+1){
                elements.forEach((field)=>{
                        field.checked=true
                })
            }else{
                elements.forEach((field)=>{
                    field.checked=false
                    tax_terms.forEach((type)=>{
                        if(field.value===type){
                            field.checked=true
                        }
                    })
            })
            }
            let hasTax=false
            let count=0
            for (const prop in newArgs["tax_query"]) {
                if(newArgs["tax_query"][prop]["taxonomy"] === name){
                    newArgs["tax_query"][prop]["terms"]=tax_terms
                    hasTax=true
                }
                count++
            }
            if(!hasTax){
                newArgs["tax_query"][count]={
                    "taxonomy":name,
                    "field":"slug",
                    "terms":tax_terms
                }
            }
        }
    }
    newArgs["paged"]=paged?paged:1;
}
const getPosts = async(postsContainer, paginationContainer, message, args)=> { 
    const response = await fetch(siteHomeURL + '/wp-json/purdue-home/v1/post-select/', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(args),
    });  
    const result = await response.json();
    console.log(result)
    const html = result['html'] || "";
    const pagination = result.pagination || '';
    const newURL = result.url || false;
    postsContainer.innerHTML = html;
    if(!html){
        message.classList.remove('hide')
    }else{
        message.classList.add('hide')
    }

    if(paginationContainer){
        paginationContainer.innerHTML = pagination;
        const paginationLinks=paginationContainer.querySelectorAll('a')
        if(paginationLinks.length>0){
            const current=parseInt(paginationContainer.querySelector('.current').innerHTML,10)
            const form = postsContainer.parentElement.parentElement.querySelector('.purdue-home-post-grid__filter')
            const queryArg=JSON.parse(form.dataset.args);
            const fields= form.querySelectorAll(".purdue-home-post-grid__filter-field")
            paginationLinks.forEach((link)=>{
                link.addEventListener("click", (e)=>{
                    e.preventDefault();
                    let paged=1
                    if(link.classList.contains("prev")){
                        paged=current-1
                    }else if(link.classList.contains("next")){
                        paged=current+1
                    }else{
                        paged=parseInt(link.innerHTML,10)
                    }
                    const args=updateArgs(fields, queryArg, paged)   
                    args['requestURL']= window.location.href;
                    getPosts(postsContainer, paginationContainer, message, args)
                })
            })
        }
    }
    history.pushState(null, 'post archive', newURL);
    return response
}
const toggleAccordion=(header)=>{
    const content=header.nextElementSibling
    header.classList.toggle("is-open")
    if(header.getAttribute("aria-expanded")==="false"){
        header.setAttribute("aria-expanded","true")
    }else{
        header.setAttribute("aria-expanded","false")
    }
    if(content){
        content.classList.toggle("hide")
    }

}
document.addEventListener("DOMContentLoaded",()=>{
    const forms=document.querySelectorAll(".purdue-home-post-grid__filter");
    const width=window.innerWidth
    if(forms.length>0){
        forms.forEach((form)=>{
            const queryArg=JSON.parse(form.dataset.args);
            const fields= form.querySelectorAll(".purdue-home-post-grid__filter-field")
            const postsContainer=form.nextElementSibling.querySelector('.purdue-home-cta-grid__cards .columns')
            const paginationContainer=form.parentElement.querySelector('.purdue-home-pagination .nav-links')
            const message=form.parentElement.querySelector('.purdue-home-cta-grid__message')
            const submitButton=form.querySelector('.purdue-home-post-grid__filter-button')
            const filterContent=form.querySelector('.purdue-home-post-grid__filter-content')
            const filterButton=form.querySelector('.purdue-home-post-grid__filter-control')
            const controlButtons=form.querySelectorAll('.field-control')
            const url = window.location.href;
            const regex = /[?&]([^=#]+)=([^&#]*)/g;
            let match;
            const newArgs=JSON.parse(JSON.stringify(queryArg)); 
            let urlPara=[]
            while ((match = regex.exec(url))) {
                updateArgsFromURL(match[1], match[2], form, newArgs)
                urlPara.push(match[1])
                newArgs['requestURL']= window.location.href;
            }
            if(urlPara.length>0){
                getPosts(postsContainer, paginationContainer, message, newArgs)
            }
            if(fields.length>0){
                fields.forEach((field)=>{
                    field.addEventListener("change", ()=>{
                        if(field.classList.contains("select-all")){
                            const sameNameFields=form.querySelectorAll(`input[name=${field.getAttribute("name")}]`);
                            sameNameFields.forEach((elem)=>{
                                elem.checked = field.checked;                    
                            })
                        }
                        if(form.querySelectorAll(`input[type=checkbox][name=${field.getAttribute("name")}]:checked`).length===form.querySelectorAll(`input[type=checkbox][name=${field.getAttribute("name")}]`).length-1){
                            form.querySelector(`input.select-all[name=${field.getAttribute("name")}]`).checked=!form.querySelector(`input.select-all[name=${field.getAttribute("name")}]`).checked
                        }

                        if(field.classList.contains("search-field")){
                            const args=updateArgs(fields, queryArg, 1)   
                            args['requestURL']= window.location.href;
                            getPosts(postsContainer, paginationContainer, message, args)
                        }else{
                            submitButton.classList.remove('hide')
                        }
                                        
                    })
                })
                submitButton.addEventListener("click", ()=>{
                    const args=updateArgs(fields, queryArg, 1)   
                    args['requestURL']= window.location.href;
                    getPosts(postsContainer, paginationContainer, message, args)
                })
                form.querySelector(".search-button").addEventListener("click", ()=>{
                    const args=updateArgs(fields, queryArg, 1)   
                    args['requestURL']= window.location.href;
                    getPosts(postsContainer, paginationContainer, message, args)
                })
                form.querySelector(".clear-button").addEventListener("click", ()=>{
                    const args=updateArgs(fields, queryArg, 1)   
                    args['requestURL']= window.location.href;
                    getPosts(postsContainer, paginationContainer, message, args)
                })

                filterButton.addEventListener("click", ()=>{
                    toggleAccordion(filterButton)
                })
               
                controlButtons.forEach((button)=>{
                    if(width<1024){
                        button.setAttribute("aria-diabled", "false")
                        button.setAttribute("aria-expanded", "false")
                        if(button.nextElementSibling){
                            button.nextElementSibling.classList.add("hide")
                        }
                    }
                    button.addEventListener("click", ()=>{
                        const width=window.innerWidth
                        if(width<1024){
                            toggleAccordion(button)
                        }
                    })
                })
                
            window.addEventListener("resize",()=>{
                const width=window.innerWidth
                if(width>=1024){
                    controlButtons.forEach((button)=>{
                        button.setAttribute("aria-disabled", "true")
                        button.setAttribute("aria-expanded", "true")
                        if(button.nextElementSibling){
                            button.nextElementSibling.classList.remove("hide")
                        }
                        button.classList.remove("is-open")
                    })
                }else{
                    controlButtons.forEach((button)=>{
                        button.setAttribute("aria-disabled", "false")
                        button.setAttribute("aria-expanded", "false")
                        if(button.nextElementSibling){
                            button.nextElementSibling.classList.add("hide")
                        }
                        button.classList.remove("is-open")
                    })
                }
            })
            }

            const paginationLinks=paginationContainer.querySelectorAll('a')
            if(paginationLinks.length>0){
                const current=parseInt(paginationContainer.querySelector('.current').innerHTML,10)
                paginationLinks.forEach((link)=>{
                    link.addEventListener("click", (e)=>{
                        e.preventDefault();
                        let paged=1
                        if(link.classList.contains("prev")){
                            paged=current-1
                        }else if(link.classList.contains("next")){
                            paged=current+1
                        }else{
                            paged=parseInt(link.innerHTML,10)
                        }
                        const args=updateArgs(fields, queryArg, paged)   
                        args['requestURL']= window.location.href;
                        getPosts(postsContainer, paginationContainer, message, args)
                    })
                })
            }
        })
    }
})


