<?php
$target = $card["external"] ? 'target="_blank"' : 'target="_self"';
?>
<a class="<?= $cardClass; ?>" href="<?= $card["linkURL"]; ?>" <?= $target; ?>>
    <div class="flex-container flex-container--align-center">
    <?php if($attributes["showTag"]&&$card["tag"]){?>
        <p class="purdue-home-news-events__tag"><?= $card["tag"]; ?></p>
        <?php } ?>
        <p class="purdue-home-news-events__title"><?= $card["title"]; ?></p>
        <?php if($attributes["showDate"]){?>
        <p class="purdue-home-news-events__date">
            <?php
            if ($card["date"]) {
                ?>
                <span class="date"><?= $card["date"]; ?></span>
                <?php
            }
            if ($card["time"]) {
                ?>
                <span class="time"><?= $card["time"]; ?></span>
                <?php
            }
            ?>
        </p>
        <?php } ?>
    </div>
</a>