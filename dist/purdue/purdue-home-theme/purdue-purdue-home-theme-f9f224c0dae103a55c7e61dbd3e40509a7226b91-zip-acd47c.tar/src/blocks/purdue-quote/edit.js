import { __ } from "@wordpress/i18n";

import {
  PanelBody,
  PanelRow,
  CheckboxControl,
  TextControl,
  SelectControl,
  Button,
} from "@wordpress/components";
import { InspectorControls, useBlockProps, InnerBlocks, RichText } from "@wordpress/block-editor";
const BLOCKS_TEMPLATE = [
  [ 'core/paragraph', { placeholder: 'Quote content copy' } ],
];

import './editor.scss';
const edit = ( props )=>{
  const blockProps = useBlockProps();
  const { className, setAttributes } = props;
  const { alignment,citeName, citeTitle, paddingTop, paddingBottom, removeSidePadding, id} = props.attributes;

  return [
    <InspectorControls key="1">
      <PanelBody>
       <PanelRow>
          <SelectControl
            label="Alignment"
            value={ alignment }
            options={
              [
                { value: 'left', label: 'Left' },
                { value: 'center', label: 'Center' },
              ]
            }
            onChange={ ( alignment ) => {
              setAttributes( { alignment } )
            } }
          />
        </PanelRow>
        <PanelRow>
          <SelectControl
            label="Padding top"
            value={ paddingTop }
            options={
              [
                { value: 'has-padding-top-none', label: 'None' },
                { value: 'has-padding-top-small', label: 'Small' },
                { value: '', label: 'Medium' },
                { value: 'has-padding-top-large', label: 'Large' },
              ]
            }
            onChange={ ( paddingTop ) => {
              setAttributes( { paddingTop } )
            } }
          />
        </PanelRow>
        <PanelRow>
          <SelectControl
            label="Padding bottom"
            value={ paddingBottom }
            options={
              [
                { value: 'has-padding-bottom-none', label: 'None' },
                { value: 'has-padding-bottom-small', label: 'Small' },
                { value: '', label: 'Medium' },
                { value: 'has-padding-bottom-large', label: 'Large' },
              ]
            }
            onChange={ ( paddingBottom ) => {
              setAttributes( { paddingBottom } )
            } }
          />
        </PanelRow>
        <PanelRow>
        <CheckboxControl
          label="Remove side padding?"
          help="You can remove the side paddings when use this block inside another container block"
          checked={removeSidePadding}
          onChange={() => {
            setAttributes( { removeSidePadding: !removeSidePadding } )
          }}
        />
      </PanelRow>
        <PanelRow>
          <TextControl
            label="HTML Anchor"
            help="Enter a word without spaces to make a unique web address just for this block, called an “anchor.” It must be unique from any other anchors on the page. Then, you’ll be able to link directly to this section of your page."
            value={ id }
            onChange={ ( id ) => setAttributes( { id } ) }
          />
        </PanelRow>
        </PanelBody>
    </InspectorControls>,
    <div {...blockProps} key="2">
    <div className={`purdue-home-quote purdue-home-quote-editor`}>   
        <div className={`section ${paddingTop?` ${paddingTop}`:''}${paddingBottom?` ${paddingBottom}`:''}${removeSidePadding?" has-no-sidepadding":""}${alignment==="center"?" align-center":""}`}>  
          <div className={`container`}>           
              <blockquote>
                  <InnerBlocks
                    template={ BLOCKS_TEMPLATE }
                    templateLock={ false }
                  />
              </blockquote>
              <RichText
                tagName="p"
                value={citeName}
                className={`purdue-home-quote__name`}
                onChange={(citeName) => {
                  setAttributes({ citeName});
                }}
                placeholder="Add attribution name"
              ></RichText>
              <RichText
                tagName="p"
                value={citeTitle}
                className={`purdue-home-quote__title`}
                onChange={(citeTitle) => {
                  setAttributes({ citeTitle});
                }}
                placeholder="Add attribution title"
              ></RichText>
          </div>
        </div>
    </div></div>,
  ];
}
export default edit;