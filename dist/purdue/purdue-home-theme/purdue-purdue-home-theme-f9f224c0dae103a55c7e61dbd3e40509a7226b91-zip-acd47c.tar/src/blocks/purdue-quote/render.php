<?php
$id = $attributes['id'] != "" ? ' id="' . $attributes['id'] . '"' : "";
?>
<div <?= $id ?> class="purdue-home-quote <?= $attributes['className'] ?>">
    <?php
    $blockclass = 'section';
    if ($attributes['paddingTop']) {
        $blockclass .= ' ' . $attributes['paddingTop'];
    }
    if ($attributes['paddingBottom']) {
        $blockclass .= ' ' . $attributes['paddingBottom'];
    }
    if ($attributes['removeSidePadding']) {
        $blockclass .= ' has-no-sidepadding';
    }
    if ($attributes['alignment']=="center") {
        $blockclass .= ' align-center';
    }
    ?>
    <div class="<?= $blockclass ?>">
        <div class="container">
            <blockquote>
                <?= $content; ?>
            </blockquote>
            <?php if($attributes['citeName']){
            ?>
            <p class="purdue-home-quote__name"><?= $attributes['citeName']; ?></p>
            <?php
            }
            ?>
            <?php if($attributes['citeTitle']){
            ?>
            <p class="purdue-home-quote__title"><?= $attributes['citeTitle']; ?></p>
            <?php
            }
            ?>
        </div>
    </div>
</div>
