<?php
$id = $attributes['id'] != "" ? ' id="' . $attributes['id'] . '"' : "";
?>
<div<?= $id ?> class="purdue-home-video-embed <?= $attributes['className'] ?>">
    <?php
    $blockclass = 'section';
    $blockclass .= ' has-' . $attributes['background'] . '-background';

    if ($attributes['paddingTop']) {
        $blockclass .= ' ' . $attributes['paddingTop'];
    }
    if ($attributes['paddingBottom']) {
        $blockclass .= ' ' . $attributes['paddingBottom'];
    }
    if ($attributes['removeSidePadding']) {
        $blockclass .= ' has-no-sidepadding';
    }
    ?>
    <div class="<?= $blockclass ?>">
        <div class="container">
            <?php if ($attributes['header'] != "") : ?>
                <div class="tagged-header-container">
                    <h2 class="tagged-header purdue-home-video-embed__header"><?= $attributes["header"] ?></h2>
                </div>
            <?php endif; ?>

            <?php
            preg_match('%(?:youtube(?:-nocookie)?.com/(?:[^/]+/.+/|(?:v|e(?:mbed)?)/|.*[?&]v=)|youtu.be/)([^"&?/ ]{11})%i', $attributes["youtubeLink"], $match);
            $videoId = print_r($match[1], TRUE);

            if ($videoId) :
                $cardClass = "purdue-home-cta-card purdue-home-cta-card--horizontal";
                $cardClass .= " purdue-home-cta-card--video";
            ?>
                <div class="<?= $cardClass ?>">
                    <div class="image is-16by9">
                        <?php if ($attributes['mediaType'] == "image") : ?>
                            <img class="purdue-home-background-image" alt="<?= $attributes["mediaAlt"] ?>" src="<?= $attributes["mediaURL"] ?>" />
                        <?php elseif ($attributes['mediaType'] == "video") : ?>
                            <video preload="metadata" class="purdue-home-background-image" title="<?= $attributes['mediaTitle'] ?>" muted playsinline="">
                                <source src="<?= $attributes["mediaURL"] ?>#t=0.1">
                            </video>
                        <?php endif; ?>
                    </div>
                    <div class="flex-container flex-container--align-center">
                        <span class="cta-link purdue-home-cta-card__link">Watch Video</span>
                        <img class="cta-icon cta-icon--play" src="<?php echo get_template_directory_uri() ?>/imgs/play_icon_gold.svg" alt="">                                       
                    </div>
                    <?php
                    $protocol = isset($_SERVER['HTTPS']) ? 'https://' : 'http://';
                    $origin = $protocol . $_SERVER['HTTP_HOST'];
                    $youtubeurl = 'https://www.youtube.com/embed/' . $videoId . '?rel=0&autoplay=1&enablejsapi=1&mute=1&origin=' . $origin;
                    ?>
                    <div class="iframe-container is-sr-only">
                        <div class="youtube-video" id="<?= $videoId ?>" data-title="<?= $attributes['mediaTitle'] ?>" data-src="<?= $youtubeurl ?>"></div>
                    </div>
                </div>
            <?php else : ?>
                <p>Please enter a valid Youtube URL.</p>
            <?php endif; ?>
        </div>
    </div>
</div>
