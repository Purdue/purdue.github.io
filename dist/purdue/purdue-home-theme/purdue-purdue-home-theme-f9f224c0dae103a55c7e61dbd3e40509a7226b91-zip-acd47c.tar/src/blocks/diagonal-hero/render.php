<?php
    $id = $attributes['id'] != "" ? ' id="' . $attributes['id'] . '"' : "";
?>

<div <?= $id ?> class="purdue-home-diagonal-hero has-<?= $attributes['background'] ?>-background <?= $attributes['className'] ?>">
    <div class="section has-padding-top-large has-padding-bottom-large">
        <div class="container">
            <div class="purdue-home-diagonal-hero__content">

                <?php 
                    if ($attributes['subheader'] != ""): 
                        if ($attributes['background'] != "gold"){
                            $subheaderClass="purdue-home-hero__subheader tagged-header tagged-header--gold purdue-home-diagonal-hero__subheader";
                        }else{
                            $subheaderClass="purdue-home-hero__subheader tagged-header purdue-home-diagonal-hero__subheader"; 
                        }
                ?>
                    <p class="<?= $subheaderClass ?>"><?= $attributes['subheader'] ?></p>
                <?php endif; ?>

                <?php if ($attributes['header'] != ""): ?>
                    <?php $class = 'second-level-page-heading purdue-home-diagonal-hero__header'; ?>
                    <h1 class="<?= $class ?>"><?= $attributes['header'] ?></h1>
                <?php endif; ?>

                <?php if ($attributes['subtext'] != ""): ?>
                    <p class="purdue-home-diagonal-hero__subtext"><?= $attributes['subtext'] ?></p>
                <?php endif; ?>

                <?php if ($attributes['links'] && sizeof($attributes['links']) > 0 && $attributes['links'][0]['linkURL']): ?>
                    <ul class="purdue-home-button-list">
                        <?php foreach ($attributes['links'] as $key => $link): ?>
                            <?php
                            $target = $link["external"] ? 'target="_blank"' : 'target="_self"';
                            $buttonClass = "purdue-home-button";
                            if ($link["buttonColor"] == "black") {
                                $buttonClass .= " purdue-home-button--black";
                            }elseif($link["buttonColor"] == "white") {
                                $buttonClass .= " purdue-home-button--white";
                            }
                            $liClass = $link["fullWidth"] ? "purdue-home-button-wrap--full" : "";
                            ?>
                            <li class="<?= $liClass ?>"><a class="<?= $buttonClass ?>" href="<?= $link["linkURL"] ?>" <?= $target ?>><?= trim($link["linkText"]) ?></a></li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>

            </div>
        </div>
    </div>

    <div class="image">
        <?php if ($attributes['mediaType'] == "image"): ?>
            <img alt="<?= $attributes["mediaAlt"] ?>" src="<?= $attributes["mediaURL"] ?>"/>
        <?php elseif ($attributes['mediaType'] == "video"): ?>
            <video preload="metadata" title="<?= $attributes['mediaTitle'] ?>" muted playsinline="">
                <source src="<?= $attributes["mediaURL"] ?>#t=0.1">
            </video>
        <?php endif; ?>
    </div>
</div>
