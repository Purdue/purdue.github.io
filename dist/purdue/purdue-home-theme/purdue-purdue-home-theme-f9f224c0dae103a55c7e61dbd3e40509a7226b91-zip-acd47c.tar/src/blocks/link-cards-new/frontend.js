//link_cards
import {CustomActiveClass, check_resize} from '../../../src/js/front-end/slider';
import Glide from '@glidejs/glide';

document.addEventListener("DOMContentLoaded",function(){

  const link_cards = document.querySelectorAll('.purdue-home-link-cards__slider');

  if(link_cards && link_cards.length>0){
    for (let i = 0; i < link_cards.length; i++) {
      const type = link_cards[i].classList.contains('purdue-home-link-cards__slider--loop')?"carousel":"slide";
          let glide = new Glide(link_cards[i], {
            type: type,
            perView: 4,
            gap:24,
            breakpoints: {
              1407:{
                perView: 3,
              },
              1024:{
                perView: 2,
              },
              767: {
                perView: 1,
              },
            },
          });
          const nextButton = link_cards[i].querySelector('.arrow--left');
          const prevButton = link_cards[i].querySelector('.arrow--right');
          nextButton.addEventListener('click', function (event) {
            event.preventDefault();	  
            glide.go('<');
          })
          
          prevButton.addEventListener('click', function (event) {
            event.preventDefault();	  
            glide.go('>');
          })
          glide.slides_count = link_cards[i].querySelectorAll('.glide__slide').length;
          glide.controls = link_cards[i].querySelector('.slider-controls');
          glide.on('resize', () => {
            check_resize(glide);
          });

          glide.mount({CustomActiveClass,});
          check_resize(glide);
    }
  }
});