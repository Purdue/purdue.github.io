import Glide from '@glidejs/glide';
import { siblings } from "@glidejs/glide/src/utils/dom";


const check_resize = (glide) => {
    if (glide.slides_count <= glide.settings.perView) {
        glide.update({startAt: 0}).disable();
        glide.controls.classList.add('hidden');
    } else {
        glide.enable();
        glide.controls.classList.remove('hidden');
    }
};

const CustomActiveClass = (Glide, Components, Events) => {
    const Component = {
      mount() {
        this.changeActiveSlide();
      },
  
      changeActiveSlide() {
        const slide = Components.Html.slides[Glide.index];
        const bullets = Components.Controls.items[0];
        const bullet = [...bullets.children].find(
          (bullet) => bullet.getAttribute("data-glide-dir") === `=${Glide.index}`
        );
  
        bullet.classList.remove("is-next", "is-prev");
        bullet.classList.add("is-active");
        slide.classList.remove("is-next", "is-prev");
        slide.classList.add("is-active");
  
        siblings(slide).forEach((sibling) => {
          sibling.classList.remove("is-active", "is-next", "is-prev");
        });
        siblings(bullet).forEach((sibling) => {
          sibling.classList.remove("is-active", "is-next", "is-prev");
        });
  
        if (slide.nextElementSibling) {
          slide.nextElementSibling.classList.add("is-next");
        }
  
        if (slide.previousElementSibling) {
          slide.previousElementSibling.classList.add("is-prev");
        }
        if (bullet.nextElementSibling) {
          bullet.nextElementSibling.classList.add("is-next");
        }
  
        if (bullet.previousElementSibling) {
          bullet.previousElementSibling.classList.add("is-prev");
        }
      },
    };
  
    Events.on("run", () => {
      Component.changeActiveSlide();
    });
  
    return Component;
  };

export {check_resize, CustomActiveClass};