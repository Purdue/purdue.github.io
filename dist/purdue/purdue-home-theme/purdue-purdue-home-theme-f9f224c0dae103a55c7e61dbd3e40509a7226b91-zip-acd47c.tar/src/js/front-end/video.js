const youtube = [...document.querySelectorAll(".youtube-video")];

if (youtube && youtube.length > 0) {
  const tag = document.createElement("script");
  tag.src = "https://www.youtube.com/iframe_api";
  const firstScriptTag = document.getElementsByTagName("script")[0];
  firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);
}

//cta caard: on hover preview, on click play youtube
const cta_cards = document.querySelectorAll(".purdue-home-cta-card");
if (cta_cards.length > 0) {
  let players = [];
  cta_cards.forEach((card) => {
    const card_video_element = card.querySelector("video");
    if (card_video_element !== null) {
      card_video_element.loop = true; // Make sure the video loops
      card_video_element.muted = true; // Make sure the video is muted
      card.addEventListener("mouseover", () => {
        card_video_element.play();
      });

      card.addEventListener("mouseout", () => {
        card_video_element.pause();
      });
    }
    const card_iframe_element = card.querySelector(".youtube-video");
    const card_iframe_container = card.querySelector(".iframe-container");
    const card_text_container = card.querySelector(".flex-container");
    const card_background_container = card.querySelector(".image");

    if (card_iframe_element) {
      let checkYT = setInterval(function () {
        if (YT && YT.loaded) {
          let player = new YT.Player(card_iframe_element.id, {
            height: "390",
            width: "640",
            videoId: card_iframe_element.id,
            playerVars: {
              rel: 0,
              html5: 1,
            },
            events: {
              onReady: function (event) {
                card.addEventListener("click", (event) => {
                  event.preventDefault();
                  card_text_container.style.display = "none";
                  card_background_container.style.display = "none";
                  card_iframe_container.classList.remove("is-sr-only");
                  if (player) {
                    setTimeout(() => player.playVideo(), 500);
                  }
                });
              },
              onStateChange: function (event) {
                setTimeout(function () {
                  if (
                    event.target.getPlayerState() == 0 ||
                    event.target.getPlayerState() == 2
                  ) {
                    card_text_container.style.display = "flex";
                    card_background_container.style.display = "block";
                    card_iframe_container.classList.add("is-sr-only");
                  }
                }, 500);
              },
            },
          });
          players.push({
            id: card_iframe_element.id,
            player: player,
          });
          clearInterval(checkYT);
        }
      }, 1000);
      checkYT;
    }
  });
}

//cta banner: auto play when in view
document.addEventListener("DOMContentLoaded", function () {
  const ctaBanner = document.querySelectorAll(
    ".purdue-home-cta-banner, .purdue-home-media-grid"
  );

  if ("IntersectionObserver" in window) {
    let lazyBackgroundObserver = new IntersectionObserver(function (
      entries,
      observer
    ) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.play();
          entry.target.loop = true;
          lazyBackgroundObserver.unobserve(entry.target);
        }
      });
    });

    ctaBanner.forEach((banner) => {
      const videos = banner.querySelectorAll("video");
      if (videos.length > 0) {
        videos.forEach((video) => {
          lazyBackgroundObserver.observe(video);
        });
      }
    });
  }
});
