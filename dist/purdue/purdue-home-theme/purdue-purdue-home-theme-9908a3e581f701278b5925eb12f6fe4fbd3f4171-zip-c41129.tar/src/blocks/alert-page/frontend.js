window.addEventListener("load",function(){
const alertPage=document.querySelector('.alert-page-widget')
if(alertPage){
        // Check if the user has already seen the modal
        if (!localStorage.getItem('seenModal')) {
            const alertPage = document.querySelector('.alert-page-widget');
            if (alertPage) {
                alertPage.classList.add('is-active');
                localStorage.setItem('seenModal', 'true');
            }
        }
}
})
