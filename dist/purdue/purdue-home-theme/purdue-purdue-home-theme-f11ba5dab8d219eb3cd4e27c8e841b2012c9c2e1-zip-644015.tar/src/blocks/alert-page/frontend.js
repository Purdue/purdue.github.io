const alertPage=document.querySelector('.alert-page-widget')
if(alertPage){
    alertPage.classList.add('is-active')
}
