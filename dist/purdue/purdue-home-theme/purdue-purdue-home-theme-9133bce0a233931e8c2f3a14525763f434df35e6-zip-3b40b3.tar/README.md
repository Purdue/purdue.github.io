# Purdue WordPress Theme
WordPress theme based on Purdue University's digital brand standards.

## Getting Started

### Prerequisites

In order to effectively use this theme please become familar with the following materials
1. [The Gutenberg editing experience](https://wordpress.org/gutenberg/)
2. [Developers Adoption Guide - WordPress Gutenberg Editor](https://pantheon.io/sites/default/files/pdf/Pantheon-ebook-GutenbergAdoptionGuide.pdf)
3. [Purdue Digital Brand Standards](https://www.purdue.edu/brand-studio/digital/)

### Installing

The preferred method of using this theme is by including it in the composer.json file of your project.

```json
"repositories": [
  { "type": "composer", "url": "https://wpackagist.org" },
  { "type": "composer", "url": "https://purdue.github.io" }
],
"require": {
  "composer/installers": "^2.0",
  "purdue/purdue-home-theme": "1.1.*"
}
```

`composer/installers` is required — it is what places the theme in `wp-content/themes`.

If your project does not use composer for dependency management, the theme can be installed by adding the folder to the wp-content/themes folder in your WordPress install.  For the best experience, you should also install [BoilerUp WP](https://github.com/Purdue/boilerup-wp) plugin.

## Releasing

1. `npm run build` and commit the `build/` output — it is tracked, and it is what ships.
2. Set the same `X.Y.Z` in `style.css` (`Version:`) and `package.json` (`version`). Commit as `Version Bump X.Y.Z` on `main`.
3. Tag `X.Y.Z` and push the tag. Composer reads versions from tags.
4. Publish to the Composer repo, [Purdue/purdue.github.io](https://github.com/Purdue/purdue.github.io) (`master` branch, served by GitHub Pages):

   ```
   satis build satis.json <pages-checkout> \
     --repository-url 'git@github.com:Purdue/purdue-home-theme/'
   ```

   Commit the output as `Repo Updated DD/MM/YYYY HH:MM:SS` and push. Pages publishes in ~5 minutes.

`--repository-url` scopes the rebuild to this theme. **Do not run a full `satis build`** unless you know you have the current `satis.json`: releases without a `composer.json` (Gravity Forms, for one) are declared inline in it, the copy on that repo's `main` branch is out of date and omits them, and a full rebuild silently drops whatever it cannot see.
