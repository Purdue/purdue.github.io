<div class="column is-half-tablet is-4-desktop">

    <?php
    $cardClass = "purdue-home-cta-card";
    $figClass = "image";
    $containerClass = "flex-container";
    if($attributes['cardType'] == "faculty"){
        $cardClass .= " purdue-home-cta-card--faculty";
        $figClass .= " is-square";
        $containerClass .= " flex-container--align-bottom";
    }else{
        $cardClass .= " purdue-home-cta-card--story";
        $figClass .= " is-16by9";
        $containerClass .= " flex-container--align-center";
    }
    $postType = $post->post_type;
    if($postType == "post"){
        $postType = "article";
    }
    if($postType == "podcast" || $postType == "rkv_podcast"){
        $postType = "podcast";
    }
    if($postType == "rkv_video" || $postType == "video"){
        $postType = "video";
    }
    $cardClass.=" ".$postType;
    $external = function_exists('get_field') ? get_field('is_this_post_an_external_link'):null;
    $target = $external != null && $external[0]=="Yes" ? 'target="_blank"' : 'target="_self"';
    ?>
    <a class="<?= $cardClass ?>" href="<?= the_permalink() ?>" <?= $target; ?>>
    <?php if(get_post_thumbnail_id($post->ID)){ ?>
        <figure class="<?= $figClass ?>">
            <img class="purdue-home-background-image" alt="<?= get_post_meta(get_post_thumbnail_id($post->ID), '_wp_attachment_image_alt', true) ?>" src="<?= wp_get_attachment_url(get_post_thumbnail_id($post->ID)) ?>"/>
        </figure>
    <?php } ?>
        <div class="<?= $containerClass ?>">
            <?php
            if ((purdue_post_tag( $post->ID, $attributes['selectedTax'] ) || $attributes['postTypeTag']) && $attributes['cardType'] != "faculty") {
            ?>
                <p class="purdue-home-cta-grid__card-subtitle">
                    <?php if($attributes['postTypeTag']){ ?>
                        <span class="purdue-posttype-tag"><?php echo $postType; ?></span>
                    <?php
                        }
                    ?>
                <?php echo purdue_post_tag( $post->ID, $attributes['selectedTax'] );?></p>
            <?php
            }
            ?>
            <p class="purdue-home-cta-grid__card-title"><?= get_the_title() ?></p>
            <?php
            if ($attributes['cardType'] != "faculty") {
            ?>
            <div class="purdue-home-cta-grid__card-subtext"><?php echo purdue_get_excerpt(); ?></div>
            <button class="purdue-home-button"><?= $attributes['buttonText'] ?></button>
            <?php
            }else{
                $tax_terms = wp_get_object_terms( $post->ID, $attributes['selectedTax'] );
                if(sizeof($tax_terms)>0){
            ?>
            <div class="purdue-home-cta-grid__tags">
                <?php 
                foreach ($tax_terms as $key => $tax_term) {
                    echo $tax_term -> name;
                    if($key < sizeof($tax_terms) -1){
                        echo ", ";
                    }
                }
                ?>
            </div>
            <?php
                }
            }
            ?>
        </div>
    </a>
</div>
