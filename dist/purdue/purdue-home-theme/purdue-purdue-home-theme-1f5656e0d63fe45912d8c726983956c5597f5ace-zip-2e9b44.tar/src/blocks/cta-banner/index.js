import { registerBlockType } from '@wordpress/blocks';
import edit from './edit';
import metadata from './block.json';
import icon from './icon.js';

registerBlockType( metadata.name, {	
	icon:icon, 
	edit:edit
});
