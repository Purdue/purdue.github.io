<div class="modal-background"></div>
<div class="modal-close" aria-label="close"></div>
<div class="modal-content">
    <?php if ($attributes['imgURL'] != ""): ?>
        <img class="alert-page__image" src="<?= $attributes['imgURL'] ?>" alt="<?= $attributes['imgAlt'] ?>"/>
    <?php endif; ?>

    <?php if ($attributes['tag'] != ""): ?>
        <p class="alert-page__tag"><?= $attributes['tag'] ?></p>
    <?php endif; ?>

    <?php if ($attributes['header'] != ""): ?>
        <h2 class="alert-page__header"><?= $attributes['header'] ?></h2>
    <?php endif; ?>

    <?php if ($attributes['subtext'] != ""): ?>
        <p class="alert-page__subtext"><?= $attributes['subtext'] ?></p>
    <?php endif; ?>

    <?php if ($attributes['linkURL'] != ""):
        $target = $attributes["external"] ? 'target="_blank"' : 'target="_self"';
    ?>
        <a class="alert-page__link purdue-home-button" href="<?= $attributes['linkURL'] ?>" <?= $target ?>><?= $attributes['linkText'] ?></a>
    <?php endif; ?>
</div>