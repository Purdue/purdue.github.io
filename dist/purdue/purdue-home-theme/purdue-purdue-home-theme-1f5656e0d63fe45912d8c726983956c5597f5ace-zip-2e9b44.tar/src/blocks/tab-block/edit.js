import { InnerBlocks, useBlockProps } from "@wordpress/block-editor";
const BLOCKS_TEMPLATE = [
  [ 'core/paragraph', { placeholder: 'Add tab content' } ],
];

const edit = ( props ) => {
    const blockProps = useBlockProps();
    return [
        <div {...blockProps}>
        <div
            className={ `purdue-home-tabs__panel ${props.attributes.editorSelected ?" active" : ""}` }
            role="tabpanel"
        >
            <InnerBlocks
                template={ BLOCKS_TEMPLATE }
                templateLock={ false }
                templateInsertUpdatesSelection={ false }
            />
        </div>
        </div>
    ];
}
export default edit;