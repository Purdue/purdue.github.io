<?php 
/**
 * Server-side rendering of the block.
 *
 * @package WordPress
 */
	
function card($card,$type, $hasType, $hasTag, $background){
    $cardClass="purdue-home-cta-card";
    if($type=="simple"){
        $cardClass.=" has-content-bottom";
    }elseif($type=="story"){
        $cardClass.=" purdue-home-cta-card--story";
        if(array_key_exists("postType", $card) && $card["postType"]){
            $cardClass.=" post-type-".$card["postType"];
        }
    }else{
        $cardClass.=" purdue-home-cta-card--stack";
    }
    
    $contentClass="flex-container";
    $output = '';
    if($type=="story"){
        $contentClass.=" flex-container--align-center";
        if($background=="black"){
            $contentClass.=" has-black-background";
        }
        if(!$card["inculdeDesc"]){
            $contentClass.=" has-no-excerpt";
        }
    }elseif($type=="faculty"){
        $contentClass.=" flex-container--faculty";
    }else{
        $contentClass.=" flex-container--align-bottom";
    }
    if($card["linkURL"]!=""){
        $target = isset($card["external"]) && $card["external"] ? "_blank" : "_self";
        $output.='<a class="'.$cardClass.'" href="'.$card["linkURL"].'" target='.$target.'>';  
        $imageClass="image";
        if($type=="simple" || $type=="story"){
            $imageClass.=" is-16by9";
        }else{
            $imageClass.=" is-square";
        }
        $output.='<figure class="'.$imageClass.'">';
        $output.='<img alt="'.$card["mediaAlt"].'" src="'.$card["mediaURL"].'"/>';
        $output.='</figure>';
        $output.='<div class="'.$contentClass.'">';
        if($type=="story" && ($card["tag"] || $card["postType"])&&($hasType||$hasTag)){
            $output.='<p class="purdue-home-cta-grid__card-subtitle">';
        }
        if($type=="story" && $card["postType"]&&$hasType){
            $output.='<span class="purdue-posttype-tag">'.$card["postType"].'</span>';
        }
        if($type=="story" && $card["tag"]&&
        $hasTag){
            $output.='<span class="purdue-tax-tag">'.$card["tag"].'</span>';
        }
        if($type=="story" && ($card["tag"] || $card["postType"])&&($hasType||$hasTag)){
            $output.='</p>';
        }
        if($type=="story"&& $card["title"]){
        $output.='<p class="purdue-home-cta-grid__card-title">'.$card["title"].'</p>';
        }
        if($type=="story"&& $card["subtext"]&& $card["inculdeDesc"]){
            $output.='<div class="purdue-home-cta-grid__card-subtext">'.$card["subtext"].'</div>';
        }
        if($type=="story"){
            $output.='<button class="purdue-home-button">Learn More</button>';
        }
        if($type=="faculty"&& $card["name"]){
            $output.='<p class="purdue-home-cta-grid__card-name">'.$card["name"].'</p>';
        }
        if($type=="faculty"&& $card["titleLine1"]){
            $output.='<p class="purdue-home-cta-grid__card-titleline">'.$card["titleLine1"].'</p>';
        }
        if($type=="faculty"&& $card["titleLine2"]){
            $output.='<p class="purdue-home-cta-grid__card-titleline">'.$card["titleLine2"].'</p>';
        }
        if($type=="faculty"&& $card["email"]){
            $output.='<p class="purdue-home-cta-grid__card-email" href="mailto:'.trim($card["email"]).'">'.trim($card["email"]).'</p>';
        }
        if($type=="faculty"&& $card["address"]){
            $output.='<p class="purdue-home-cta-grid__card-address">'.trim($card["address"]).'</p>';
        }
        if($type=="faculty"&& $card["phone"]){
            $output.='<p class="purdue-home-cta-grid__card-phone" href="tel://'.trim($card["phone"]).'">'.trim($card["phone"]).'</p>';
        }
        if($type=="simple"&& $card["title"]){
            $output.='<p class="purdue-home-cta-grid__card-title">'.$card["title"].'</p>';
        }
        if($type=="simple"&& $card["subtext"]){
            $output.='<p class="purdue-home-cta-grid__card-subtext">'.$card["subtext"].'</p>';
        }
        $output.='</div></a>';
    }else{
        $output.='<div class="'.$cardClass.'">';  
        $imageClass="image";
        if($type=="simple" || $type=="story"){
            $imageClass.=" is-16by9";
        }else{
            $imageClass.=" is-square";
        }
        $output.='<figure class="'.$imageClass.'">';
        $output.='<img alt="'.$card["mediaAlt"].'" src="'.$card["mediaURL"].'"/>';
        $output.='</figure>';
        $output.='<div class="'.$contentClass.'">';
        if($type=="story" && ($card["tag"] || $card["postType"])&&($hasType||$hasTag)){
            $output.='<p class="purdue-home-cta-grid__card-subtitle">';
        }
        if($type=="story" && $card["postType"]&&$hasType){
            $output.='<span class="purdue-posttype-tag">'.$card["postType"].'</span>';
        }
        if($type=="story" && $card["tag"]&&
        $hasTag){
            $output.='<span class="purdue-tax-tag">'.$card["tag"].'</span>';
        }
        if($type=="story" && ($card["tag"] || $card["postType"])&&($hasType||$hasTag)){
            $output.='</p>';
        }
        if($type=="story"&& $card["title"]){
        $output.='<p class="purdue-home-cta-grid__card-title">'.$card["title"].'</p>';
        }
        if($type=="story"&& $card["subtext"]&& $card["inculdeDesc"]){
            $output.='<p class="purdue-home-cta-grid__card-subtext">'.$card["subtext"].'</p>';
        }
        if($type=="faculty"&& $card["name"]){
            $output.='<p class="purdue-home-cta-grid__card-name">'.$card["name"].'</p>';
        }
        if($type=="faculty"&& $card["titleLine1"]){
            $output.='<p class="purdue-home-cta-grid__card-titleline">'.$card["titleLine1"].'</p>';
        }
        if($type=="faculty"&& $card["titleLine2"]){
            $output.='<p class="purdue-home-cta-grid__card-titleline">'.$card["titleLine2"].'</p>';
        }
        if($type=="faculty"&& $card["email"]){
            $output.='<a class="purdue-home-cta-grid__card-email" href="mailto:'.trim($card["email"]).'">'.trim($card["email"]).'</a>';
        }
        if($type=="faculty"&& $card["address"]){
            $output.='<p class="purdue-home-cta-grid__card-address">'.trim($card["address"]).'</p>';
        }
        if($type=="faculty"&& $card["phone"]){
            $output.='<a class="purdue-home-cta-grid__card-phone" href="tel://'.trim($card["phone"]).'">'.trim($card["phone"]).'</a>';
        }
        if($type=="simple"&& $card["title"]){
            $output.='<p class="purdue-home-cta-grid__card-title">'.$card["title"].'</p>';
        }
        if($type=="simple"&& $card["subtext"]){
            $output.='<p class="purdue-home-cta-grid__card-subtext">'.$card["subtext"].'</p>';
        }
        $output.='</div></div>';
    }
    return $output;
}
function rss_feed($url){
    $results=[];

    $rss = fetch_feed( $url );
	if ( is_wp_error( $rss ) ) {
		return '<div class="components-placeholder"><div class="notice notice-error"><strong>' . __( 'RSS Error:' ) . '</strong> ' . $rss->get_error_message() . '</div></div>';
	}

	if ( ! $rss->get_item_quantity() ) {
		return '<div class="components-placeholder"><div class="notice notice-error">' . __( 'An error has occurred, which probably means the feed is down. Try again later.' ) . '</div></div>';
	}
    $rss->enable_order_by_date(false);
    $rss_items  = $rss->get_items( 0, 9);
    if(!empty($rss_items)){
        $id=0; 
        foreach ($rss_items as $item) {  
            $title = esc_html( trim( strip_tags( $item->get_title() ) ) );
            if ( empty( $title ) ) {
                $title = __( '(no title)' );
            }
            $link = $item->get_link();
            $link = esc_url( $link );
            $urlWithoutFeed = strstr($url, '/feed/', true);
            $postType = $item->get_item_tags($urlWithoutFeed."/cms", 'posttype');
            $postType = $postType&&sizeof($postType)>0? $postType[0]['data']:"";
      
            $cat = $item->get_categories();
            $tag = $cat&&sizeof($cat)>0? $cat[0]->get_term():"";
            if($tag=="Featured"){
                if($cat&&sizeof($cat)>1){
                    $tag = $cat[1]->get_term();
                }else{
                    $tag ="";
                }
            }
            if($tag=="Uncategorized"){
                if($cat&&sizeof($cat)>1){
                    $tag = $cat[1]->get_term();
                }else{
                    $tag ="";
                }
            }
            $description = $item->get_description();
            $imgURLMatch = preg_match("/img.+?src=\"([^\"]+)\"/", $description, $matchimgURL);
            if($imgURLMatch){
                $imgURL=$matchimgURL[1];
            }else{
                $imgURL='';
            }
            $imgALTMatch = preg_match("/<img[^>]+alt=\"([^>]*)\"[^>]*>/iU", $description, $matchimgALT);
            if($imgALTMatch){
                $imgALT=$matchimgALT[1];
            }else{
                $imgALT='';
            }
            $text="";
            if(strlen(strip_tags(preg_replace('/<figure[^>]*>.*?<\/figure>/i', ' ', $description)))>0){
            $text=substr(strip_tags(preg_replace('/<figure[^>]*>.*?<\/figure>/i', ' ', $description)), 0, 300)."...";
            }
            $postDate = strtotime($item->get_date('j F Y, g:i a'));
            $date = date('M d, Y',$postDate);
            $month = date('M',$postDate);
            $day = date('d',$postDate);
            $node=array(
                'id'=>$id,
                'title'=>strval($title),
                'subtext'=>strval($text),
                'linkURL'=>strval($link),
                'date'=>$date,
                'mediaURL'=>$imgURL,
                'mediaAlt'=>$imgALT,
                "tag"=>$tag,
                "postType"=>$postType,
                "external"=>true,
            );
            array_push($results, $node);
            ++$id;
        }	 
    }
    return $results;
}