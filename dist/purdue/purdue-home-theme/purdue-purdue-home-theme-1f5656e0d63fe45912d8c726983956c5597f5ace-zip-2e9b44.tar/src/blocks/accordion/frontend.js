const accordions = document.querySelectorAll('.purdue-accordion__title > button');
const id = window.location.hash;

accordions.forEach((el) => {
    el.addEventListener('click', (event) => {
        const element = el.parentElement.parentElement.parentElement.parentElement.parentElement;
        const sameLevelAccordions = element.parentElement.querySelectorAll(':scope > .purdue-accordion-wrap');
        purdueBlocksToggleAccordion(element, (element.classList.contains('is-open')) ? true : false);
        sameLevelAccordions.forEach((ele) => {
            const control = ele.querySelector('.purdue-accordion__title > button');
            if(control !== event.target) {
                purdueBlocksToggleAccordion(ele, true);
            }
        });        
    })
})


if (id) {
    const el = document.querySelector(id);
    if (el) {
        const element = el.parentElement.parentElement.parentElement.parentElement;
        if (el.classList.contains('purdue-accordion__title')) {
            window.scrollTop = el.offsetTop;
            el.parentElement.parentElement.parentElement.parentElement
            purdueBlocksToggleAccordion(element, false);
            let close = el.parentElement.closest('.purdue-accordion'); 
            while(close) {
                purdueBlocksToggleAccordion(close, false);
                close = close.parentElement.closest('.purdue-accordion'); 
            }            
        }
    }
}

function purdueBlocksToggleAccordion(el, close = false) {
    const content = el.querySelector('.purdue-accordion__content');
    const control = el.querySelector('.purdue-accordion__title');
    
    (close) ? el.classList.remove('is-open') : el.classList.add('is-open');

    content.setAttribute('hidden', close)
    content.setAttribute('aria-hidden', close);
    control.setAttribute('aria-expanded', close ? false : true); 
}
