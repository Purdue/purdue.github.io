<?php
$target = $card["external"] ? 'target="_blank"' : 'target="_self"';
if($card["postType"] && $card["postType"] == "rkv_podcast"){
    $card["postType"] = "podcast";
   }
   if($card["postType"] && $card["postType"] == "post"){
    $card["postType"] = "article";
   }
if($attributes['type'] === "50-50-post"):
?>
    <a class="<?= $cardClass; ?> <?= 'post-type-'.strtolower(str_replace(' ', '-', $card["postType"])) ?>" href="<?= $card["linkURL"]; ?>" <?= $target; ?>>
        <div class="flex-container flex-container--align-center">
            <div class="columns">
                <?php
                    if($attributes["showImage"] && $card['mediaType'] == "image"):
                ?>
                    <div class="column is-4 is-hidden-tablet-only">
                       <?php                   
                            if ($card['mediaType'] == "image") {
                                if($card["mediaURL"] == ""){
                                    $card["mediaURL"]="https://marcom.purdue.edu/app/uploads/2021/09/cropped-cropped-DW540158-HDR.jpg";
                                }
                                ?>
                                <div class="image is-16by9">
                                    <img class="purdue-home-background-image" alt="<?= $card["mediaAlt"]; ?>" src="<?= $card["mediaURL"]; ?>"/>
                                </div>
                                <?php
                            }
                        ?>
                    </div>
                <?php endif; ?>
                <div class="column">
                    <p class="purdue-home-news-events__title"><?= $card["title"]; ?></p>
                    <?php if($attributes["showTag"] || $attributes["showPostType"]){?>
                    <p class="purdue-home-news-events__date"><?= $attributes["showPostType"] && $card["postType"] ? '<span class="purdue-posttype-tag">'.$card["postType"].'</span>' : "";?> <?= ($attributes["showTag"] && $card["tag"]) && ($attributes["showPostType"] && $card["postType"])? " | " : "";?>   <?= $attributes["showTag"]? $card["tag"] : "";?></p>
                    <?php } ?>
                </div>
            </div>
        </div>
    </a>
<?php elseif($attributes['type'] === "50-50"): ?>
    <a class="<?= $cardClass; ?>" href="<?= $card["linkURL"]; ?>" <?= $target; ?>>
        <div class="flex-container flex-container--align-center">
            <div class="columns">
                    <?php
                        if($attributes["showImage"] && $card['mediaType'] == "image"):
                    ?>
                        <div class="column is-4 is-hidden-tablet-only">
                        <?php                   
                                if ($card['mediaType'] == "image") {
                                    if($card["mediaURL"] == ""){
                                        $card["mediaURL"]="https://marcom.purdue.edu/app/uploads/2021/09/cropped-cropped-DW540158-HDR.jpg";
                                    }
                                    ?>
                                    <div class="image is-16by9">
                                        <img class="purdue-home-background-image" alt="<?= $card["mediaAlt"]; ?>" src="<?= $card["mediaURL"]; ?>"/>
                                    </div>
                                    <?php
                                }
                            ?>
                        </div>
                <?php endif; ?>
                <div class="column">
                    <?php if($attributes["showTag"]&&$card["tag"]){?>
                        <p class="purdue-home-news-events__tag"><?= $card["tag"]; ?></p>
                        <?php } ?>
                        <p class="purdue-home-news-events__title"><?= $card["title"]; ?></p>        
                        <?php if($attributes["showDate"]){?>
                        <p class="purdue-home-news-events__date">
                            <?php
                            if ($card["date"]) {
                                ?>
                                <span class="date"><?= $card["date"]; ?></span>
                                <?php
                            }
                            if ($card["time"]) {
                                ?>
                                <span class="time"><?= $card["time"]; ?></span>
                                <?php
                            }
                            ?>
                        </p>
                        <?php } ?>
                </div>
            </div>
        </div>
    </a>
<?php else: ?>
    <a class="<?= $cardClass; ?>" href="<?= $card["linkURL"]; ?>" <?= $target; ?>>
        <div class="flex-container flex-container--align-center">
             <?php if($attributes["showTag"]&&$card["tag"]){?>
                 <p class="purdue-home-news-events__tag"><?= $card["tag"]; ?></p>
              <?php } ?>
                 <p class="purdue-home-news-events__title"><?= $card["title"]; ?></p>        
              <?php if($attributes["showDate"]){?>
                    <p class="purdue-home-news-events__date">
                            <?php
                            if ($card["date"]) {
                                ?>
                                <span class="date"><?= $card["date"]; ?></span>
                                <?php
                            }
                            if ($card["time"]) {
                                ?>
                                <span class="time"><?= $card["time"]; ?></span>
                                <?php
                            }
                            ?>
                     </p>
             <?php } ?>
        </div>
    </a>
<?php endif; ?>