const tabGroups=[...document.querySelectorAll(".purdue-home-tabs")]
if(tabGroups&&tabGroups.length>0){
tabGroups.forEach((tabs)=>{
    const headers=[...tabs.querySelectorAll(".purdue-home-tabs__header")]
    const panels=[...tabs.querySelectorAll(".purdue-home-tabs__panel")]
    const panelsContainer=panels[0].parentElement
    const arrow=tabs.querySelector(".arrow")
    const activeHeader=tabs.querySelector(".purdue-home-tabs__header.active")
    if(arrow){
        arrow.style.top=activeHeader.offsetTop+activeHeader.offsetHeight/2+"px"
    }

    headers.forEach((header,index)=>{
        let clHeader = header.cloneNode(true);
        clHeader.id="accrdion-"+clHeader.id
        clHeader.classList.remove("purdue-home-tabs__header")
        clHeader.classList.add("purdue-home-tabs__header-mobile")
        clHeader.setAttribute("role", "button")
        panelsContainer.insertBefore(clHeader, panels[index])
    })
    let newHeaders=[...tabs.querySelectorAll(".purdue-home-tabs__header-mobile")]

    headers.forEach((header, index)=>{
        header.addEventListener('click', ()=>{
            panels.forEach((panel,i)=>{
                if(index===i){
                    panel.classList.add('active')   

                }else{
                    panel.classList.remove('active')
                }
            })
            headers.forEach((h,i)=>{
                if(index===i){
                    h.classList.add('active')
                    h.setAttribute('aria-selected',"true")            
                }else{
                    h.classList.remove('active')
                    h.setAttribute('aria-selected',"false")
                }
            })
            newHeaders.forEach((h,i)=>{
                if(index===i){
                    h.classList.add('active')
                    h.setAttribute('aria-selected',"true")            
                }else{
                    h.classList.remove('active')
                    h.setAttribute('aria-selected',"false")
                }
            })
            if(arrow){
                arrow.style.top=header.offsetTop+header.offsetHeight/2+"px"
            }
        })
    })
    newHeaders.forEach((header,index)=>{
        header.addEventListener('click', (e)=>{      
            panels.forEach((panel,i)=>{
                if(index===i){
                    panel.classList.contains('active')?panel.classList.remove('active'):panel.classList.add('active')
                                      
                }else{
                    panel.classList.remove('active')
                }
            })
            newHeaders.forEach((h,i)=>{
                if(index===i){
                    if(header.classList.contains("active")){
                        header.classList.remove('active')
                        header.setAttribute('aria-selected',"false")
                    }else{
                        header.classList.add('active')
                        header.setAttribute('aria-selected',"true")
                    }
                }else{
                    h.classList.remove('active')
                    h.setAttribute('aria-selected',"false")
                }
            })
            headers.forEach((h,i)=>{
                if(index===i){
                    h.classList.add('active')
                    h.setAttribute('aria-selected',"true")            
                }else{
                    h.classList.remove('active')
                    h.setAttribute('aria-selected',"false")
                }
            })

        })
    })
})
}