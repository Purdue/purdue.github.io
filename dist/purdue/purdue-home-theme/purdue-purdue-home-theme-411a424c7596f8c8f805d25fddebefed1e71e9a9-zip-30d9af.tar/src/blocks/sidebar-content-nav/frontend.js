document.addEventListener( 'DOMContentLoaded', () => {
	const origin = window.location.origin;

	// Current-page detection (is-active / aria-current) and the associated
	// auto-expansion of ancestor sections are handled server-side in render.php
	// so the state is correct on first paint and without JS. This file covers
	// the interactive bits: external-link markup, click-to-toggle, and filter.

	// ── External link detection ───────────────────────────────────────────────
	// Inject ↗ icon on any sidebar link whose hostname differs from this site.
	document.querySelectorAll( '.scn-nav__link' ).forEach( ( link ) => {
		const href = link.getAttribute( 'href' ) || '';
		if ( ! href || href.startsWith( '#' ) || href.startsWith( 'mailto:' ) || href.startsWith( 'tel:' ) ) return;

		let isExternal = false;
		try {
			const url = new URL( href, origin );
			isExternal = url.origin !== origin;
		} catch ( e ) {}

		if ( isExternal ) {
			link.setAttribute( 'target', '_blank' );
			link.setAttribute( 'rel', 'noopener noreferrer' );
			link.classList.add( 'scn-nav__link--external' );

			// Wrap existing content in a span so the icon flows inline with
			// the text rather than becoming a separate flex child that gets
			// pushed to the far right of the link.
			const labelSpan = document.createElement( 'span' );
			labelSpan.className = 'scn-nav__label';
			while ( link.firstChild ) {
				labelSpan.appendChild( link.firstChild );
			}
			link.appendChild( labelSpan );

			const svg = document.createElementNS( 'http://www.w3.org/2000/svg', 'svg' );
			svg.setAttribute( 'class', 'scn-nav__icon scn-nav__icon--external' );
			svg.setAttribute( 'viewBox', '0 0 24 24' );
			svg.setAttribute( 'fill', 'none' );
			svg.setAttribute( 'stroke', 'currentColor' );
			svg.setAttribute( 'stroke-width', '1.5' );
			svg.setAttribute( 'stroke-linecap', 'round' );
			svg.setAttribute( 'stroke-linejoin', 'round' );
			svg.setAttribute( 'aria-hidden', 'true' );
			svg.setAttribute( 'focusable', 'false' );
			svg.innerHTML = '<line x1="7" y1="17" x2="17" y2="7"/><polyline points="7 7 17 7 17 17"/>';

			// Screen-reader-only cue that this link opens in a new tab.
			const srText = document.createElement( 'span' );
			srText.className = 'screen-reader-text';
			srText.textContent = ' (opens in a new tab)';

			// Glue the final word and the icon into one nowrap unit so the arrow
			// can never wrap onto a line by itself when a long label wraps.
			const tail = document.createElement( 'span' );
			tail.className = 'scn-nav__label-end';
			const lastText = labelSpan.lastChild;
			if ( lastText && lastText.nodeType === Node.TEXT_NODE ) {
				const text = lastText.textContent.replace( /\s+$/, '' );
				const sp = text.lastIndexOf( ' ' );
				if ( sp >= 0 ) {
					lastText.textContent = text.slice( 0, sp + 1 );
					tail.textContent = text.slice( sp + 1 );
				} else {
					lastText.textContent = '';
					tail.textContent = text;
				}
			}
			tail.appendChild( srText );
			tail.appendChild( svg );
			labelSpan.appendChild( tail );
		}
	} );

	// ── L1 expand / collapse ──────────────────────────────────────────────────
	document.querySelectorAll( '.scn-nav__trigger--l1' ).forEach( ( trigger ) => {
		trigger.addEventListener( 'click', () => {
			const isExpanded = trigger.getAttribute( 'aria-expanded' ) === 'true';
			const children = document.getElementById( trigger.getAttribute( 'aria-controls' ) );
			trigger.setAttribute( 'aria-expanded', String( ! isExpanded ) );
			if ( children ) children.hidden = isExpanded;
			trigger.closest( '.scn-nav__item--l1' ).classList.toggle( 'is-open', ! isExpanded );
		} );
	} );

	// ── L2 / L3 expand / collapse ─────────────────────────────────────────────
	document.querySelectorAll( '.scn-nav__trigger--l2, .scn-nav__trigger--l3' ).forEach( ( trigger ) => {
		trigger.addEventListener( 'click', () => {
			const isExpanded = trigger.getAttribute( 'aria-expanded' ) === 'true';
			const children = document.getElementById( trigger.getAttribute( 'aria-controls' ) );
			trigger.setAttribute( 'aria-expanded', String( ! isExpanded ) );
			if ( children ) children.hidden = isExpanded;
			trigger.closest( '.scn-nav__item' ).classList.toggle( 'is-open', ! isExpanded );
		} );
	} );

	// ── Centre the current item in the sidebar ───────────────────────────────
	// The sidebar is its own scroll container (overflow-y: auto, capped height).
	// On a deep menu the current page's link can sit below the fold, so we set the
	// container's scroll position to centre it. We scroll the container directly
	// (not element.scrollIntoView, which would also scroll the page/window) and
	// centre within the area *below* the sticky filter bar, so the item never
	// lands under it and its ancestors stay visible above it for context.
	//
	// Always instant, never smooth: this runs on arrival, where animating the
	// sidebar reads as jitter rather than as feedback.
	const centreActiveItem = ( block ) => {
		// Not scrollable (e.g. mobile, where the block is static/visible) → nothing to do.
		if ( block.scrollHeight <= block.clientHeight ) return;

		const active = block.querySelector(
			'.scn-nav__link.is-active, .scn-nav__link[aria-current="page"]'
		);
		if ( ! active ) return;

		const blockRect  = block.getBoundingClientRect();
		const activeRect = active.getBoundingClientRect();

		// Height of the sticky filter bar so the item lands below it, not under it.
		const filter  = block.querySelector( '.scn-filter' );
		const filterH = filter ? filter.offsetHeight : 0;

		// Offset of the active item from the top of the scrollable content.
		const activeOffset = activeRect.top - blockRect.top + block.scrollTop;
		// Centre it in the visible area beneath the filter bar. Values outside the
		// scrollable range are clamped by the browser, so an item near either end
		// simply rests against that end rather than being forced to the middle.
		const visibleH = block.clientHeight - filterH;
		const ideal    = activeOffset - filterH - Math.max( 0, ( visibleH - activeRect.height ) / 2 );

		// Clamp to the scrollable range *before* the snap below reasons about it.
		// Assigning an out-of-range scrollTop is harmless — the browser clamps it —
		// but the snap asks "which row sits at the top of the visible area", and
		// that has to be answered from the position actually applied, not the ideal
		// one. Near either end of a short menu the ideal routinely overshoots, and
		// the snap would then inspect a region the reader never sees.
		const maxScroll = Math.max( 0, block.scrollHeight - block.clientHeight );
		const target    = Math.min( Math.max( 0, ideal ), maxScroll );

		// Centring lands on an arbitrary pixel, which usually slices whichever row
		// straddles the top of the visible area in half. Find that row and scroll
		// up to its top edge so it reads in full — at most one row of movement.
		// Rows inside a collapsed section have no layout box, hence the height test.
		const regionTop = target + filterH;
		let clippedRowTop = null;
		block.querySelectorAll( '.scn-nav__link, .scn-nav__trigger--l1' ).forEach( ( row ) => {
			const rowH = row.offsetHeight;
			if ( ! rowH ) return;
			const rowTop = row.getBoundingClientRect().top - blockRect.top + block.scrollTop;
			if ( rowTop < regionTop - 0.5 && rowTop + rowH > regionTop + 0.5 ) {
				clippedRowTop = rowTop;
			}
		} );

		let finalTop = target;
		if ( null !== clippedRowTop ) {
			const snapped = clippedRowTop - filterH;
			// Scrolling up pushes the active item down the visible area. Only take
			// the snap while the active item still fits below it; otherwise keeping
			// the current page visible wins over a tidy top edge.
			const slackBelow = ( target + block.clientHeight ) - ( activeOffset + activeRect.height );
			if ( target - snapped <= slackBelow ) {
				finalTop = snapped;
			}
		}

		block.scrollTop = Math.min( Math.max( 0, finalTop ), maxScroll );
	};

	document.querySelectorAll( '.scn-block' ).forEach( ( block ) => {
		// Once the reader touches the sidebar, its scroll position belongs to them —
		// a later settle pass must not yank it back. Tracked via input events rather
		// than a scroll listener, which cannot tell our own scrolling from theirs.
		let userEngaged = false;
		[ 'pointerdown', 'wheel', 'touchstart', 'keydown' ].forEach( ( evt ) => {
			block.addEventListener( evt, () => { userEngaged = true; }, { passive: true, once: true } );
		} );

		const pass = () => {
			if ( ! userEngaged ) centreActiveItem( block );
		};

		pass();

		// The mobile drawer is hidden at load, leaving nothing to measure, so it
		// asks for a pass each time it opens (see the drawer section below).
		block.addEventListener( 'scn:drawer-open', pass );

		// Re-run once layout has settled. Webfonts and images land after
		// DOMContentLoaded and change row heights, which would otherwise leave the
		// first measurement stale and the item off-centre (or off-screen).
		if ( document.readyState !== 'complete' ) {
			window.addEventListener( 'load', pass, { once: true } );
		}
		if ( document.fonts && document.fonts.ready ) {
			document.fonts.ready.then( pass );
		}
	} );

	// ── Filter ───────────────────────────────────────────────────────────────
	document.querySelectorAll( '.scn-block' ).forEach( ( block ) => {
		const input = block.querySelector( '.scn-filter__input' );
		if ( ! input ) return;

		const status = block.querySelector( '.scn-filter__status' );
		const items = block.querySelectorAll( '.scn-nav__item' );
		// Count only leaves (the links/actions users care about) for result-count announcements.
		const leafItems = Array.from( items ).filter( ( item ) => {
			return ! item.querySelector( ':scope > .scn-nav__children' );
		} );

		// Snapshot each item's text + its original expanded state so we can restore
		// everything when the filter is cleared.
		const snapshots = new Map();
		items.forEach( ( item ) => {
			const label = item.querySelector( ':scope > .scn-nav__link, :scope > .scn-nav__trigger' );
			const text = ( label?.textContent || '' ).trim().toLowerCase();
			const childrenList = item.querySelector( ':scope > .scn-nav__children' );
			const trigger = item.querySelector( ':scope > .scn-nav__trigger' );
			snapshots.set( item, {
				text,
				wasOpen: item.classList.contains( 'is-open' ),
				childrenHidden: childrenList ? childrenList.hidden : null,
				triggerExpanded: trigger ? trigger.getAttribute( 'aria-expanded' ) : null,
			} );
		} );

		// Debounce status updates so we don't announce on every keystroke.
		let statusTimer = null;
		const announce = ( msg ) => {
			if ( ! status ) return;
			clearTimeout( statusTimer );
			statusTimer = setTimeout( () => {
				// Clear first to force re-announcement even if the text is the same.
				status.textContent = '';
				requestAnimationFrame( () => { status.textContent = msg; } );
			}, 300 );
		};

		const MIN_QUERY_LENGTH = 3;

		const applyFilter = ( query ) => {
			const q = query.trim().toLowerCase();

			if ( q.length < MIN_QUERY_LENGTH ) {
				// Too-short queries are treated the same as empty so the
				// menu fully reverts until the user types the threshold.
				items.forEach( ( item ) => {
					const snap = snapshots.get( item );
					item.classList.remove( 'is-hidden' );
					item.classList.toggle( 'is-open', snap.wasOpen );
					const childrenList = item.querySelector( ':scope > .scn-nav__children' );
					if ( childrenList && snap.childrenHidden !== null ) {
						childrenList.hidden = snap.childrenHidden;
					}
					const trigger = item.querySelector( ':scope > .scn-nav__trigger' );
					if ( trigger && snap.triggerExpanded !== null ) {
						trigger.setAttribute( 'aria-expanded', snap.triggerExpanded );
					}
				} );
				block.classList.remove( 'is-filter-empty' );
				if ( status ) status.textContent = '';
				return;
			}

			// Match if the item's own text contains q.
			const matches = new Set();
			items.forEach( ( item ) => {
				const snap = snapshots.get( item );
				if ( snap.text.includes( q ) ) matches.add( item );
			} );

			// An expandable container (L1/L2 with a children list) isn't
			// actionable on its own — its trigger only toggles children.
			// Drop it from matches if nothing inside matches, so we don't
			// surface an empty expanded panel. Deepest-first so pruning a
			// nested container can cascade into emptying its parent.
			const itemDepth = ( item ) => {
				let depth = 0;
				let ancestor = item.parentElement?.closest( '.scn-nav__item' );
				while ( ancestor ) {
					depth++;
					ancestor = ancestor.parentElement?.closest( '.scn-nav__item' );
				}
				return depth;
			};
			const containers = Array.from( items )
				.filter( ( item ) => !! item.querySelector( ':scope > .scn-nav__children' ) )
				.sort( ( a, b ) => itemDepth( b ) - itemDepth( a ) );
			containers.forEach( ( container ) => {
				const childList = container.querySelector( ':scope > .scn-nav__children' );
				const hasMatchingDescendant = Array.from(
					childList.querySelectorAll( '.scn-nav__item' )
				).some( ( descendant ) => matches.has( descendant ) );
				if ( ! hasMatchingDescendant ) matches.delete( container );
			} );

			// Any ancestor of a match also matches so parents stay visible.
			matches.forEach( ( item ) => {
				let ancestor = item.parentElement?.closest( '.scn-nav__item' );
				while ( ancestor ) {
					matches.add( ancestor );
					ancestor = ancestor.parentElement?.closest( '.scn-nav__item' );
				}
			} );

			items.forEach( ( item ) => {
				const isMatch = matches.has( item );
				item.classList.toggle( 'is-hidden', ! isMatch );

				if ( isMatch ) {
					const childrenList = item.querySelector( ':scope > .scn-nav__children' );
					const trigger = item.querySelector( ':scope > .scn-nav__trigger' );
					if ( childrenList ) childrenList.hidden = false;
					if ( trigger ) trigger.setAttribute( 'aria-expanded', 'true' );
					item.classList.add( 'is-open' );
				}
			} );

			const leafMatches = leafItems.filter( ( item ) => matches.has( item ) ).length;
			block.classList.toggle( 'is-filter-empty', leafMatches === 0 );

			if ( leafMatches === 0 ) {
				announce( 'No matches found.' );
			} else if ( leafMatches === 1 ) {
				announce( '1 result.' );
			} else {
				announce( `${ leafMatches } results.` );
			}
		};

		input.addEventListener( 'input', ( e ) => applyFilter( e.target.value ) );
		input.addEventListener( 'keydown', ( e ) => {
			if ( e.key === 'Escape' ) {
				// Escape empties the filter. In the mobile drawer the keypress
				// carries on to close the drawer as well (see Mobile drawer
				// below), so one Escape always dismisses it, as it does any
				// dialog.
				input.value = '';
				applyFilter( '' );
			}
		} );
	} );

	// ── Mobile drawer (sidebar display) ──────────────────────────────────────
	// Below the tablet breakpoint the columns stack, so rather than dropping to
	// the bottom of the page the sidebar becomes an off-canvas drawer: a
	// floating button (in Back to Top's spot, stacked above it once it shows) slides it in from the right
	// over a scrim, and a close button sits at the bottom of the panel within
	// thumb reach. Without JS none of this is set up and the nav stays stacked
	// under the content.
	//
	// The nav is restyled in place (.has-drawer) rather than moved to <body>,
	// so crossing the breakpoint needs no DOM moves and the desktop column is
	// left as it was. Staying put is safe because nothing between the column
	// and <body> creates a containing block or stacking context that would
	// trap the fixed panel. The layout column it leaves empty on mobile is
	// collapsed in style.scss.
	//
	// One drawer per page: the floating button has a fixed spot, and a second
	// one would land on top of the first. Further sidebar navs keep the
	// stacked layout.
	const drawerBlock = document.querySelector( '.scn-block--sidebar' );
	if ( drawerBlock ) {
		// Must match the theme's `mobile` mixin ($tablet - 1px), which the
		// drawer styles in style.scss are written against.
		const mobileQuery = window.matchMedia( '(max-width: 767px)' );
		const root = document.documentElement;

		if ( ! drawerBlock.id ) drawerBlock.id = 'scn-drawer-nav';

		const toggle = document.createElement( 'button' );
		toggle.type = 'button';
		toggle.className = 'scn-drawer-toggle';
		toggle.setAttribute( 'aria-controls', drawerBlock.id );
		toggle.setAttribute( 'aria-expanded', 'false' );
		// It opens a modal dialog (see openDrawer()), not an in-page disclosure.
		toggle.setAttribute( 'aria-haspopup', 'dialog' );
		toggle.setAttribute( 'aria-label', 'Section navigation' );
		toggle.innerHTML = '<span class="scn-drawer-toggle__icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M15 3v18"/></svg></span>';

		const overlay = document.createElement( 'div' );
		overlay.className = 'scn-drawer-overlay';

		// Circle-x on the accordion icon's grid: its plus turned 45°.
		const closeBar = document.createElement( 'span' );
		closeBar.className = 'scn-drawer-close';
		closeBar.innerHTML = '<button type="button" class="scn-drawer-close__button" aria-label="Close section navigation"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 52 52" fill="none" stroke="currentColor" stroke-width="4" stroke-linecap="round" aria-hidden="true" focusable="false"><circle cx="26" cy="26" r="24"/><path d="M17.5 17.5l17 17M34.5 17.5l-17 17"/></svg></button>';

		drawerBlock.before( toggle, overlay );
		drawerBlock.append( closeBar );
		drawerBlock.classList.add( 'has-drawer' );

		const isOpen = () => drawerBlock.classList.contains( 'is-drawer-open' );

		// The panel only animates while opening or closing (.is-drawer-sliding
		// in style.scss), so the class comes off once the slide ends. A standing
		// transition would also play when a resize crosses into the mobile layout.
		drawerBlock.addEventListener( 'transitionend', ( e ) => {
			if ( e.target === drawerBlock && e.propertyName === 'transform' ) {
				drawerBlock.classList.remove( 'is-drawer-sliding' );
			}
		} );

		// While the drawer is open, everything else on the page is inert, so
		// nothing behind the scrim can be reached by pointer, keyboard or screen
		// reader. aria-modal (see openDrawer()) says the same to assistive tech,
		// but support for it is uneven; inert is what enforces it. Walks up from
		// the panel marking each level's siblings, skipping the scrim (a tap on
		// it closes the drawer), and on close undoes only what it set.
		let inertedByDrawer = [];
		const setPageInert = ( on ) => {
			if ( ! on ) {
				inertedByDrawer.forEach( ( el ) => { el.inert = false; } );
				inertedByDrawer = [];
				return;
			}
			for ( let el = drawerBlock; el.parentElement && el !== document.body; el = el.parentElement ) {
				for ( const sibling of el.parentElement.children ) {
					if ( sibling === el || sibling === overlay || sibling.inert ) continue;
					sibling.inert = true;
					inertedByDrawer.push( sibling );
				}
			}
		};

		const openDrawer = () => {
			// Open, the panel is a modal dialog (WAI-ARIA APG dialog pattern),
			// named by its existing "Section navigation" label. Set before the
			// panel becomes visible, so it is announced as a dialog from the
			// start. render.php explains why the element is a div.
			drawerBlock.setAttribute( 'role', 'dialog' );
			drawerBlock.setAttribute( 'aria-modal', 'true' );
			setPageInert( true );
			drawerBlock.classList.add( 'is-drawer-sliding', 'is-drawer-open' );
			overlay.classList.add( 'is-open' );
			toggle.setAttribute( 'aria-expanded', 'true' );
			// The drawer's own page-scroll lock, not the header overlay's
			// .no-scroll; style.scss explains why.
			root.classList.add( 'scn-drawer-scroll-lock' );
			// Focus the panel itself, not its first control: that is the filter
			// input, and focusing it would raise the on-screen keyboard. Only
			// focusable while open, so a click in the desktop sidebar's padding
			// never focuses the whole nav.
			drawerBlock.setAttribute( 'tabindex', '-1' );
			drawerBlock.focus( { preventScroll: true } );
			drawerBlock.dispatchEvent( new Event( 'scn:drawer-open' ) );
		};

		const closeDrawer = ( { restoreFocus = true, animate = true } = {} ) => {
			if ( ! isOpen() ) return;
			drawerBlock.classList.toggle( 'is-drawer-sliding', animate );
			drawerBlock.classList.remove( 'is-drawer-open' );
			// Back to the plain navigation landmark it is when closed. The page
			// comes back before focus returns to the toggle, which is part of it.
			drawerBlock.setAttribute( 'role', 'navigation' );
			drawerBlock.removeAttribute( 'aria-modal' );
			setPageInert( false );
			overlay.classList.remove( 'is-open' );
			toggle.setAttribute( 'aria-expanded', 'false' );
			root.classList.remove( 'scn-drawer-scroll-lock' );
			drawerBlock.removeAttribute( 'tabindex' );
			if ( restoreFocus ) toggle.focus();
		};

		toggle.addEventListener( 'click', openDrawer );
		overlay.addEventListener( 'click', () => closeDrawer() );
		closeBar.querySelector( 'button' ).addEventListener( 'click', () => closeDrawer() );

		// Escape closes the drawer, as it does any modal dialog (WAI-ARIA APG
		// dialog pattern), and closeDrawer() hands focus back to the toggle.
		// Listened for on the document so it works wherever focus has ended up,
		// not only inside the panel. From the filter it also clears the query
		// (see Filter above).
		document.addEventListener( 'keydown', ( e ) => {
			if ( e.key === 'Escape' && isOpen() ) closeDrawer();
		} );

		drawerBlock.addEventListener( 'keydown', ( e ) => {
			if ( ! isOpen() || e.key !== 'Tab' ) return;

			// Keep Tab inside the open drawer. Rows in collapsed or filtered-out
			// lists have no layout box, so they drop out of the cycle.
			const focusable = Array.from(
				drawerBlock.querySelectorAll( 'a[href], button:not([disabled]), input:not([disabled])' )
			).filter( ( el ) => el.getClientRects().length );
			if ( ! focusable.length ) return;
			const first = focusable[ 0 ];
			const last = focusable[ focusable.length - 1 ];

			if ( e.shiftKey && ( document.activeElement === first || document.activeElement === drawerBlock ) ) {
				e.preventDefault();
				last.focus();
			} else if ( ! e.shiftKey && document.activeElement === last ) {
				e.preventDefault();
				first.focus();
			}
		} );

		// A link to somewhere else on this page leaves the reader here, so get
		// the drawer out of the way of its target. Links to other pages just
		// navigate.
		drawerBlock.addEventListener( 'click', ( e ) => {
			const link = e.target.closest( 'a[href]' );
			if ( ! link || ! isOpen() ) return;
			if ( link.hash && link.origin === window.location.origin && link.pathname === window.location.pathname ) {
				closeDrawer( { restoreFocus: false } );
			}
		} );

		// Back to the side-by-side layout: the nav is a column again, so drop the
		// open state and the scroll lock with it, without a slide. A slide cut
		// short by the resize never fires transitionend, so its class goes too;
		// left on, the next resize into mobile would animate.
		mobileQuery.addEventListener( 'change', ( e ) => {
			drawerBlock.classList.remove( 'is-drawer-sliding' );
			if ( ! e.matches ) closeDrawer( { restoreFocus: false, animate: false } );
		} );

		// The toggle keeps step with Back to Top (to-top.js). It shares Back to
		// Top's spot until that slides in partway down the page (.to-top-shown),
		// then stacks above it (.is-stacked). Near the bottom of the page,
		// to-top.js drops Back to Top out of its fixed spot into the top of the
		// footer (.to-top-relative), and the toggle follows it there
		// (.is-anchored). See style.scss for both. Checked a frame after each
		// scroll, once to-top.js has updated #to-top's classes for it.
		const toTop = document.getElementById( 'to-top' );
		if ( toTop ) {
			let frame = 0;

			const followToTop = () => {
				frame = 0;
				toggle.classList.toggle( 'is-stacked', toTop.classList.contains( 'to-top-shown' ) );

				const anchored = mobileQuery.matches && toTop.classList.contains( 'to-top-relative' );
				toggle.classList.toggle( 'is-anchored', anchored );
				if ( ! anchored ) {
					toggle.style.removeProperty( 'top' );
					toggle.style.removeProperty( 'left' );
					return;
				}

				// Nudge the toggle's box onto #to-top's by however far apart they
				// measure. Starting from 0, 0 the first time means the nudge works
				// whichever ancestor the toggle ends up positioned against. Rerun
				// on later scrolls, it only writes if the page has shifted under
				// the pair since (late images, a section opening above).
				if ( ! toggle.style.top ) {
					toggle.style.top = '0px';
					toggle.style.left = '0px';
				}
				const from = toggle.getBoundingClientRect();
				const to = toTop.getBoundingClientRect();
				// The measured box includes the toggle's transform: the .is-stacked
				// lift, possibly still mid-transition. Adding back whatever it is
				// right now leaves dy as the box's own move, so the lift stays
				// applied rather than being nudged away.
				const lift = new DOMMatrixReadOnly( getComputedStyle( toggle ).transform ).m42;
				const dy = to.top - from.top + lift;
				const dx = to.left - from.left;
				if ( Math.abs( dy ) < 0.5 && Math.abs( dx ) < 0.5 ) return;
				toggle.style.top = `${ parseFloat( toggle.style.top ) + dy }px`;
				toggle.style.left = `${ parseFloat( toggle.style.left ) + dx }px`;
			};

			const queueFollow = () => {
				if ( ! frame ) frame = requestAnimationFrame( followToTop );
			};

			window.addEventListener( 'scroll', queueFollow, { passive: true } );
			window.addEventListener( 'resize', queueFollow );
			// #to-top slides in with a transform, and measuring it mid-slide
			// would leave the toggle short of where it comes to rest.
			toTop.addEventListener( 'transitionend', queueFollow );
			queueFollow();
		}
	}
} );