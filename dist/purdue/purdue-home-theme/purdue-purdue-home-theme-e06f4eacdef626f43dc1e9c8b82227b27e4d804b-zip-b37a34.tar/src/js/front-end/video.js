const youtube = [...document.querySelectorAll(".youtube-video,.lite-youtube, .modal-youtube-video")];
if (youtube && youtube.length > 0) {
  const tag = document.createElement("script");
  tag.src = "https://www.youtube.com/iframe_api";
  const firstScriptTag = document.getElementsByTagName("script")[0];
  firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);
}
let players = [];
//cta caard: on hover preview, on click play youtube
const cta_cards = document.querySelectorAll(".purdue-home-cta-card");
if (cta_cards.length > 0) {

  cta_cards.forEach((card) => {
    const card_video_element = card.querySelector("video");
    if (card_video_element !== null) {
      card_video_element.loop = true; // Make sure the video loops
      card_video_element.muted = true; // Make sure the video is muted
      card.addEventListener("mouseover", () => {
        card_video_element.play();
      });

      card.addEventListener("mouseout", () => {
        card_video_element.pause();
      });
    }
    const card_iframe_element = card.querySelector(".youtube-video");
    const card_iframe_container = card.querySelector(".iframe-container");
    const card_text_container = card.querySelector(".flex-container");
    const card_background_container = card.querySelector(".image");

    if (card_iframe_element) {
      let checkYT = setInterval(function () {
        if (YT && YT.loaded) {
          let player = new YT.Player(card_iframe_element.id, {
            height: "390",
            width: "640",
            videoId: card_iframe_element.id,
            playerVars: {
              rel: 0,
              html5: 1,
            },
            events: {
              onReady: function (event) {
                card.addEventListener("click", (event) => {
                  event.preventDefault();
                  card_text_container.style.display = "none";
                  card_background_container.style.display = "none";
                  card_iframe_container.classList.remove("is-sr-only");
                  if (player) {
                    setTimeout(() => player.playVideo(), 500);
                  }
                  players.forEach((pl) => {
                    if (pl.id !== card_iframe_element.id) {
                      if (
                        typeof pl.player.getPlayerState === 'function' &&
                        pl.player.getPlayerState() === 1
                      ) {
                        pl.player.pauseVideo();
                      }
                    }
                  });
                });
              },
              onStateChange: function (event) {
                setTimeout(function () {
                  if (
                    event.target.getPlayerState() == 0 ||
                    event.target.getPlayerState() == 2
                  ) {
                    card_text_container.style.display = "flex";
                    card_background_container.style.display = "block";
                    card_iframe_container.classList.add("is-sr-only");
                  }
                }, 500);
                if (typeof event.target.getPlayerState === 'function' && event.target.getPlayerState() === 1) {
                  players.forEach((pl) => {
                    if (pl.id !== card_iframe_element.id) {
                      if (
                        typeof pl.player.getPlayerState === 'function' &&
                        pl.player.getPlayerState() === 1
                      ) {
                        pl.player.pauseVideo();
                      }
                    }
                  });
                }
              },
            },
          });
          players.push({
            id: card_iframe_element.id,
            player: player,
          });
          clearInterval(checkYT);
        }
      }, 1000);
      checkYT;
    }
  });
}
//Youtube in modal
const yt_modal = document.querySelectorAll('.modal-youtube-video');
if (yt_modal && yt_modal.length > 0) {
  yt_modal.forEach((youtube) => {
    const yt_modal_id = youtube.id;
    let checkYT = setInterval(function () {
      if (YT && YT.loaded) {
        let player = new YT.Player(yt_modal_id, {
          height: "390",
          width: "640",
          videoId: yt_modal_id,
          playerVars: {
            rel: 0,
            html5: 1,
          },
          events: {
            onReady: function (event) {
              (
                document.querySelectorAll(
                  ".modal-close, .modal-card-head .delete, .modal-card-foot .button, .modal-background"
                ) || []
              ).forEach((close) => {         
                close.addEventListener("click", () => {
                  player.pauseVideo();
                });
              });
            },
            onStateChange: function (event) {

              if (typeof event.target.getPlayerState === 'function' && event.target.getPlayerState() === 1) {
                players.forEach((pl) => {
                  if (pl.id !== yt_modal_id) {
                    if (
                      typeof pl.player.getPlayerState === 'function' &&
                      pl.player.getPlayerState() === 1
                    ) {
                      pl.player.pauseVideo();
                    }
                  }
                });
              }
            },
          },
        });
        players.push({
          id: yt_modal_id,
          player: player,
        });
        clearInterval(checkYT);
      }
    }, 1000);
    checkYT;
  })
}
//youtube lite
const ytl_list = document.querySelectorAll('lite-youtube');
if (ytl_list && ytl_list.length > 0) {
  ytl_list.forEach((youtube) => {
    youtube.parentNode.classList.add('youtube-lite-container');
    const videoIdLite = youtube.getAttribute('videoid');
    let playBtnEl = youtube.querySelector('.lty-playbtn');
    // A label for the button takes priority over a [playlabel] attribute on the custom-element
    const playLabel =
      (playBtnEl && playBtnEl.textContent.trim()) || youtube.getAttribute('playlabel') || 'Play';

    if (!youtube.style.backgroundImage) {
      const posterUrl = `https://i.ytimg.com/vi/${videoIdLite}/maxresdefault.jpg`;
      youtube.style.backgroundImage = `url("${posterUrl}")`;
    }

    // Set up play button, and its visually hidden label
    if (!playBtnEl) {
      playBtnEl = document.createElement('button');
      playBtnEl.type = 'button';
      playBtnEl.classList.add('lty-playbtn');
      youtube.append(playBtnEl);
    }
    if (!playBtnEl.textContent) {
      const playBtnLabelEl = document.createElement('span');
      playBtnLabelEl.className = 'lyt-visually-hidden';
      playBtnLabelEl.textContent = playLabel;
      playBtnEl.append(playBtnLabelEl);
    }
    const iframe = youtube.querySelector('.iframe-element');
    if (!iframe) {
      const params = new URLSearchParams(youtube.getAttribute('params') || []);
      params.append('autoplay', '1');
      params.append('enablejsapi', '1');
      const host = window.location.protocol + '//' + window.location.host;
      params.append('origin', host);
      const iframeEl = document.createElement('div');
      iframeEl.id = videoIdLite;
      iframeEl.dataset.title = playLabel;
      // AFAIK, the encoding here isn't necessary for XSS, but we'll do it only because this is a URL
      // https://stackoverflow.com/q/64959723/89484
      iframeEl.dataset.src = `https://www.youtube.com/embed/${encodeURIComponent(
        videoIdLite
      )}?${params.toString()}`;
      iframeEl.classList.add('iframe-element', 'screen-reader-text');
      youtube.append(iframeEl);
    }
    const checkYTLite = setInterval(() => {
      if (YT && YT.loaded) {
        const player = new YT.Player(videoIdLite, {
          height: '390',
          width: '640',
          videoId: videoIdLite,
          playerVars: {
            html5: 1,
          },
          events: {
            onReady: function () {
              youtube.addEventListener('click', (event) => {
                event.preventDefault();
                !youtube.classList.contains('lyt-activated')?youtube.classList.add('lyt-activated'):"";
                youtube.querySelector('.iframe-element').classList.container('screen-reader-text')?
                youtube.querySelector('.iframe-element').classList.remove('screen-reader-text'):"";
                player.playVideo();
                players.forEach((pl) => {
                  if (pl.id !== videoIdLite) {
                    if (
                      typeof pl.player.getPlayerState === 'function' &&
                      pl.player.getPlayerState() === 1
                    ) {
                      pl.player.pauseVideo();
                    }
                  }
                });
              });
            },
            onStateChange: function (event) {

              if (typeof event.target.getPlayerState === 'function' && event.target.getPlayerState() === 1) {
                players.forEach((pl) => {
                  if (pl.id !== videoIdLite) {
                    if (
                      typeof pl.player.getPlayerState === 'function' &&
                      pl.player.getPlayerState() === 1
                    ) {
                      pl.player.pauseVideo();
                    }
                  }
                });
              }
            },
          },
        });
        players.push({
          id: videoIdLite,
          player: player,
        });
        clearInterval(checkYTLite);
      }
    }, 1000);
    checkYTLite;
  });
}
//cta banner: auto play when in view
document.addEventListener("DOMContentLoaded", function () {
  const ctaBanner = document.querySelectorAll(
    ".purdue-home-cta-banner, .purdue-home-media-grid"
  );

  if ("IntersectionObserver" in window) {
    let lazyBackgroundObserver = new IntersectionObserver(function (
      entries,
      observer
    ) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.play();
          entry.target.loop = true;
          lazyBackgroundObserver.unobserve(entry.target);
        }
      });
    });

    ctaBanner.forEach((banner) => {
      const videos = banner.querySelectorAll("video");
      if (videos.length > 0) {
        videos.forEach((video) => {
          lazyBackgroundObserver.observe(video);
        });
      }
    });
  }
});
