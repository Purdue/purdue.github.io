 <?php
    //$cardClass = "purdue-home-cta-card purdue-home-directory-card";
    $cardClass = "purdue-home-directory-card";
    ?>
<aritcle class="<?= $cardClass ?>">
    <div class="columns">
        <?php if(get_post_thumbnail_id($post->ID)){ ?>
        <div class="column is-4-desktop py-0">
            <figure class="image is-4by5">
                <img class="purdue-home-background-image" alt="<?= get_post_meta(get_post_thumbnail_id($post->ID), '_wp_attachment_image_alt', true) ?>" src="<?= wp_get_attachment_url(get_post_thumbnail_id($post->ID)) ?>"/>
            </figure>
        </div>
        <?php } ?>
            <div class="flex-container flex-container--align-center column">
                
                <h2 class="purdue-home-directory__card-title"><?= get_the_title() ?></h2>

                <p class="purdue-home-directory__card-subtitle"><?= get_field('field_65b2bdc93007g', $post->ID) ?></p>

                <?php if(get_field('field_65b2bdc93007f', $post->ID)){ ?>
                    <p class="purdue-home-directory__card-email"><a href="mailto:<?php echo get_field('field_65b2bdc93007f', $post->ID); ?>"><?php echo get_field('field_65b2bdc93007f', $post->ID); ?></a></p>
                <?php } ?>

            </div>
    </div>
</article>