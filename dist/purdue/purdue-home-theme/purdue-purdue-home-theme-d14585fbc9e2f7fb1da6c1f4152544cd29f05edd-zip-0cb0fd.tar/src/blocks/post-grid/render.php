<?php
$id = $attributes['id'] != "" ? ' id="' . $attributes['id'] . '"' : "";
$rand=rand();
?>

<div <?= $id ?>
    class="purdue-home-cta-grid purdue-home-post-grid has-<?= $attributes['background'] ?>-background <?= $attributes['className'] ?>">
    <?php
    $sectionclass = 'section';
    if ($attributes['paddingTop']) {
        $sectionclass .= ' ' . $attributes['paddingTop'];
    }
    if ($attributes['paddingBottom']) {
        $sectionclass .= ' ' . $attributes['paddingBottom'];
    }  
    if($attributes['blockType'] == "recent")  {
        $paged = 1;
        if($attributes['postsPerPage'] == "9"){
            $posts_per_page=9;
        }elseif($attributes['postsPerPage'] == "6"){
            $posts_per_page=6;
        }else{
            $posts_per_page=3;
        }
        
    }else{
        if($attributes['columns'] == "3"){
            $posts_per_page=12;
        }else{
            $posts_per_page=16; 
        }
        $paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
    }         
    if($attributes['orderBy'] == "meta")  {
        $orderBy="meta_value";
        $metaKey="meta_for_sorting";
        $order = 'ASC';
    }elseif($attributes['orderBy'] == "title"){
        $orderBy="title";
        $metaKey="";
        $order = 'ASC';
    }else{
        $orderBy="date";
        $metaKey="";
        $order = 'DESC';
    }

    $args = array(
        'posts_per_page' => $posts_per_page,
        'paged' => $paged,
        'meta_key' => $metaKey,
        'orderby' => $orderBy,
        'order'   => $order,
    );
    $args['use_tag'] = $attributes['selectedTax'];
    $args['button_text'] = $attributes['buttonText'];
    $args['postType_tag'] = $attributes['postTypeTag'];
    $args['cardType'] = $attributes['cardType'];
    $args['showExcerpt'] = $attributes['showExcerpt'];
    if($attributes['hasSelectedPostType'] && sizeof($attributes['selectedPostType'])>0){
        $args['post_type'] = $attributes['selectedPostType'];
    }else{
        $ptargs = array(
            'public'   => true,
            '_builtin' => false,
         );
        $allPostTypes=get_post_types( $ptargs, 'names' );
        foreach ( $allPostTypes  as $post_type ) {
            $args['post_type'][] = $post_type; 
         }           
        $args['post_type'][]="post";
    }
    $args['tax_query'] = [
        'relation' => 'AND'
    ];
   
    if($attributes['hasSelectedCatTerms'] && sizeof($attributes['selectedCatTerms'])>0){
        $cat = array(
                'taxonomy' => 'category',
                'field' => 'slug',
                'terms' => $attributes['selectedCatTerms'],
        );
        array_push($args['tax_query'], $cat);
    }
    if($attributes['hasSelectedTax'] && sizeof($attributes['selectedTaxTerms'])>0){
        $taxTerms=[];
        $taxes=[];
        foreach($attributes['selectedTaxTerms'] as $selectedTaxTerm){
            $taxTerm=explode( '::', str_replace( ' ', '', $selectedTaxTerm ) );
            $taxTerms[]=$taxTerm;
            $taxes[]=$taxTerm[0];
        }
        $taxes=array_unique($taxes);
        
        foreach($taxes as $taxo){
            $taxTermTemp=[];
            foreach($taxTerms as $taxTerm){
                if($taxTerm[0]==$taxo){
                    $taxTermTemp[]=$taxTerm[1];
                }
            }
            $tax_query = array(
                    'taxonomy' => $taxo,
                    'field' => 'slug',
                    'terms' => $taxTermTemp,
              );
            array_push($args['tax_query'], $tax_query);

        }
    }
    ?>
    <!-- section class -->
    <div class="<?= $sectionclass ?>">
        <div class="container">
            <?php
            if ($attributes['header']) {
            ?>
            <div class="purdue-home-cta-grid__intro">
                <?php
                    if ($attributes['header'] && $attributes['headerStyle'] == "simple") {
                    ?>
                <h2 class="purdue-home-intro-text__header header-font-united purdue-home-cta-grid__header">
                    <?= $attributes['header'] ?></h2>
                <?php
                    }else{
                        $headerClass=$attributes['background']=="black"?" tagged-header--gold":"";

                ?>
                <div class="columns is-mulitline">
                    <div class="column">
                        <div class="tagged-header-container">
                            <h2 class="tagged-header<?= $headerClass; ?>"><?= $attributes['header'] ?></h2>
                        </div>
                    </div>
                    <?php
                            if($attributes["linkURL"] && $attributes["linkText"] && $attributes['blockType']=="recent"){
                                $target1 = $attributes["external"] ? 'target="_blank"' : 'target="_self"';
                                $buttonClass=$attributes['background']!="black"?" purdue-home-button--black":"";
                            ?>
                    <div class="column is-narrow mobile-hidden">
                        <a class="purdue-home-button <?= $buttonClass;?>" href="<?= $attributes["linkURL"]; ?>"
                            <?= $target1; ?>><?= trim($attributes["linkText"]); ?></a>
                    </div>
                    <?php
                            }
                    ?>
                </div>
                <?php
                    }
                ?>
            </div>
            <?php
                }
            ?>
            <!-- grid container -->
            <div class="purdue-home-cta-grid__grid" data-args='<?php echo wp_json_encode($args); ?>'>

                <?php
            if (($attributes['addTaxFilter']||$attributes['addCatFilter']||$attributes['addPostTypeFilter']) && $attributes['blockType']=="all") {
            ?>
                <div class="purdue-home-cta-grid__grid__filters purdue-home-cta-grid__grid__filters-checkbox">
                    <form class="purdue-home-post-grid__filter" onSubmit="return false;">
                        <div id="purdue-home-post-grid__filter-content-<?php echo $rand; ?>"
                            class="purdue-home-post-grid__filter-content">
                            <div class="purdue-home-post-grid__filter-fields">
                                <?php
                    if($attributes['addTaxFilter']){
                        $taxes=$attributes['selectedTaxFilters'];
                        if(sizeof($taxes)>0){
                            foreach ( $taxes as $tax ){
                                $label = get_taxonomy( $tax )->label;
                                $query_terms=[];
                                $terms=[];
                                if($attributes['hasSelectedTax'] && sizeof($attributes['selectedTaxTerms'])>0 && !empty($args['tax_query'])){
                                    foreach ( $args['tax_query'] as $query_tax ){
                                        if(is_array($query_tax) && $query_tax['taxonomy'] == $tax){
                                            $query_terms=$query_tax['terms'];
                                        }
                                    }
                                }
                                if(sizeof($query_terms)>0){
                                    foreach ( $query_terms as $query_tax_term ){
                                        $terms[] = get_term_by('slug', $query_tax_term, $tax);
                                    }
                                }else{
                                    $terms=get_terms([
                                        'taxonomy' => $tax,
                                        'hide_empty' => true,
                                        'parent'        => 0,
                                    ]);
                                }
                            ?>
                                <fieldset>
                                    <button class="field-title field-control" aria-disabled="true"
                                        aria-controls="<?php echo esc_attr( $tax ); ?>-field-<?php echo $rand; ?>"
                                        aria-expanded="true"><span>Filter by: </span>
                                        <?php echo esc_attr( $label ); ?></button>
                                    <div id="<?php echo esc_attr( $tax ); ?>-field-<?php echo $rand; ?>"
                                        class="field-content">
                                        <?php
                                    foreach ($terms as $term){
                                    ?>
                                        <div>
                                            <label class="field-wrap">
                                                <input type="checkbox"
                                                    class="purdue-home-post-grid__filter-field tax-field"
                                                    name="<?php echo esc_attr( $tax ); ?>"
                                                    value="<?php echo esc_attr( $term->slug ); ?>" />
                                                <?php echo esc_html( $term->name ); ?>
                                                <span class="checkmark"></span>
                                            </label>
                                        </div>
                                        <?php
                                    }
                                    ?>
                                    </div>
                                </fieldset>
                                <?php
                        }
                    }
                    }
                    if($attributes['addCatFilter']){  
                        $cats=[];              
                        $allCats=get_categories();               
                        if($attributes['hasSelectedCatTerms'] && sizeof($attributes['selectedCatTerms'])>0){ 
                            foreach ($attributes['selectedCatTerms'] as $value) {
                                foreach ($allCats as $term) {
                                    if( $term->slug == $value){
                                        $cats[]=$term; 
                                    }
                                }                            
                            }
                        }else{
                            $cats=$allCats;
                        }
                        ?>
                                <fieldset>
                                    <button class="field-title field-control" aria-disabled="true"
                                        aria-controls="category-field-<?php echo $rand; ?>"
                                        aria-expanded="true"><span>Filter by: </span>
                                        <?php echo esc_attr( $attributes['catFilterName']?$attributes['catFilterName']:"Category" ); ?>
                                    </button>
                                    <div id="category-field-<?php echo $rand; ?>" class="field-content">
                                        <?php
                                foreach ($cats as $term){
                                ?>
                                        <div>
                                            <label class="field-wrap">
                                                <input type="checkbox"
                                                    class="purdue-home-post-grid__filter-field tax-field"
                                                    name="category" value="<?php echo esc_attr( $term->slug ); ?>" />
                                                <?php echo esc_html( $term->name ); ?>
                                                <span class="checkmark"></span>
                                            </label>
                                        </div>
                                        <?php
                                }
                                ?>
                                    </div>
                                </fieldset>
                                <?php
                    }
                    if($attributes['addPostTypeFilter']){
                        $ptargs = array(
                            'public'   => true,
                            '_builtin' => false,
                        );
                        $allPostTypes=get_post_types( $ptargs, 'objects', 'and' );
                        $postTypes=[];
                        if($attributes['hasSelectedPostType'] && sizeof($attributes['selectedPostType'])>0){                        
                            foreach ($attributes['selectedPostType'] as $value) {
                                if($value=="post"){
                                    $temp=['label'=>"Post", 'name'=>'post'];
                                    $postTypes[]=$temp;
                                }else{
                                    foreach ($allPostTypes as $term) {  
                                        if( $term->name == $value){
                                            $temp=['label'=>$term->label, 'name'=>$term->name];
                                            $postTypes[]=$temp;
                                        }
                                    }
                                }                            
                            }
                        }else{
                            $temp=['label'=>"Post", 'name'=>'post'];
                            $postTypes[]=$temp;
                            foreach ($allPostTypes as $term) {  
                                    $temp=['label'=>$term->label, 'name'=>$term->name];
                                    $postTypes[]=$temp;
                            }
                        }
                        ?>
                                <fieldset>
                                    <button class="field-title field-control" aria-disabled="true"
                                        aria-controls="post-type-field-<?php echo $rand; ?>"
                                        aria-expanded="true"><span>Filter by: </span>
                                        <?php echo esc_attr( $attributes['postTypeFilterName']?$attributes['postTypeFilterName']:"Post Types" ); ?>
                                    </button>
                                    <div id="post-type-field-<?php echo $rand; ?>" class="field-content">
                                        <?php
                                foreach ($postTypes as $term){
                                ?>
                                        <div>
                                            <label class="field-wrap">
                                                <input type="checkbox"
                                                    class="purdue-home-post-grid__filter-field postType-field"
                                                    name="post-type" value="<?php echo esc_attr( $term['name'] ); ?>" />
                                                <?php echo esc_html( $term['label'] ); ?>
                                                <span class="checkmark"></span>
                                            </label>
                                        </div>
                                        <?php
                                }
                                ?>
                                    </div>
                                </fieldset>
                                <?php
                    }
                ?>
                            </div>
                            <div class="purdue-home-post-grid__filter-button hide">
                                <button type="button" class="purdue-home-button">Filter</button>
                                <button type="button"
                                    class="purdue-home-button purdue-home-button--black form-clear-button">
                                    Clear All
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
                <?php } ?>
                <?php
                    if (($attributes['addSearch']||$attributes['addOrderFilter']) && $attributes['blockType']=="all") {
                ?>
                <div class="purdue-home-cta-grid__grid__filters purdue-home-cta-grid__grid__filters-search">
                    <form class="purdue-home-post-grid__filter purdue-home-post-grid__filter-search"
                        onSubmit="return false;">
                        <?php 
                        if($attributes['addSearch']){
                            $value = isset($_GET['p']) ? wp_filter_nohtml_kses(sanitize_text_field($_GET['p'])) : ""; 
                        ?>
                        <div class="search-box">
                            <div class="search-form">
                                <i class="fas fa-search search-icon"></i>
                                <input type="search" title="search"
                                    class="search-field purdue-home-post-grid__filter-field" placeholder="Search..."
                                    name="p" value="<?php echo $value; ?>">
                                <button type="submit" class="search-button">Search
                                </button>
                                <button type="button" class="clear-button">
                                    <i class="fa-regular fa-circle-xmark" aria-label="Clear"></i>
                                </button>
                            </div>
                        </div>
                        <?php 
                }
                    if($attributes['addOrderFilter']){
                        ?>
                        <fieldset>
                            <span>Sort by:</span>
                            <label class="field-wrap radio-field">
                                <input type="radio" class="purdue-home-post-grid__filter-field order-field" name="order"
                                    value="DESC" <?= $attributes['orderBy']=="date"?'checked="checked"':"" ?> />
                                <?= $attributes['orderBy']=="date"?"Newest":"DESC" ?>
                                <span class="checkmark"></span>
                            </label>
                            <label class="field-wrap radio-field">
                                <input type="radio" class="purdue-home-post-grid__filter-field order-field" name="order"
                                    value="ASC" <?= $attributes['orderBy']!="date"?'checked="checked"':"" ?> />
                                <?= $attributes['orderBy']=="date"?"Oldest":"ASC" ?>
                                <span class="checkmark"></span>
                            </label>

                        </fieldset>
                        <?php
                    }
                    ?>
                    </form>
                </div>
                <?php
                }
                    if (($attributes['addTaxFilter']||$attributes['addCatFilter']||$attributes['addPostTypeFilter'])&&$attributes['blockType']=="all") {
                ?>
                <div class="purdue-home-cta-grid__grid__filters-selected">
                </div>
                <?php
                }
                ?>
                <div class="purdue-home-cta-grid__grid__content">
                    <?php
                        if ($attributes['excludeCat']) {
                            $term = get_term_by('slug', $attributes['excludeCat'], 'category');
                            if ($term) {
                                $exclude = array(
                                    'taxonomy' => 'category',
                                    'field' => 'term_id',
                                    'terms' => array($term->term_id), 
                                    'operator' => 'NOT IN',
                                );
                                $args['tax_query'][] = $exclude; // Append $exclude to the tax_query array
                            }
                        }
                        $query = new WP_Query($args);
                ?>
                    <div class="purdue-home-cta-grid__cards">
                        <div class="columns is-multiline">
                            <?php
                        global $post; //phpcs:ignore.
                        while ($query->have_posts()) {
                            $query->the_post();  
                            if($attributes['columns'] == "3"){
                                require __DIR__ . '/inc/story-grid.php';
                            }else{
                                require __DIR__ . '/inc/story-grid-2.php';
                            }
                        }
                        wp_reset_postdata();
                        ?>
                        </div>
                    </div>
                    <p class="purdue-home-cta-grid__message hide">No More Posts!</p>
                    <?php 
                    if($attributes['blockType']=="all"){
                     ?>
                    <nav class="pagination purdue-home-pagination">
                        <h2 class="screen-reader-text">Posts navigation</h2>
                        <div class="nav-links">
                            <?php
                        $big = 999999999; // need an unlikely integer
                        echo paginate_links(
                            array(
                                'base' => str_replace($big, '%#%', esc_url(get_pagenum_link($big))),
                                'format' => '?paged=%#%',
                                'current' => max(
                                    1,
                                    get_query_var('paged')
                                ),
                                'prev_text' => __( 'Prev', 'textdomain' ),
                                'next_text' => __( 'Next', 'textdomain' ),
                                'total' => $query->max_num_pages,
                            )
                        );
                    ?>
                        </div>
                    </nav>
                    <?php 
                    }else{
                        if($attributes["linkURL"] && $attributes["linkText"]){
                     ?>
                    <div class="purdue-home-button-storylink <?php echo($attributes['headerStyle'] != "simple" ? " mobile-show" :""); ?>">
                            <a class=" purdue-home-button purdue-home-button--storylink <?= $buttonClass;?>"
                        href="<?= $attributes["linkURL"]; ?>" <?= $target1; ?>><?= trim($attributes["linkText"]); ?></a>
                    </div>
                    <?php
                        }
                    }
                     ?>
                </div>
            </div>
            <!-- end of grid container -->
        </div>
        <!-- end of container -->
    </div>
    <!-- end of section -->
</div>