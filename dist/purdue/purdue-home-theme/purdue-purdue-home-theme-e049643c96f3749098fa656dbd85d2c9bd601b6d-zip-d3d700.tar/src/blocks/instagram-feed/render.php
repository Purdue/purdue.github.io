<?php
    $id = $attributes['id'] != "" ?' id="' . $attributes['id'] . '"' : "";
?>

<div <?= $id; ?> class="purdue-home-instagram-feed <?= $attributes['className']; ?>">
<?php if ($attributes['mediaURL'] != ""): ?>
    <div class="image" style="background-image:url(<?= $attributes['mediaURL']; ?>)"></div>
<?php endif; ?>

<?php
$blockclass = 'section';
if ($attributes['paddingTop']) {
    $blockclass .= ' ' . $attributes['paddingTop'];
}
if ($attributes['paddingBottom']) {
    $blockclass .= ' ' . $attributes['paddingBottom'];
}
?>

<div class="<?= $blockclass; ?>">
    <div class="container">
        <div class="columns">
            <div class="column">

                <?php if ($attributes['subheader'] != ""): ?>
                    <?php $subheaderclass = "tagged-header tagged-header--gold"; ?>
                    <div class="tagged-header-container">
                        <h2 class="<?= $subheaderclass; ?>"><?= $attributes["subheader"]; ?></h2>
                    </div>
                <?php endif; ?>

                <?php 
                $headerclass = 'purdue-home-instagram-feed__header'; 
                if ($attributes['subheader'] == ""):
                ?>
                <h2 class="<?= $headerclass; ?>"><?= $attributes['header']; ?></h2>
                <?php 
                elseif ($attributes['subheader'] != ""):
                ?>
                <h3 class="<?= $headerclass; ?>"><?= $attributes['header']; ?></h3>
                <?php endif; ?>
                <?php if ($attributes['buttonLinks'] && sizeof($attributes['buttonLinks']) > 0 && $attributes['buttonLinks'][0]['linkURL']): ?>
                <ul class="purdue-home-button-list">
                    <?php foreach ($attributes['buttonLinks'] as $key => $link): ?>
                        <?php
                        $target = $link["external"] ? 'target="_blank"' : 'target="_self"';
                        $buttonClass = "purdue-home-button";
                        if ($link["buttonColor"] == "black") {
                            $buttonClass .= " purdue-home-button--black";
                        }elseif($link["buttonColor"] == "white") {
                            $buttonClass .= " purdue-home-button--white";
                        }
                        $liClass = $link["fullWidth"] ? "purdue-home-button-wrap--full" : "";
                        ?>
                        <li class="<?= $liClass; ?>">
                            <a class="<?= $buttonClass; ?>" href="<?= $link["linkURL"]; ?>" <?= $target; ?>>
                                <?= trim($link["linkText"]); ?>
                            </a>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
                <?php if ($attributes['links'] && sizeof($attributes['links']) > 0 && $attributes['links'][0]["linkURL"] !== ""): ?>
                    <div class="purdue-home-instagram-feed__list-container mobile-hidden">
                        <ul class="purdue-home-instagram-feed__list">
                            <?php foreach ($attributes['links'] as $key => $link): ?>
                                <?php $target = $link["external"] ? 'target="_blank"' : 'target="_self"'; ?>
                                <li>
                                    <a title="<?= $link["linkText"]; ?>" href="<?= $link["linkURL"]; ?>" <?= $target; ?>>
                                        <span class="screen-reader-text"><?= $link["linkText"]; ?></span>
                                        <?php if(strtolower($link["linkText"]) != "twitter"){ ?>
                                            <i class="fab fa-<?= strtolower($link["linkText"]); ?>" aria-hidden="true"></i>
                                        <?php }else{ ?>
                                            <i class="fa-brands fa-x-twitter" aria-hidden="true"></i>
                                        <?php } ?>
                                    </a>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

            </div>
            <div class="column">

                <?php if ($attributes['type'] == "plugin"): ?>
                    <?= $content; ?>
                <?php elseif ($attributes['type'] == "manual"): ?>
                    <div class="purdue-home-instagram-feed__image-container mobile-hidden">
                        <?php foreach ($attributes['imgs'] as $key => $img): ?>
                            <?php if ($key < 6): ?>
                                <figure class="purdue-home-instagram-feed__image image is-1by1">
                                    <img src="<?= $img["url"]; ?>" alt="<?= $img["alt"]; ?>" />
                                </figure>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                    <div class="glide purdue-home-instagram-feed__image-slider mobile-show">
                        <div class="glide__track" data-glide-el="track">
                            <div class="glide__slides">
                                <?php foreach ($attributes['imgs'] as $img): ?>
                                    <?php if ($key < 6): ?>
                                        <div class="glide__slide">
                                            <figure class="image is-1by1">
                                                <img src="<?= $img["url"]; ?>" alt="<?= $img["alt"]; ?>" />
                                            </figure>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <div class="slider-controls slider-controls--dark">
                            <button class="glide__arrow arrow--left">prev</button>
                            <div class="glide__bullets" data-glide-el="controls[nav]">
                                <?php foreach ($attributes['imgs'] as $key => $card): ?>
                                    <?php $num = $key + 1; ?>
                                    <button class="glide__bullet slider__bullet" data-glide-dir="=<?= $key; ?>" aria-label="slide <?= $num; ?>"></button>
                                <?php endforeach; ?>
                            </div>
                            <button class="glide__arrow arrow--right">next</button>
                        </div>
                    </div>
                <?php else: ?>
                    <?php
                    $accessToken = $attributes['token'];
                    $tokenUrl = 'https://graph.instagram.com/me/media?';
                    $postFields = array(
                        'fields' => 'id,caption,media_type,media_url,thumbnail_url,children{media_type,media_url,thumbnail_url},timestamp',
                        'access_token' => $accessToken
                    );

                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_URL, $tokenUrl . http_build_query($postFields));
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    $feed = curl_exec($ch);

                    if (curl_errno($ch)) {
                        $error = curl_error($ch);
                        print_r($error);
                        exit();
                    }

                    curl_close($ch);
                    $items = json_decode($feed, true);
                    $attributes['items'] = $items["data"];
                    ?>
                    <div class="purdue-home-instagram-feed__image-container mobile-hidden">
                        <?php foreach ($attributes['items'] as $key => $item): ?>
                            <?php if ($key < 6): ?>
                                <?php
                                $src = $item["media_type"] == "VIDEO" ? $item["thumbnail_url"] : $item["media_url"];
                                ?>
                                <figure role="button" class="purdue-home-instagram-feed__image image is-1by1 modal-trigger" data-target="feed-modal-<?= $key; ?>">
                                    <img src="<?= $src; ?>" alt="<?= $item["caption"]; ?>" />
                                </figure>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                    <div class="glide purdue-home-instagram-feed__image-slider mobile-show">
                        <div class="glide__track" data-glide-el="track">
                            <div class="glide__slides">
                                <?php foreach ($attributes['items'] as $key => $item): ?>
                                    <?php if ($key < 6): ?>
                                        <?php
                                        $src = $item["media_type"] == "VIDEO" ? $item["thumbnail_url"] : $item["media_url"];
                                        ?>
                                        <div class="glide__slide">
                                            <figure role="button" class="image is-1by1">
                                                <img src="<?= $src; ?>" alt="<?= $item["caption"]; ?>" />
                                                <div class="trigger-button-container">
                                                    <button class="purdue-home-button--black modal-trigger" data-target="feed-modal-<?= $key; ?>">View More</button>
                                                </div>
                                            </figure>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <div class="slider-controls slider-controls--dark">
                            <button class="glide__arrow arrow--left">prev</button>
                            <div class="glide__bullets" data-glide-el="controls[nav]">
                                <?php foreach ($attributes['items'] as $key => $item): ?>
                                    <?php if ($key < 6): ?>
                                        <?php $num = $key + 1; ?>
                                        <button class="glide__bullet slider__bullet" data-glide-dir="=<?= $key; ?>" aria-label="slide <?= $num; ?>"></button>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </div>
                            <button class="glide__arrow arrow--right">next</button>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if ($attributes['links'] && sizeof($attributes['links']) > 0 && $attributes['links'][0]["linkURL"] !== ""): ?>
                    <div class="purdue-home-instagram-feed__list-container mobile-show">
                        <ul class="purdue-home-instagram-feed__list">
                            <?php foreach ($attributes['links'] as $key => $link): ?>
                                <?php $target = $link["external"] ? 'target="_blank"' : 'target="_self"'; ?>
                                <li>
                                    <a title="<?= $link["linkText"]; ?>" href="<?= $link["linkURL"]; ?>" <?= $target; ?>>
                                        <span class="screen-reader-text"><?= $link["linkText"]; ?></span>
                                        <?php if(strtolower($link["linkText"]) != "twitter"){ ?>
                                            <i class="fab fa-<?= strtolower($link["linkText"]); ?>" aria-hidden="true"></i>
                                        <?php }else{ ?>
                                            <i class="fa-brands fa-x-twitter" aria-hidden="true"></i>
                                        <?php } ?>
                                    </a>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

            </div>
        </div>
    </div>
</div>
</div>
</div>
<?php if ($attributes['type'] == "facebook" && $attributes['items'] != ""): ?>
    <?php foreach ($attributes['items'] as $key => $item): ?>
        <?php if ($key < 6): ?>
            <div id="feed-modal-<?= $key; ?>" class="instagram-feed-modal modal">
                <div class="modal-background"></div>
                <div class="modal-close" aria-label="close"></div>
                <div class="modal-content">
                    <?php if ($item["media_type"] == "VIDEO"): ?>
                        <div class="iframe-container-feed">
                            <iframe class="embed-video" title="<?= $item["caption"]; ?>" src="" data-src="<?= $item["media_url"]; ?>" frameborder="0" allow="fullscreen"></iframe>
                        </div>
                    <?php elseif ($item["media_type"] == "IMAGE"): ?>
                        <figure class="image">
                            <img src="<?= $item["media_url"]; ?>" alt="<?= $item["caption"]; ?>" />
                        </figure>
                    <?php else: ?>
                        <?php $children = $item["children"]["data"];?>
                        <div class="flex-container">
                            <?php foreach ($children as $key => $child): ?>
                                <?php if ($child["media_type"] == "VIDEO"): ?>
                                    <div class="iframe-container-feed">
                                        <iframe class="embed-video" title="video player" src="" data-src="<?= $child["media_url"]; ?>" frameborder="0" allow="fullscreen"></iframe>
                                    </div>
                                <?php elseif ($child["media_type"] == "IMAGE"): ?>
                                    <figure class="image">
                                        <img src="<?= $child["media_url"]; ?>" alt="" />
                                    </figure>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    <?php endforeach; ?>
<?php endif; ?>
