<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package purdue-home-theme
 */
?>

</div><!-- #content -->
<?php 
 if(get_theme_mod('footer_image')){
	$url=wp_get_attachment_image_src( get_theme_mod('footer_image'), 'full' )[0];
 }else{
	$url="";
 }

?>
<footer id="colophon" role="contentinfo" class="footer" style="background-image: url(<?php echo $url;?>)">

	<div class="footer__global__resources">
		<div class="container is-fullhd">
			<div class="columns is-desktop">
				<div class="column is-four-fifths-desktop">
					<div class="contact-info">
						<div class="columns">
							<div class="column is-half-mobile">
								<div class="columns is-desktop">
									<div class="column is-half-desktop">
									<?php 
										$ftr_link = "https://www.purdue.edu/";
										echo '<a href="' . $ftr_link . '" rel="home"><img src="'.get_template_directory_uri().'/imgs/PU-V.svg" alt="Purdue Logo"></a>';
									?>
									</div>
									<div class="column is-half-desktop">
										<p class="contact-info__address">
										<?php
											$ftr_add1 = get_theme_mod('address_line_1', 'Purdue University');
											$ftr_add2 = get_theme_mod('address_line_2', '610 Purdue Mall');
											$ftr_add3 = get_theme_mod('address_line_3', '');
											$ftr_city = get_theme_mod('city', 'West Lafayette');
											$ftr_state = get_theme_mod('state', 'IN');
											$ftr_zip = get_theme_mod('zipcode', '47906');
											$ftr_phone = get_theme_mod('phone_number', '765-494-4600');
											if (($ftr_add1 == '') || ($ftr_city == '') || ($ftr_state == '') || ($ftr_zip == '')) {
												echo('<a href="https://www.google.com/maps/search/?api=1&query=610+Purdue+Mall%2CWest+Lafayette%2CIN%2C47907" target="_blank">');
												echo ('Purdue University<br/>');
												echo ('610 Purdue Mall<br/>');
												echo ('West Lafayette, IN 47906');
												echo('</a>');
											} else {
												if($ftr_add1 != ''){
													$add1=str_replace(" ", "+", $ftr_add1);
													if(strpos($add1, ',')!== false){
														$add1=str_replace(",", "%2C", $add1);
													}
													$add1=$add1."%2C";
												}else{
													$add1="";
												}
												if($ftr_add2 != ''){
													$add2=str_replace(" ", "+", $ftr_add2);
													if(strpos($add2, ',')!== false){
														$add2=str_replace(",", "%2C", $add2);
													}
													$add2=$add2."%2C";
												}else{
													$add2="";
												}
												if($ftr_add3 != ''){
													$add3=str_replace(" ", "+", $ftr_add3);
													if(strpos($add3, ',')!== false){
														$add3=str_replace(",", "%2C", $add3);
													}
													$add3=$add3."%2C";
												}else{
													$add3="";
												}
				
												$city=str_replace(" ", "+", $ftr_city)."%2C";
												$query=$add1.$add2.$add3.$city.$ftr_state;
												echo('<a href="https://www.google.com/maps/search/?api=1&query='.$query.'" target="_blank">');
												echo (($ftr_add1 == '') ? '' : $ftr_add1 . '<br/>');
												echo (($ftr_add2 == '') ? '' : $ftr_add2 . '<br/>');
												echo (($ftr_add3 == '') ? '' : $ftr_add3 . '<br/>');
												echo (($ftr_city == '') ? '' : $ftr_city . ', ' . $ftr_state . ' ' . $ftr_zip);
												echo('</a>');
											}
										?>
										</p>
										<p class="contact-info__phone">
										<?php
											if(!($ftr_phone == '') ) {
												if(strpos($ftr_phone, '-')!== false){
													$phone=str_replace("-", "", $ftr_phone);
												}else{
													$phone=$ftr_phone;
												}
												echo (($ftr_phone == '') ? '' : '<a href="tel://' . $phone . '">' . $ftr_phone . '</a>');
											}
										?>
										</p>
										<div class="navbar-item contact-info__campuses mobile-show">
										<div class="purdue-accordion dropdown-style accordion--campus">
											<button class="accordion__heading" aria-expanded="false" aria-controls="campus-menu-mobile">
											OUR CAMPUSES
											</button>
											<ul id="campus-menu-mobile" class="accordion__content">
											<li><a href="https://www.purdue.edu/campuses/indianapolis/" rel="noopener" target="_blank">Purdue University in Indianapolis</a></li>
													<li><a href="https://purdue.edu/online" rel="noopener" target="_blank">Purdue University Online</a></li>
													<li><a href="https://www.purdueglobal.edu/" rel="noopener" target="_blank">Purdue Global</a></li>
													<li><a href="https://www.pfw.edu/" rel="noopener" target="_blank">Purdue Fort Wayne</a></li>
													<li><a href="https://www.pnw.edu/" rel="noopener" target="_blank">Purdue Northwest</a></li>
											</ul>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="column is-half-mobile social-container">
								<div class="columns is-desktop">
									<div class="column is-half-desktop">
										<h2 class="title">Follow Us</h2>
										<ul class="contact-info__social">
											<?php

												$ftr_facebook = get_theme_mod('facebook', 'https://www.facebook.com/PurdueUniversity/');
												$ftr_twitter = get_theme_mod('twitter', 'https://www.twitter.com/LifeAtPurdue');
												$ftr_linkedin = get_theme_mod('linkedin', 'https://www.linkedin.com/edu/purdue-university-18357');
												$ftr_instagram = get_theme_mod('instagram', 'https://www.instagram.com/lifeatpurdue/');
												$ftr_youtube = get_theme_mod('youtube', 'https://www.youtube.com/purdueuniversity');
												$ftr_snapchat = get_theme_mod('snapchat', 'https://www.snapchat.com/add/lifeatpurdue');
												if ($ftr_facebook != '') {
													?>
													<li class="navbar-item">
														<a title="Facebook" href="<?php echo $ftr_facebook; ?>" target="_blank">
															<span class="screen-reader-text">Facebook</span>
															<i class="fab fa-facebook" aria-hidden="true"></i> 
														</a>
													</li>
												<?php
												}

												if ($ftr_twitter != '') {
													?>
													<li class="navbar-item">
														<a title="Twitter" href="<?php echo $ftr_twitter; ?>" target="_blank">
														<span class="screen-reader-text">Twitter</span>
														 <i class="fa-brands fa-x-twitter"></i> 
														</a>
													</li>
												<?php
												}

												if ($ftr_linkedin != '') {
													?>
													<li class="navbar-item">
														<a title="LinkedIN" href="<?php echo $ftr_linkedin; ?>" target="_blank">
															<span class="screen-reader-text">LinkedIn</span>
															<i class="fab fa-linkedin" aria-hidden="true"></i> 
														</a>
													</li>
												<?php
												}

												if ($ftr_instagram != '') {
													?>
													<li class="navbar-item">
														<a title="Instagram" href="<?php echo $ftr_instagram; ?>" target="_blank">
														<span class="screen-reader-text">Instagram</span>
															<i class="fab fa-instagram" aria-hidden="true"></i> 
														</a>
													</li>
												<?php
												}

												if ($ftr_youtube != '') {
													?>
													<li class="navbar-item">
														<a title="YouTube" href="<?php echo $ftr_youtube; ?>" target="_blank">
															<span class="screen-reader-text">Youtube</span>
															<i class="fab fa-youtube-square" aria-hidden="true"></i> 
														</a>
													</li>
												<?php
												}
												if ($ftr_snapchat != '') {
													?>
													<li class="navbar-item">
														<a title="SnapChat" href="<?php echo $ftr_snapchat; ?>" target="_blank">
															<span class="screen-reader-text">snapchat</span>
															<i class="fab fa-snapchat" aria-hidden="true"></i> 
														</a>
													</li>
												<?php
												}
											?>
											
										</ul>
									</div>
									<div class="column is-half-desktop">
										<div class="contact-info__campuses navbar-item mobile-hidden">
											<div class="purdue-accordion dropdown-style accordion--campus">
												<button class="accordion__heading" aria-expanded="false" aria-controls="campus-menu">
													OUR CAMPUSES
												</button>
												<ul id="campus-menu" class="accordion__content">
													<li><a href="https://www.purdue.edu/campuses/indianapolis/" rel="noopener" target="_blank">Purdue University in Indianapolis</a></li>
													<li><a href="https://purdue.edu/online" rel="noopener" target="_blank">Purdue University Online</a></li>
													<li><a href="https://www.purdueglobal.edu/" rel="noopener" target="_blank">Purdue Global</a></li>
													<li><a href="https://www.pfw.edu/" rel="noopener" target="_blank">Purdue Fort Wayne</a></li>
													<li><a href="https://www.pnw.edu/" rel="noopener" target="_blank">Purdue Northwest</a></li>
												</ul>
											</div>

										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="link-resources columns is-multiline">
						<div class="column is-one-quarter-desktop is-full-tablet">
							<?php if(array_key_exists("footer-links-1", get_nav_menu_locations()) && wp_get_nav_menu_items(get_nav_menu_locations()['footer-links-1'])){
									purdueHome_footerLinks_1();
								}else{
									purdueBrand_footer_links("global-footer-1.json");
								}
								
							?>
						</div>
						<div class="column is-one-quarter-desktop is-full-tablet">
						<?php if(array_key_exists("footer-links-2", get_nav_menu_locations()) && wp_get_nav_menu_items(get_nav_menu_locations()['footer-links-2'])){
									purdueHome_footerLinks_2();
								}else{
									purdueBrand_footer_links("global-footer-2.json");
								}
								
							?>
						</div>
						<div class="column is-one-quarter-desktop is-full-tablet">
						<?php if(array_key_exists("footer-links-3", get_nav_menu_locations()) && wp_get_nav_menu_items(get_nav_menu_locations()['footer-links-3'])){
									purdueHome_footerLinks_3();
								}else{
									purdueBrand_footer_links("global-footer-3.json");
								}
								
							?>
						</div>
						<div class="column is-one-quarter-desktop is-full-tablet">
						<?php if(array_key_exists("footer-links-4", get_nav_menu_locations()) && wp_get_nav_menu_items(get_nav_menu_locations()['footer-links-4'])){
									purdueHome_footerLinks_4();
								}else{
									purdueBrand_footer_links("global-footer-4.json");
								}
								
							?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="footer__signature">

		<?php 
		if(is_active_sidebar( 'footer-signature' ) ){
			dynamic_sidebar('footer-signature');
		}else{
			$ftr_email = get_theme_mod('email_address', 'https://www.purdue.edu/purdue/contact-us/index.php');
		?>	
		<div class="container is-fullhd">	
			<a href="https://www.purdue.edu/securepurdue/security-programs/copyright-policies/reporting-alleged-copyright-infringement.php" target="_blank">Copyright</a>
			&copy; <?php echo date('Y'); ?> Purdue University. All Rights Reserved.<br /> 
			<a href="https://www.purdue.edu/accessibilityresources/" target="_blank">Accessibility</a> | <a href="https://www.purdue.edu/purdue/ea_eou_statement.php" target="_blank">EA/EO University</a> | <a href="https://www.purdue.edu/purdue/about/integrity_statement.php" target="_blank">Integrity Statement</a> | <a href="https://www.purdue.edu/purdue/about/privacy-notice.php" target="_blank">Privacy Policy</a> | <a href="<?php echo $ftr_email;?>">Contact Us</a>
		</div>
			<?php } ?>
		</div>
	</div>
</footer><!-- #colophon -->
</div><!-- #page -->

<?php wp_footer(); ?>
<?php
	$customJS ="";
	if (function_exists('get_field')) {	
		$customJS = get_field('custom_scripts');
		if($customJS != ""){
			echo '<script type="text/javascript">' . $customJS . '</script>';
		}
	}
	?>
</body>
</html>
