<?php
/**
 *
 * @package Purdue-brand
 */
?>
<?php get_header(); ?>

<?php if(function_exists('bcn_display')) : ?>
<div class="breadcrumbs" typeof="BreadcrumbList" vocab="https://schema.org/">   
    <?php bcn_display(); //breadcrumb from NavXT, no default since it's complex to set parent page for the posts
	?> 
</div>
<?php endif; 

if (function_exists('get_field')) {	
	$subheading = get_field('add_a_subheading');	
	$hasTag = get_field('display_a_tag_on_the_post');	
	if($hasTag&&$hasTag[0]=="Yes"){
		$tag = trim(get_field('add_tag_name'));	
	}else{
		$tag = "";
	}
	$attr = get_field('add_attributions');	
	$hasRelated = get_field('add_related_stories_section_at_the_bottom');
	$relatedTitle = get_field('add_section_title');
	$relatedLink = get_field('add_a_link_to_this_section_optional');
} else {	
	$subheading = "";
	$tag = "";
	$attr = "";
	$hasRelated = "";
	$relatedTitle = "";
	$relatedLink = "";
}
?>

<main id="site-content" role="main" class="main-content">
	<section class="section">
		<div class="container">
			<div class="columns is-centered">
				<div class="column post-content">
					<?php if($tag != ""){ ?>
						<p class="post-content__tag"><?php echo $tag; ?></p>
					<?php } ?>
						<h1 id="main-heading"><?php the_title(); ?></h1>
					<?php if($subheading != ""){ ?>
						<p class="post-content__subheading">
							<?php echo ($subheading); ?>
						</p>
					<?php } ?>
					<?php
						if ( has_post_thumbnail() ) {
					?>
						<div class="post-content__thumbnail alignwide">
						<?php
						the_post_thumbnail( array( 1344, 9999999 ), [ 'class' => 'post-content__thumbnail--image' ] );
						$post_thumbnail_object      = get_post( get_post_thumbnail_id() );
						$post_thumbnail_caption     = $post_thumbnail_object->post_excerpt;
						if($post_thumbnail_caption != ""){
						?>
						<p class="post-content__thumbnail--caption"><?= $post_thumbnail_caption ?></p>
						<?php
						}
						?>
						</div>
					<?php
					}
					?>
					<?php while (have_posts()) : the_post(); ?>
						<div class="level is-mobile post-content__byline">
			
							<div class="level-left post-content__byline--date">
								<span class="level-item"><?php echo get_the_date("F j, Y"); ?></span>|
								<span class="level-item"><?php echo get_the_author(); ?></span>
							</div>
							<div class="level-right post-content__byline--share">
								<span class="level-item">
									Share
								</span>
								<span class="level-item">
									<a class="icon is-medium" href="https://www.facebook.com/sharer/sharer.php?u=<?php the_permalink(); ?>"><span class="screen-reader-text">Facebook</span><i class="fab fa-lg fa-facebook-f"></i></a>
								</span>
								<span class="level-item">
									<a class="icon is-medium" href="https://twitter.com/intent/tweet?url=<?php the_permalink(); ?>"><span class="screen-reader-text">Twitter</span><i class="fa-brands fa-x-twitter"></i></a>
								</span>
								<span class="level-item">
									<a class="icon is-medium" href="https://www.linkedin.com/shareArticle?mini=true&url=<?php the_permalink(); ?>"><span class="screen-reader-text">LinkedIn</span><i class="fab fa-lg fa-linkedin-in"></i></a>
								</span>
								<span class="level-item">
									<a class="icon is-medium" href="mailto:placeholder@placeholder.com?body=<?php the_permalink(); ?>"><span class="screen-reader-text">Email</span><i class="fas fa-lg fa-envelope"></i></a>
								</span>
							</div>					
						</div>
						<div class="post-content__body">
							<?php the_content(); ?>
						</div>
					<?php endwhile; // end of the loop. 
					if ( $attr ) {
					?>
					<div class="post-content__attribution">
						<?= $attr ?>
					</div>
					<?php
					}
					?>
				</div>
			</div>		
		</div>
	</section>
	<?php
			if($hasRelated&&$hasRelated[0]=="Yes"){
	?>	
	<section class="section has-gray-background purdue-home-cta-grid purdue-home-post-grid">
		<div class="container purdue-home-cta-grid__cards">
			<div class="columns is-mulitline align-bottom">
				<div class="column">
					<?php
						if($relatedTitle){
					?>	
						<div class="tagged-header-container tagged-header-container-gold">
							<h2 class="tagged-header tagged-header--gold has-margin-bottom"><?= $relatedTitle ?></h2>
						</div>
					<?php
						}
					?>	
				</div>
				<?php
					if($relatedLink){
				?>	
				
				<div class="column is-narrow mobile-hidden">
					<a class="purdue-home-button has-margin-bottom" href="<?= $relatedLink ?>" target="_self">View More</a>
				</div>
				<?php
					}
				?>	
				</div>
			<div class="columns is-multiline">
			<?php
			 wp_reset_query();
			 //By Category
			 $cats = get_the_category($post->ID);
			 if ($cats) {
				 $cat_array = array();
				 foreach ($cats as $catKey => $cat) {
					 $cat_array[$catKey] = $cat->slug;
				 }
			 }
	 
			 $args = array(
				 'post__not_in' => array($post->ID),
				 'posts_per_page' => 3, // Number of related posts that will be shown.
				 'orderby' => 'date',
				 'order'   => 'DESC',
				 'tax_query' => array(
					 array(
						 'taxonomy' => 'category',
						 'field' => 'slug',
						 'terms' => $cat_array,
						 'include_children' => false
					 )
				 )
			 );
	 
			 $my_query = new wp_query($args);
			 if ($my_query->have_posts()) {
	 				 while ($my_query->have_posts()) {
					 $my_query->the_post();
					 $attributes['selectedTax']="category";
					 $attributes['buttonText']="Read More";
					 require __DIR__ . '/src/blocks/post-grid/inc/grid.php';
				 }
			 }
			 wp_reset_query();
			?>	
			</div>
			<div class="button-container mobile-show"><a class="purdue-home-button" href="<?= $relatedLink ?>" target="_self">View More</a></div>
		</div>
	</section>
	<?php
			}
	?>	
	<button id="to-top" class="to-top-hidden" aria-label="Back to Top Button">
		<span class="icon"><i class="fa-solid fa-arrow-up" aria-hidden="true"></i></span>
	</button>
</main><!-- #site-content -->

<?php get_footer(); ?>