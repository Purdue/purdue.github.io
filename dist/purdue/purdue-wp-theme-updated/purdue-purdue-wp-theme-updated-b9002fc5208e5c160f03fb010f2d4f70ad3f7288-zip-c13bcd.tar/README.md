# Purdue WordPress Theme
WordPress theme forked from purdue-wp-theme.
Updated Header and footer to match purdue-home-theme.

