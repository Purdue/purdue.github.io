# HHS Blocks Plugin

Adds Purdue University branded Gutenberg blocks to the editor

## Changelog



