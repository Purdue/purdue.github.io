<?php

/**
 * Plugin Name: HHS Blocks
 * Plugin URI: https://github.com/purdue/hhs-blocks/
 * Description: Adds Gutenberg blocks to Wordpress based on Purdue's brand elements.
 * Author: Purdue Marketing and Media
 * Author URI: https://brand.purdue.edu/digital/
 * Version: 1.1.0
 * License: GPLv3
 * License URI: https://www.gnu.org/licenses/gpl-3.0.en.html
 *
 * @package CGB
 */

// Exit if accessed directly.
if (!defined('ABSPATH')) {
  exit;
}

/**
 * Block Initializer.
 */

require_once plugin_dir_path(__FILE__) . 'src/init.php';



