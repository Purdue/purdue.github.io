const { __ } = wp.i18n; // Import __() from wp.i18n
const { registerBlockType } = wp.blocks; // Import registerBlockType() from wp.blocks

const {
  PanelBody,
  PanelRow,
  TextareaControl,
  TextControl,
  Button,
  RadioControl,
  CheckboxControl,
  SelectControl
} = wp.components;
const {  RichText,InspectorControls, MediaUploadCheck, MediaUpload, InnerBlocks } = wp.blockEditor;

const BLOCKS_TEMPLATE = [
  [ 'core/paragraph', { placeholder: 'Body content copy' } ],
];
/**
 * Register: aa Gutenberg Block.
 *
 * Registers a new block provided a unique name and an object defining its
 * behavior. Once registered, the block is made editor as an option to any
 * editor interface where blocks are implemented.
 *
 * @link https://wordpress.org/gutenberg/handbook/block-api/
 * @param  {string}   name     Block name.
 * @param  {Object}   settings Block settings.
 * @return {?WPBlock}          The block, if it has been successfully
 *                             registered; otherwise `undefined`.
 */
registerBlockType( 'hhs-blocks/hhs-feature-story', {
  // Block name. Block names must be string that contains a namespace prefix. Example: my-plugin/my-custom-block.
  title: __( 'HHS Featured Story' ), // Block title.
  icon: (
    <svg id="Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 68.75 100"><defs></defs><g id="lightbulb" class="cls-1"><g class="cls-1"><path class="cls-2" d="M84.38,34.38A34.21,34.21,0,0,1,75.87,57c-3.25,3.71-8.35,11.49-10.24,18H56.26v0a11,11,0,0,1,.43-2.79A61.73,61.73,0,0,1,68.82,50.81a25,25,0,1,0-37.64,0A61.7,61.7,0,0,1,43.33,72.23,9.49,9.49,0,0,1,43.74,75v0H34.37c-1.89-6.51-7-14.29-10.24-18A34.37,34.37,0,1,1,84.38,34.38ZM53.12,18.75A3.12,3.12,0,0,1,50,21.88a12.51,12.51,0,0,0-12.5,12.5,3.13,3.13,0,0,1-6.25,0A18.77,18.77,0,0,1,50,15.63,3.11,3.11,0,0,1,53.12,18.75ZM34.38,81.25H65.62v8.43a3.11,3.11,0,0,1-.52,1.73L60.3,98.6a3.1,3.1,0,0,1-2.6,1.4H42.3a3.1,3.1,0,0,1-2.6-1.4l-4.79-7.19a3.11,3.11,0,0,1-.52-1.73Z" transform="translate(-15.62)"/></g></g></svg>
    ), // Block icon from Dashicons → https://developer.wordpress.org/resource/dashicons/.
  category: 'hhs-blocks', // Block category — Group blocks together based on common traits E.g. common, formatting, layout widgets, embed.
  keywords: [],

  /**
   * The edit function describes the structure of your block in the context of the editor.
   * This represents what the editor will render when the block is used.
   *
   * The "edit" property must be a valid function.
   *
   * @link https://wordpress.org/gutenberg/handbook/block-api/block-edit-save/
   *
   * @param {Object} props Props.
   * @returns {Mixed} JSX Component.
   */

  attributes: {
    storyTitle: { type: 'string', source: 'html', selector: '.story-title' },
    backgroundColor: { type: 'string', default: 'white' },
    imgUrl: { type: 'string', default: '' },
    altText: { type: 'string', default: '' },
    imageAlign: { type: 'string', default: 'left' },
    hasLink: { type: 'boolean', default: false },
    ctaUrl: { type: 'string', default: '' },
    ctaText: { type: 'string', default: '' },
    external: { type: 'boolean', default: false },
    headerLevel: { type: 'string', default: 'h2' },
    addPaddingTop:{ type: 'boolean', default: true },
    addPaddingBottom:{ type: 'boolean', default: true },
    addExtraPaddingTop:{ type: 'boolean', default: false },
    addExtraPaddingBottom:{ type: 'boolean', default: false },
    addBorder: { type: 'boolean', default: false },
    id: { type: 'string', default: '' },
  },

  supports: {
    className: false,
  },

  // Block description in side panel
  description: __(
    'This block adds a featured story row on the page.'
  ),

  edit: ( props ) => {
    const removeMedia = () => {
      props.setAttributes({
        imgUrl: ''
      });
    }
    return [
      <InspectorControls>
        <PanelBody>
            <PanelRow>
              <TextControl
                label="HTML Anchor"
                help="Enter a word without spaces to make a unique web address just for this block, called an “anchor.” It must be unique from any other anchors on the page. Then, you’ll be able to link directly to this section of your page."
                value={ props.attributes.id }
                onChange={ ( id ) => props.setAttributes( { id } ) }
              />
            </PanelRow>
            <PanelRow>
              <RadioControl
                label="Background Color"
                help="Choose the background color."
                selected={ props.attributes.backgroundColor }
                options={ [
                  { label: 'White', value: 'white' },
                  { label: 'Light Gray', value: 'gray' },
                  { label: 'Dark', value: 'dark' },
                ] }
                onChange={ ( option ) => {
                  props.setAttributes( { backgroundColor: option } )
                } }
              />
            </PanelRow>

          <PanelRow>
            <RadioControl
              label="Image Alignment"
              help="Choose to place the image to the left or right."
              selected={ props.attributes.imageAlign }
              options={ [
                { label: 'Left', value: 'left' },
                { label: 'Right', value: 'right' },
              ] }
              onChange={ ( option ) => {
                props.setAttributes( { imageAlign: option } )
              } }
            />
          </PanelRow>
          <PanelRow>
            <SelectControl
              label="Heading Level of the Header"
              help="This only changes the HTML tag. The styles will stay the same."
              value={ props.attributes.headerLevel }
              options={ [
                { label: 'H2', value: 'h2' },
                { label: 'H3', value: 'h3' },
                { label: 'H4', value: 'h4' },
                { label: 'H5', value: 'h5' },
                { label: 'H6', value: 'h6' },
              ] }
              onChange={ ( headerLevel ) => {
                props.setAttributes( { headerLevel } )
              } }
            />
          </PanelRow>
        </PanelBody>
        <PanelBody>
        <PanelRow>
            <CheckboxControl
              label="Add a CTA link?"
              checked={ props.attributes.hasLink }
              onChange={ () =>
                props.setAttributes( { hasLink: ! props.attributes.hasLink } )
              }
            />
          </PanelRow>
          { props.attributes.hasLink ?
            ( <PanelRow>
              <TextControl
                label="Call to action text"
                value={ props.attributes.ctaText }
                onChange={ ( ctaText ) => props.setAttributes( { ctaText } ) }
              />
            </PanelRow> ) : '' }
          { props.attributes.hasLink ? (
            <PanelRow>
              <TextControl
                label="Link address"
                value={ props.attributes.ctaUrl }
                onChange={ ( ctaUrl ) => props.setAttributes( { ctaUrl } ) }
              />
            </PanelRow> ) : '' }

          { props.attributes.hasLink ?
            <PanelRow>
              <CheckboxControl
                label="Open link in new tab?"
                checked={ props.attributes.external }
                onChange={ () =>
                  props.setAttributes( { external: ! props.attributes.external } )
                }
              />
            </PanelRow> : '' }
          <PanelRow>
            <TextareaControl
              label="Featured Image Alt Text"
              value={ props.attributes.altText }
              onChange={ ( altText ) => props.setAttributes( { altText } ) }
            />
          </PanelRow>
          <PanelRow>
            <CheckboxControl
              label="Add a Border?"
              checked={ props.attributes.addBorder }
              onChange={ () =>
                props.setAttributes( { addBorder: ! props.attributes.addBorder } ) }
            />
          </PanelRow>
          <PanelRow>
              <CheckboxControl
                label="Add padding at the top on desktop?"
                checked={props.attributes.addPaddingTop}
                onChange={(checked) => props.setAttributes({ addPaddingTop: checked })}
              />
          </PanelRow>
          <PanelRow>
              <CheckboxControl
                label="Add padding at the bottom on desktop?"
                checked={props.attributes.addPaddingBottom}
                onChange={(checked) => props.setAttributes({ addPaddingBottom: checked })}
              />
          </PanelRow>
          {props.attributes.addPaddingTop?
          <PanelRow>
              <CheckboxControl
                label="Add extra padding at the top on desktop??"
                checked={props.attributes.addExtraPaddingTop}
                onChange={(checked) => props.setAttributes({ addExtraPaddingTop: checked })}
              />
          </PanelRow>:""}
          {props.attributes.addPaddingBottom?
          <PanelRow>
              <CheckboxControl
                label="Add extra padding at the bottom on desktop??"
                checked={props.attributes.addExtraPaddingBottom}
                onChange={(checked) => props.setAttributes({ addExtraPaddingBottom: checked })}
              />
          </PanelRow>:""}
        </PanelBody>
      </InspectorControls>,

      <div className={ `hhs-feature-story hhs-feature-story-editor animate
        ${props.attributes.addExtraPaddingTop&&props.attributes.addPaddingTop ? ` hhs-feature-story--padding-top-extra`:''}
        ${props.attributes.addPaddingTop ? ` hhs-feature-story--padding-top`:''}
        ${props.attributes.addPaddingBottom ? `  hhs-feature-story--padding-bottom`:''}
        ${props.attributes.addExtraPaddingBottom&&props.attributes.addPaddingBottom ? ` hhs-feature-story--padding-bottom-extra`:''}
        ${props.attributes.backgroundColor==="gray" ? ` hhs-feature-story--gray`:''}
        ${props.attributes.backgroundColor==="dark" ? ` hhs-feature-story--dark`:''}
        ${props.attributes.backgroundColor==="white" ? ` hhs-feature-story--white`:''}
        ${ props.attributes.addBorder? " hhs-feature-story--border":"" }
        ${props.attributes.imageAlign === 'left' ? '' : ' hhs-feature-story--reversed'}
        `}
         >
      <div className="hero is-medium">
        <MediaUploadCheck>
          <MediaUpload
            onSelect={ ( img ) => {
              props.setAttributes( {
                imgUrl: img.url,
                altText:
                    props.attributes.altText !== '' ?
                      props.attributes.altText :
                      img.alt,
              } );
            } }
            render={ ( { open } ) => {
              return (
                <div className={ `hero-image` }>
                    <span
                      className="background-image"
                      role="img"
                      style={ { backgroundImage: `url(${ props.attributes.imgUrl })` } }
                      aria-label={ props.attributes.altText }
                    />
                  <div className="image-buttons">
                  <Button className={ 'remove-image-button' } onClick={ open }>{ props.attributes.imgUrl !== '' ? 'Select a new image' : 'Select an image' }</Button>
                  { props.attributes.imgUrl ?
                  <Button className={ 'remove-image-button' } onClick={removeMedia}>
                      Remove image
                  </Button>:""}  
                  </div>                    
                </div>
              );
            } }
          />
        </MediaUploadCheck>
    
        <div className="hero-body">
          <div className="container">
            <div className={ `content`}>
              <RichText
                  tagName={ props.attributes.headerLevel }
                  value={ props.attributes.storyTitle }
                  className={ 'story-title' }
                  onChange={ ( storyTitle ) => {
                    props.setAttributes( { storyTitle } )
                  } }
                  placeholder="Add header"
                  keepPlaceholderOnFocus={ true }
                >
                </RichText>
                <InnerBlocks
                  template={ BLOCKS_TEMPLATE }
                  templateLock={ false }
                />
              { props.attributes.hasLink ? <div className="read-more-button"><span>{ props.attributes.ctaText }</span></div> : '' }
            </div>
          </div>
        </div>
      </div>
      </div>,
    ];
  },

  /**
   * The save function defines the way in which the different attributes should be combined
   * into the final markup, which is then serialized by Gutenberg into post_content.
   *
   * The "save" property must be specified and must be a valid function.
   *
   * @link https://wordpress.org/gutenberg/handbook/block-api/block-edit-save/
   *
   * @param {Object} props Props.
   * @returns {Mixed} JSX Frontend HTML.
   */
  save: ( props ) => {
    const returned = <div 
        id={ props.attributes.id?props.attributes.id:null }
        className={ `hhs-feature-story
        ${props.attributes.addExtraPaddingTop&&props.attributes.addPaddingTop ? ` hhs-feature-story--padding-top-extra`:''}
        ${props.attributes.addPaddingTop ? ` hhs-feature-story--padding-top`:''}
        ${props.attributes.addPaddingBottom ? `  hhs-feature-story--padding-bottom`:''}
        ${props.attributes.addExtraPaddingBottom&&props.attributes.addPaddingBottom ? ` hhs-feature-story--padding-bottom-extra`:''}
        ${props.attributes.backgroundColor==="gray" ? ` hhs-feature-story--gray`:''}
        ${props.attributes.backgroundColor==="dark" ? ` hhs-feature-story--dark`:''}
        ${props.attributes.backgroundColor==="white" ? ` hhs-feature-story--white`:''}
        ${ props.attributes.addBorder? " hhs-feature-story--border":"" }
        ${props.attributes.imageAlign === 'left' ? '' : ' hhs-feature-story--reversed'}
        `}
         >
          <div className="hero is-medium">
            <div className={ `hero-image` }>
                <span
                  className="background-image"
                  role="img"
                  style={ { backgroundImage: `url(${ props.attributes.imgUrl })` } }
                  aria-label={ props.attributes.altText }
                />
              </div>                    
            <div className="hero-body">
              <div className="container">
                <div className={ `content`}>
                  { props.attributes.storyTitle ? ( <RichText.Content
                      tagName={ props.attributes.headerLevel }
                      value={ props.attributes.storyTitle }
                      className={ 'story-title' }
                    /> ) : '' }
                    <InnerBlocks.Content />
                    { props.attributes.hasLink ? <a className="read-more-button" href={props.attributes.ctaUrl}
                  target={ props.attributes.external ? '_blank' : '_self' }
                  rel="noopener noreferrer"><span>{ props.attributes.ctaText }</span></a> : '' }
                </div>
              </div>
            </div>
          </div>
    </div> ;
    return returned;
  },
} );
