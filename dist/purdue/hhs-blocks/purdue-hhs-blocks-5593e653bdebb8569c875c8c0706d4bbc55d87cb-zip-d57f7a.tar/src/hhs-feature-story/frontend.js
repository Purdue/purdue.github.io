const stories=[...document.querySelectorAll(".hhs-feature-story")]
const wH=window.innerHeight;
window.addEventListener('scroll', () => {
    if(stories&&stories.length>0){
        stories.forEach((t)=>{
            const thisTop = t.getBoundingClientRect().top;
            if(thisTop<=wH*0.5){
                t.classList.add('animate')
            }
        })
    }
})