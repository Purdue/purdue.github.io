const lists=[...document.querySelectorAll(".hhs-list")]
const wH=window.innerHeight;
window.addEventListener('scroll', () => {
    if(lists&&lists.length>0){
        lists.forEach((t)=>{
            const thisTop = t.getBoundingClientRect().top;
            if(thisTop<=wH*0.5){
                t.classList.add('animate')
            }
        })
    }
})