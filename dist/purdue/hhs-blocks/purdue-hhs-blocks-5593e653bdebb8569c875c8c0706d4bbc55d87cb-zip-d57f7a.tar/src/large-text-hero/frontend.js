const largeText=[...document.querySelectorAll(".hhs-large-text-hero")]
const width=window.innerWidth;
window.addEventListener('load', () => {
    if(largeText&&largeText.length>0){
        largeText.forEach((t)=>{
            t.classList.add('animate')
            const background=t.querySelector(".background-image")
            const datasrc=background.dataset.src
            let imageURLs=[]
            let imagURL=""
            if(datasrc.length>0){
                imageURLs = datasrc.split(", ")
                imagURL = imageURLs[Math.floor(Math.random()*imageURLs.length)]
                if(width>767){
                    background.style.backgroundImage = `url(${imagURL})`;
                }
            }
        })
    }
})
window.addEventListener('resize', () => {
    let newWidth=window.innerWidth;
    if(largeText&&largeText.length>0){
        largeText.forEach((t)=>{
            const background=t.querySelector(".background-image")
            const datasrc=background.dataset.src
            const datasrc1=background.dataset.srcMobile
            let imageURLs=[]
            let imagURL=""
            if(datasrc.length>0){
                imageURLs = datasrc.split(", ")
                imagURL = imageURLs[Math.floor(Math.random()*imageURLs.length)]
            }else{
                imagURL = datasrc1
            }
            if(newWidth>767){
                background.style.backgroundImage = `url(${imagURL})`;
            }else{
                background.style.backgroundImage = `url(${datasrc1})`;
            }
        })
    }
})