<?php

if ( ! class_exists( 'PurduePostType' ) ) :
    require_once dirname( __FILE__ ) . '/base-cpt.php';
endif;

if ( ! class_exists( 'PurdueOurWorkCPT' ) ) :
	class PurdueOurWorkCPT extends PurduePostType {
        protected $slug = 'our-work';
        protected $singular = 'Our Work';
        protected $plural = 'Our Work';
        
        function __construct() {
            
            $names = array(
                'name'     => $this->slug,
                'singular' => __($this->singular, 'purdue'),
                'plural'   => __($this->plural, 'purdue'), 
                'slug'     => $this->slug,
            );
    
            $labels = array(
                'archives'              => __('Case Study Archives', 'purdue'),
                'attributes'            => __('Post Attributes', 'purdue'),
                'parent_item_colon'     => __('Parent Case Study:', 'purdue'),
                'all_items'             => __('All Case Studies', 'purdue'),
                'add_new_item'          => __('Add New Case Study', 'purdue'),
                'new_item'              => __('New Case Study', 'purdue'),
                'edit_item'             => __('Edit Case Study', 'purdue'),
                'update_item'           => __('Update Case Study', 'purdue'),
                'view_item'             => __('View Case Study', 'purdue'),
                'view_items'            => __('View Case Studies', 'purdue'),
                'search_items'          => __('Search Case Studies', 'purdue'),
            );
    
            $options = array( 
                'has_archive' => 'ourwork',
                'taxonomies' => array(),
                'menu_icon' => 'data:image/svg+xml;base64,' . base64_encode('<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 1000 1000" fill="currentColor" xml:space="preserve"><g><g transform="translate(0.000000,512.000000) scale(0.100000,-0.100000)"><path d="M414,5007.7c-101.5-24.9-197.2-95.7-252.8-189.6l-51.7-90l-5.7-3724.4L100-2720.7l1026.4-1030.2l1026.4-1028.3l2502.7,3.8c2286.4,5.7,2506.6,7.6,2558.3,38.3c120.6,65.1,203,174.3,225.9,298.7l13.4,61.3h-2451H2553l-5.8,875.1l-5.7,877l-53.6,90c-34.5,59.4-84.3,109.1-143.6,143.6l-90,53.6l-875.1,5.7l-877,5.8v3473.6v3475.5h3274.4H7051V2583.5V544.1h201.1h201.1l-3.8,2093l-5.7,2091l-53.6,90c-34.5,59.4-84.3,109.1-143.6,143.6l-90,53.6l-3341.5,3.8C1976.6,5019.2,446.6,5015.4,414,5007.7z"/><path d="M6227.6,2573.9V1348.4h201.1h201.1v1225.5v1225.5h-201.1h-201.1V2573.9z"/><path d="M1813.8,3743.9c-386.8-111.1-704.7-417.4-823.4-790.8c-26.8-84.2-47.9-155.1-47.9-160.8c0-3.8,224-7.7,497.9-7.7h497.9v497.9c0,273.8-1.9,497.9-3.8,495.9C1930.6,3778.4,1877,3763.1,1813.8,3743.9z"/><path d="M2359.6,3209.7v-549.6l390.6-390.6l390.6-390.6l57.4,88.1c105.3,168.5,147.5,338.9,147.5,607c0,289.1-44,446.2-181.9,658.7c-149.4,227.9-344.7,384.9-603.2,480.6C2340.4,3797.5,2359.6,3843.5,2359.6,3209.7z"/><path d="M5423.4,2363.3V1348.4h191.5h191.5v1014.9v1014.9h-191.5h-191.5V2363.3z"/><path d="M4600,1961.2v-612.8H4801h201.1v612.8v612.8H4801H4600V1961.2z"/><path d="M942.5,2355.6c0-5.8,21.1-78.5,47.9-162.8c116.8-365.7,400.2-649.1,777.4-777.4c212.6-70.9,509.4-74.7,716.2-9.6c109.2,34.5,314,130.2,354.3,166.6c3.8,3.8-168.5,183.8-383,398.3l-392.5,392.5h-559.1C1195.3,2363.3,942.5,2359.4,942.5,2355.6z"/><path d="M3776.6,1750.5v-402.1h201.1h201.1v402.1v402.1h-201.1h-201.1V1750.5z"/><path d="M1325.5-78.2v-201.1h1426.6h1426.6v201.1v201.1H2752.1H1325.5V-78.2z"/><path d="M6723.6,103.7c-281.5-34.5-612.8-158.9-861.7-325.5c-157-107.2-407.9-358.1-515.1-515.1c-478.7-712.4-442.3-1654.5,90-2318.9c383-474.9,913.4-729.6,1528.1-729.6c337,0,639.6,74.7,928.7,231.7l67,36.4l603.2-601.3c587.9-586,605.1-601.3,716.2-631.9c273.8-78.5,549.6,90,608.9,373.4c17.2,88.1,15.3,124.5-11.5,220.2c-32.5,113-44,126.4-633.8,718.1l-601.3,603.2l36.4,67c266.2,492.1,306.4,1080,113,1618.1C8491-319.5,7619.7,207.1,6723.6,103.7z M7303.8-403.7c503.6-130.2,896.2-492.1,1060.8-976.6c42.1-126.4,53.6-197.2,61.3-396.4c11.5-310.2-23-465.3-155.1-729.6c-82.3-166.6-122.6-222.1-270-369.6c-147.4-147.4-203-187.7-369.6-270c-264.3-132.1-419.4-166.6-729.6-155.1c-281.5,9.6-457.7,59.4-683.6,191.5c-162.8,95.7-432.8,363.8-524.7,518.9c-530.4,901.9,21.1,2052.8,1060.9,2213.6C6895.9-353.9,7165.9-367.3,7303.8-403.7z"/><path d="M1325.5-901.6v-201.1h1426.6h1426.6v201.1v201.1H2752.1H1325.5V-901.6z"/><path d="M1325.5-1715.4v-191.5h1426.6h1426.6v191.5v191.5H2752.1H1325.5V-1715.4z"/></g></g></svg>')
            );

            parent::__construct($names, $options, $labels);
            $this->add_campaign_tax();
            $this->add_message_tax();
        }

        private function add_campaign_tax() {
            $names = [
                'name' => 'campaigns',
                'singular' => 'Campaign',
                'plural' => 'Campaigns',
                'slug' => 'campaigns'
            ];

            $terms = array (
                array( 'term' => 'Protect Purdue', 'slug' => 'protect-purdue'),
                array( 'term' => 'Affordability', 'slug' => 'affordability'),
                array( 'term' => 'Reasons to Believe', 'slug' => 'rtb'),
            );

            $this->add_taxonomy($names, array(), $terms);
        }

        private function add_message_tax() {
            $names = [
                'name' => 'brand_theme',
                'singular' => 'Theme',
                'plural' => 'Themes',
                'slug' => 'brand_themes'
            ];

            $terms = array (
                array( 'term' => 'World Changing Research', 'slug' => 'research'),
                array( 'term' => 'Transformative Education', 'slug' => 'education'),
                array( 'term' => 'Experience', 'slug' => 'experience'),
                array( 'term' => 'Culture', 'slug' => 'culture'),
            );

            $this->add_taxonomy($names, array('show_in_rest' => true), $terms);
        }
    
    }

    $PurdueOurWorkCPT = new PurdueOurWorkCPT();

endif;