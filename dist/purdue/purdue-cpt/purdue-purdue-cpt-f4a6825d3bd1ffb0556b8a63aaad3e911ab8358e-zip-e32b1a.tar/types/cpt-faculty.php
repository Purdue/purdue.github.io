<?php

if ( ! class_exists( 'PurduePostType' ) ) :
    require_once dirname( __FILE__ ) . '/base-cpt.php';
endif;

if ( ! class_exists( 'PurdueFacultyCPT' ) ) :
	class PurdueFacultyCPT extends PurduePostType {
        protected $slug = 'faculty';
        protected $singular = 'Faculty';
        protected $plural = 'Faculty';
        protected $classicEditor = true;

        function __construct() {
            
            $names = array(
                'name'     => $this->slug,
                'singular' => __($this->singular, 'purdue'),
                'plural'   => __($this->plural, 'purdue'), 
                'slug'     => $this->slug,
            );
    
            $labels = array(
                'add_new_item'          => __('Add Faculty Member', 'purdue'),
                'add_new'               => __('Add New', 'purdue'),
                'new_item'              => __('New Faculty Member', 'purdue'),
                'edit_item'             => __('Edit Faculty Member', 'purdue'),
                'update_item'           => __('Update Faculty Member', 'purdue'),
                'not_found'             => __('Not found', 'purdue'),
                'not_found_in_trash'    => __('Not found in Trash', 'purdue'), 
            );
    
            $options = array('menu_icon' => 'dashicons-groups');

            parent::__construct($names, $options, $labels);
            $this->add_unit_tax();
            $this->add_expertise_tax();
        }

        private function add_unit_tax() {
            $names = [
                'name' => 'academic-unit',
                'singular' => 'Academic Unit',
                'plural' => 'Academic Units',
                'slug' => 'academic-unit'
            ];

            $terms = array (
                array( 'term' => 'College of Agriculture', 'slug' => 'agriculture'),
                array( 'term' => 'College of Education', 'slug' => 'education'),
                array( 'term' => 'College of Engineering', 'slug' => 'engineering'),
                array( 'term' => 'Exploratory Studies', 'slug' => 'exploratory-studies'),
                array( 'term' => 'College of Health and Human Sciences', 'slug' => 'hhs'),
                array( 'term' => 'College of Liberal Arts', 'slug' => 'liberal-arts'),
                array( 'term' => 'Krannert School of Management', 'slug' => 'management'),
                array( 'term' => 'College of Pharmacy', 'slug' => 'pharmacy'),
                array( 'term' => 'Purdue Polytechnic Institute', 'slug' => 'polytechnic'),
                array( 'term' => 'College of Science', 'slug' => 'science'),
                array( 'term' => 'College of Veterinary Medicine', 'slug' => 'vet'),
                array( 'term' => 'The Honors College', 'slug' => 'honors'),
                array( 'term' => 'The Graduate School', 'slug' => 'graduate'),
            );

            $this->add_taxonomy($names, array(), $terms);
        }

        private function add_expertise_tax() {
            $names = [
                'name' => 'expertise',
                'singular' => 'Expertise',
                'plural' => 'Expertise',
                'slug' => 'expertise'
            ];
            $terms = array();

            $this->add_taxonomy($names, array(), $terms);
        }

    
    }

    $PurdueFacultyCPT = new PurdueFacultyCPT();

endif;