<?php

/*
Plugin Name: Purdue Post Types
Description: Create custom post types used by Purdue University WordPress websites
Author: Purdue Marketing and Communications
Author URI: https://marcom.purdue.edu/
Version: 1.4.0
 
License:     GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

------------------------------------------------------------------------

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/

 
if ( !defined('ABSPATH') ) {
	header( 'HTTP/1.0 403 Forbidden' );
	die;
}

require __DIR__ . '/vendor/autoload.php';

if ( ! function_exists('write_log')) {
    function write_log ( $log )  {
       if ( is_array( $log ) || is_object( $log ) ) {
          error_log( print_r( $log, true ) );
       } else {
          error_log( $log );
       }
    }
 }

if ( ! class_exists( 'PurduePostTypes' ) ) :

    class PurduePostTypes {
        private $_settings = array();
        private $_classic = array();
        private $_types = array();

        public function __construct() {
            $this->includes();
            $this->hooks();
        }

        private function includes() {
            require_once dirname( __FILE__ ) . '/types/base-cpt.php';
            foreach (glob(dirname( __FILE__ ) . "/types/cpt-*.php") as $filename)
            {
                include_once $filename;
            }

            foreach(get_declared_classes() as $class){
                if(is_subclass_of( $class, 'PurduePostType' ) ) {
                    $this->_types[] = array ('class' => $class, 'name' => ${$class}->getName(), 'slug' => ${$class}->getPath() );
                    if ( ${$class}->isClassic() ) {
                        $this->_classic[] = ${$class}->getPath();
                    }
                }
            }

            write_log($this->_types);
            
            require_once dirname( __FILE__ ) . '/admin/cpt-config-options.php';
            new PurdueCPT_Settings_Page($this->_types);
        }

        public function allTypes() {
            return $this->_types;
        }

        

        private function hooks() {
            // add_filter('use_block_editor_for_post_type', array( $this, 'disable_gutenberg'), 10, 2);
        }

        /*

        NEEDS WORK
        
        public function disable_gutenberg ($is_enabled, $post_type) {
            if ( in_array($post_type,  $this->_classic) ) {
                return false;
            }

            return $is_enabled;
        }
        */
        
    }

    $PurdueCPT = new PurduePostTypes();
endif;
