<?php

if ( ! class_exists( 'PurduePostType' ) ) :
    require_once dirname( __FILE__ ) . '/base-cpt.php';
endif;

if ( ! class_exists( 'PurdueContentPkgCPT' ) ) :
	class PurdueContentPkgCPT extends PurduePostType {
        protected $slug = 'contentpkg';
        protected $singular = 'Content Package';
        protected $plural = 'Content Packages';
        
        function __construct() {
            
            $names = array(
                'name'     => $this->slug,
                'singular' => __($this->singular, 'purdue'),
                'plural'   => __($this->plural, 'purdue'), 
                'slug'     => $this->slug,
            );
    
            $labels = array(
                'archives'              => __('Package Archives', 'purdue'),
                'attributes'            => __('Post Attributes', 'purdue'),
                'parent_item_colon'     => __('Parent Package:', 'purdue'),
                'all_items'             => __('All Content Packages', 'purdue'),
                'add_new_item'          => __('Add New Content Package', 'purdue'),
                'new_item'              => __('New Content Package', 'purdue'),
                'edit_item'             => __('Edit Content Package', 'purdue'),
                'update_item'           => __('Update Content Package', 'purdue'),
                'view_item'             => __('View Content Package', 'purdue'),
                'view_items'            => __('View Content Packages', 'purdue'),
                'search_items'          => __('Search Content Packages', 'purdue'),
            );
    
            $options = array( 
                'menu_icon' => 'data:image/svg+xml;base64,' . base64_encode('<svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 464.585 464.585" style="enable-background:new 0 0 464.585 464.585;" xml:space="preserve"><g><path d="M464.585,393.312L377.122,78.297L301.73,99.229l8.329,29.998h-83.857V87.446h-78.243v30.92h-42.373V50.207H0v364.17h90.586	h15h42.373h15h48.243h15h98.153V180.715l64.838,233.528L464.585,393.312z M162.959,102.446h48.243v37.147h-48.243V102.446z	 M162.959,201.81h48.243v170.575h-48.243V201.81z M162.959,186.81v-8.608h48.243v8.608H162.959z M162.959,163.202v-8.609h48.243	v8.609H162.959z M90.586,370.189H15V94.199h75.586V370.189z M90.586,65.207v13.992H15V65.207H90.586z M15,399.378v-14.189h75.586	v14.189H15z M147.959,399.378h-42.373V133.366h42.373V399.378z M162.959,399.378v-11.993h48.243v11.993H162.959z M309.355,399.378	h-83.153V144.226h83.153V399.378z M399.634,395.778l-52.742-189.961l46.485-12.907l52.742,189.961L399.634,395.778z	 M342.879,191.364l-4.133-14.884l46.485-12.907l4.133,14.884L342.879,191.364z M366.681,96.762l14.537,52.358l-46.485,12.907	l-14.537-52.358L366.681,96.762z"/><rect x="243.621" y="160.457" width="48.315" height="15"/><rect x="243.621" y="186.81" width="48.315" height="15"/><rect x="243.621" y="213.164" width="48.315" height="15"/><rect x="243.621" y="365.797" width="48.315" height="15"/><rect x="119.272" y="272.274" width="15" height="25.255"/><rect x="119.272" y="311.805" width="15" height="57.099"/><rect x="119.272" y="189.919" width="15" height="68.081"/><rect x="119.272" y="150.387" width="15" height="26.354"/></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g></svg>')
            );

            parent::__construct($names, $options, $labels);
            $this->add_campaign_tax();
            $this->add_message_tax();
        }

        private function add_campaign_tax() {
            $names = [
                'name' => 'campaigns',
                'singular' => 'Campaign',
                'plural' => 'Campaigns',
                'slug' => 'campaigns'
            ];

            $terms = array (
                array( 'term' => 'Protect Purdue', 'slug' => 'protect-purdue'),
                array( 'term' => 'Affordability', 'slug' => 'affordability'),
                array( 'term' => 'Reasons to Believe', 'slug' => 'rtb'),
            );

            $this->add_taxonomy($names, array(), $terms);
        }

        private function add_message_tax() {
            $names = [
                'name' => 'messages',
                'singular' => 'Message',
                'plural' => 'Messages',
                'slug' => 'messages'
            ];

            $terms = array (
            );

            $this->add_taxonomy($names, array(), $terms);
        }
    
    }

    $PurdueContentPkgCPT = new PurdueContentPkgCPT();

endif;