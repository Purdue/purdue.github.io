<?php

/*
Plugin Name: Purdue Post Types
Description: Create custom post types used by Purdue University WordPress websites
Author: Purdue Marketing and Media
Author URI: https://brand.purdue.edu/digital/
Version: 0.2.1
 
License:     GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

------------------------------------------------------------------------

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/

if ( !defined('ABSPATH') ) {
	header( 'HTTP/1.0 403 Forbidden' );
	die;
}

require __DIR__ . '/vendor/autoload.php';

if ( ! class_exists( 'PurduePostTypes' ) ) :

    class PurduePostTypes {
        private $_settings = array();
        private $_classic = array();

        public function __construct() {
            $this->includes();
            $this->hooks();
        }

        private function includes() {
            require_once dirname( __FILE__ ) . '/admin/posttype-config-options.php';
            require_once dirname( __FILE__ ) . '/inc/class-purdue-posttype.php';

            // unregister_taxonomy('academic-unit');
            // unregister_post_type('faculty');
            // $addFaculty = (empty(checked(1, get_option('purdue-faculty-cpt'), false)));
           
            if ( empty(get_option('purdue-faculty-cpt')) === false ) {
                // require_once dirname( __FILE__ ) . '/inc/faculty-cpt.php';
                $this->create_faculty();
            } elseif (post_type_exists('faculty')) {
                unregister_post_type('faculty');
            }

            if ( empty(get_option('purdue-publication-cpt')) === false ) {
                // require_once dirname( __FILE__ ) . '/inc/faculty-cpt.php';
                $this->create_publication();
            } elseif (post_type_exists('publication')) {
                unregister_post_type('publication');
            }

        }

        private function hooks() {
            add_filter('use_block_editor_for_post_type', array( $this, 'disable_gutenberg'), 10, 2);
        }

        public function disable_gutenberg ($is_enabled, $post_type) {
            if ( in_array($post_type,  $this->_classic) ) {
                return false;
            }

            return $is_enabled;
        }

        private function create_faculty() {
            $names = [
                'name'     => 'faculty',
                'singular' => __('Faculty', 'purdue'),
                'plural'   => __('Faculty', 'purdue'),
                'slug'     => 'faculty',
            ];

            $options = array( 
                'menu_icon' => 'dashicons-groups'
            );

            $labels = array(
                'add_new_item'          => __('Add Faculty Member', 'purdue'),
                'add_new'               => __('Add New', 'purdue'),
                'new_item'              => __('New Faculty Member', 'purdue'),
                'edit_item'             => __('Edit Faculty Member', 'purdue'),
                'update_item'           => __('Update Faculty Member', 'purdue'),
                'not_found'             => __('Not found', 'purdue'),
                'not_found_in_trash'    => __('Not found in Trash', 'purdue'),
            );

            $faculty = new PurduePostType($names, $options, $labels);
            $this->add_unit_tax($faculty);
            $this->add_expertise_tax($faculty);

            $this->_classic[] = 'faculty';
        }

        private function create_publication() {
            $labels = array(
                'archives'              => __('Publication Archives', 'purdue'),
                'attributes'            => __('Post Attributes', 'purdue'),
                'parent_item_colon'     => __('Parent Publication:', 'purdue'),
                'all_items'             => __('All Publications', 'purdue'),
                'add_new_item'          => __('Add New Publication', 'purdue'),
                'new_item'              => __('New Publication', 'purdue'),
                'edit_item'             => __('Edit Publication', 'purdue'),
                'update_item'           => __('Update Publication', 'purdue'),
                'view_item'             => __('View Publication', 'purdue'),
                'view_items'            => __('View Publications', 'purdue'),
                'search_items'          => __('Search Publications', 'purdue'),
              );
              
              $args = array(
                'label'                 => __('publication-post', 'purdue'),
                'description'           => __('Publication post type', 'purdue'),
                'labels'                => $labels,
                'supports'              => array('title', 'editor', 'thumbnail', 'comments', 'trackbacks', 'revisions', 'custom-fields', 'page-attributes', 'post-formats'),
                'taxonomies'            => array('dept_tax', 'pub_tax', 'category', 'post_tag'),
                'hierarchical'          => false,
                'public'                => true,
                'show_ui'               => true,
                'show_in_menu'          => true,
                'menu_position'         => 5,
                'show_in_admin_bar'     => true,
                'show_in_nav_menus'     => true,
                'can_export'            => true,
                'has_archive'           => true,
                'exclude_from_search'   => false,
                'publicly_queryable'    => true,
                'capability_type'       => 'page',
                'show_in_rest'      => true,
                'rewrite'           => ['slug' => 'publication', 'with_front' => false],
              );

            $names = [
                'name'     => 'pub_post',
                'singular' => __('Publication', 'purdue'),
                'plural'   => __('Publications', 'purdue'),
                'slug'     => 'publication',
            ];

            $options = array( 
                'menu_icon' => 'dashicons-book'
            );
            
            $labels = array(
                'add_new_item'          => __('Add Faculty Member', 'purdue'),
                'add_new'               => __('Add New', 'purdue'),
                'new_item'              => __('New Faculty Member', 'purdue'),
                'edit_item'             => __('Edit Faculty Member', 'purdue'),
                'update_item'           => __('Update Faculty Member', 'purdue'),
                'not_found'             => __('Not found', 'purdue'),
                'not_found_in_trash'    => __('Not found in Trash', 'purdue'),
            );

            $pub = new PurduePostType($names, $options, $labels);
            $this->add_unit_tax($pub);
        }

        private function add_unit_tax($cpt) {
            $names = [
                'name' => 'academic-unit',
                'singular' => 'Academic Unit',
                'plural' => 'Academic Units',
                'slug' => 'academic-unit'
            ];

            $terms = array (
                array( 'term' => 'College of Agriculture', 'slug' => 'agriculture'),
                array( 'term' => 'College of Education', 'slug' => 'education'),
                array( 'term' => 'College of Engineering', 'slug' => 'engineering'),
                array( 'term' => 'Exploratory Studies', 'slug' => 'exploratory-studies'),
                array( 'term' => 'College of Health and Human Sciences', 'slug' => 'hhs'),
                array( 'term' => 'College of Liberal Arts', 'slug' => 'liberal-arts'),
                array( 'term' => 'Krannert School of Management', 'slug' => 'management'),
                array( 'term' => 'College of Pharmacy', 'slug' => 'pharmacy'),
                array( 'term' => 'Purdue Polytechnic Institute', 'slug' => 'polytechnic'),
                array( 'term' => 'College of Science', 'slug' => 'science'),
                array( 'term' => 'College of Veterinary Medicine', 'slug' => 'vet'),
                array( 'term' => 'The Honors College', 'slug' => 'honors'),
                array( 'term' => 'The Graduate School', 'slug' => 'graduate'),
            );

            $cpt->add_taxonomy($names, array(), $terms);
        }

        private function add_expertise_tax($cpt) {
            $names = [
                'name' => 'expertise',
                'singular' => 'Expertise',
                'plural' => 'Expertise',
                'slug' => 'expertise'
            ];

            $cpt->add_taxonomy($names, array(), $terms);
        }

        
    }

    $PurdueCPT = new PurduePostTypes();
endif;
