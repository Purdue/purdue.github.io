# Purdue Custom Post Types

Custom post types supported by the Purdue Branded WP theme.

## Descripton

Plugin to easiy add custom post type for WordPress sites.  Includes an admin screen to enable/disable available post types without needing to understand PHP coding.

## Change Log
#### [1.0.2] - 2020-12-10
- FIX: Gutenberg Editor on Content Package CPT

#### [1.0.1] - 2020-12-10
- UPDATE: Content Package label to Content Pkg
- UPDATE: Category taxonomy removed from Content Package CPT

#### [1.0.0] - 2020-12-09
- Refactored code support modular expansion
- ADD: Case Study CPT
- ADD: Content Package CPT

#### [0.6.0] - 2020-11-11
- ADD: Template CPT

