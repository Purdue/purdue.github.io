<?php

if ( ! class_exists( 'PurduePostType' ) ) :
    require_once dirname( __FILE__ ) . '/base-cpt.php';
endif;

if ( ! class_exists( 'PurdueFacultyCPT' ) ) :
	class PurdueFacultyCPT extends PurduePostType {
        protected $slug = 'faculty';
        protected $singular = 'Faculty';
        protected $plural = 'Faculty';
        protected $classicEditor = true;

        function __construct() {
            
            $names = array(
                'name'     => $this->slug,
                'singular' => __($this->singular, 'purdue'),
                'plural'   => __($this->plural, 'purdue'), 
                'slug'     => $this->slug,
            );
    
            $labels = array(
                'add_new_item'          => __('Add Faculty Member', 'purdue'),
                'add_new'               => __('Add New', 'purdue'),
                'new_item'              => __('New Faculty Member', 'purdue'),
                'edit_item'             => __('Edit Faculty Member', 'purdue'),
                'update_item'           => __('Update Faculty Member', 'purdue'),
                'not_found'             => __('Not found', 'purdue'),
                'not_found_in_trash'    => __('Not found in Trash', 'purdue'), 
            );
    
            $options = array('menu_icon' => 'dashicons-groups');

            parent::__construct($names, $options, $labels);
            $this->add_unit_tax();
            $this->add_expertise_tax();
        }

        private function add_unit_tax() {
            $names = [
                'name' => 'academic-unit',
                'singular' => 'Academic Unit',
                'plural' => 'Academic Units',
                'slug' => 'academic-unit'
            ];

            $terms = array (
                array( 'term' => 'College of Agriculture', 'slug' => 'agriculture'),
                array( 'term' => 'College of Education', 'slug' => 'education'),
                array( 'term' => 'College of Engineering', 'slug' => 'engineering'),
                array( 'term' => 'Exploratory Studies', 'slug' => 'exploratory-studies'),
                array( 'term' => 'College of Health and Human Sciences', 'slug' => 'hhs'),
                array( 'term' => 'College of Liberal Arts', 'slug' => 'liberal-arts'),
                array( 'term' => 'Krannert School of Management', 'slug' => 'management'),
                array( 'term' => 'College of Pharmacy', 'slug' => 'pharmacy'),
                array( 'term' => 'Purdue Polytechnic Institute', 'slug' => 'polytechnic'),
                array( 'term' => 'College of Science', 'slug' => 'science'),
                array( 'term' => 'College of Veterinary Medicine', 'slug' => 'vet'),
                array( 'term' => 'The Honors College', 'slug' => 'honors'),
                array( 'term' => 'The Graduate School', 'slug' => 'graduate'),
            );

            $this->add_taxonomy($names, array(), $terms);
        }

        private function add_expertise_tax() {
            $names = [
                'name' => 'expertise',
                'singular' => 'Expertise',
                'plural' => 'Expertise',
                'slug' => 'expertise'
            ];
            $terms = array();

            $this->add_taxonomy($names, array(), $terms);
        }

        public function acf_fields() { 
            if( function_exists('acf_add_local_field_group') ) {
    
                acf_add_local_field_group(array(
                    'key' => 'group_5ec29fade5103',
                    'title' => 'Faculty Info',
                    'fields' => array(
                        array(
                            'key' => 'field_5ec29fb6e812f',
                            'label' => 'Title',
                            'name' => 'title',
                            'type' => 'text',
                            'instructions' => '',
                            'required' => 1,
                            'conditional_logic' => 0,
                            'wrapper' => array(
                                'width' => '',
                                'class' => '',
                                'id' => '',
                            ),
                            'default_value' => '',
                            'placeholder' => '',
                            'prepend' => '',
                            'append' => '',
                            'maxlength' => '',
                        ),
                        array(
                            'key' => 'field_5ec29fc1e8130',
                            'label' => 'College / Department',
                            'name' => 'unit',
                            'type' => 'taxonomy',
                            'instructions' => '',
                            'required' => 0,
                            'conditional_logic' => 0,
                            'wrapper' => array(
                                'width' => '',
                                'class' => '',
                                'id' => '',
                            ),
                            'taxonomy' => 'academic-unit',
                            'field_type' => 'select',
                            'allow_null' => 0,
                            'add_term' => 1,
                            'save_terms' => 1,
                            'load_terms' => 1,
                            'return_format' => 'id',
                            'multiple' => 0,
                        ),
                        array(
                            'key' => 'field_5ec29ffce8131',
                            'label' => 'Email',
                            'name' => 'email',
                            'type' => 'email',
                            'instructions' => '',
                            'required' => 0,
                            'conditional_logic' => 0,
                            'wrapper' => array(
                                'width' => '',
                                'class' => '',
                                'id' => '',
                            ),
                            'default_value' => '',
                            'placeholder' => '',
                            'prepend' => '',
                            'append' => '',
                        ),
                        array(
                            'key' => 'field_5ec2a00ae8132',
                            'label' => 'Phone Number',
                            'name' => 'phone_number',
                            'type' => 'text',
                            'instructions' => '',
                            'required' => 0,
                            'conditional_logic' => 0,
                            'wrapper' => array(
                                'width' => '',
                                'class' => '',
                                'id' => '',
                            ),
                            'default_value' => '',
                            'placeholder' => '',
                            'prepend' => '',
                            'append' => '',
                            'maxlength' => '',
                        ),
                        array(
                            'key' => 'field_5ec2a24163645',
                            'label' => 'Profile Page',
                            'name' => 'profile_page',
                            'type' => 'url',
                            'instructions' => 'URL of faculty profile page',
                            'required' => 0,
                            'conditional_logic' => 0,
                            'wrapper' => array(
                                'width' => '',
                                'class' => '',
                                'id' => '',
                            ),
                            'default_value' => '',
                            'placeholder' => '',
                        ),
                        array(
                            'key' => 'field_5ec2a015e8133',
                            'label' => 'Expertise',
                            'name' => 'expertise',
                            'type' => 'taxonomy',
                            'instructions' => '',
                            'required' => 0,
                            'conditional_logic' => 0,
                            'wrapper' => array(
                                'width' => '',
                                'class' => '',
                                'id' => '',
                            ),
                            'taxonomy' => 'expertise',
                            'field_type' => 'checkbox',
                            'add_term' => 1,
                            'save_terms' => 1,
                            'load_terms' => 0,
                            'return_format' => 'id',
                            'multiple' => 0,
                            'allow_null' => 0,
                        ),
                        array(
                            'key' => 'field_5ec2a02de8134',
                            'label' => 'Short Bio',
                            'name' => 'short_bio',
                            'type' => 'wysiwyg',
                            'instructions' => '',
                            'required' => 0,
                            'conditional_logic' => 0,
                            'wrapper' => array(
                                'width' => '',
                                'class' => '',
                                'id' => '',
                            ),
                            'default_value' => '',
                            'tabs' => 'all',
                            'toolbar' => 'basic',
                            'media_upload' => 0,
                            'delay' => 0,
                        ),
                    ),
                    'location' => array(
                        array(
                            array(
                                'param' => 'post_type',
                                'operator' => '==',
                                'value' => 'faculty',
                            ),
                        ),
                    ),
                    'menu_order' => 20,
                    'position' => 'acf_after_title',
                    'style' => 'seamless',
                    'label_placement' => 'top',
                    'instruction_placement' => 'label',
                    'hide_on_screen' => '',
                    'active' => true,
                    'description' => '',
                ));
            }
        }
    
    }

    $PurdueFacultyCPT = new PurdueFacultyCPT();

endif;