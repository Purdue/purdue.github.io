<?php

if ( ! class_exists( 'PurduePostType' ) ) :
    require_once dirname( __FILE__ ) . '/base-cpt.php';
endif;

if ( ! class_exists( 'PurdueNewsListCPT' ) ) :
	class PurdueNewsListCPT extends PurduePostType {
        protected $slug = 'newsList';
        protected $singular = 'News List';
        protected $plural = 'News List';
        protected $classicEditor = true;

        function __construct() {
            
            $names = array(
                'name'     => $this->slug,
                'singular' => __($this->singular, 'purdue'),
                'plural'   => __($this->plural, 'purdue'), 
                'slug'     => $this->slug,
            );

            $options = array( 
                'supports'              => array( 'title', 'thumbnail', 'revisions' ),
                'taxonomies'            => array( 'newspublisher', 'newsyear' ),
                'hierarchical'          => false,
                'public'                => true,
                'show_ui'               => true,
                'show_in_menu'          => true,
                'menu_position'         => 9,
                'menu_icon'             => 'dashicons-layout',
                'show_in_admin_bar'     => true,
                'show_in_nav_menus'     => true,
                'can_export'            => true,
                'has_archive'           => false,
                'exclude_from_search'   => true,
                'publicly_queryable'    => true,
                'rewrite'               => false,
                'capability_type'       => 'post',
                'show_in_rest'          => false,
            );

            $labels = array(
                'add_new_item'          => __('Add News Item', 'purdue'),
                'add_new'               => __('Add New', 'purdue'),
                'new_item'              => __('New News Item', 'purdue'),
                'edit_item'             => __('Edit News Item', 'purdue'),
                'update_item'           => __('Update News Item', 'purdue'),
                'not_found'             => __('Not found', 'purdue'),
                'not_found_in_trash'    => __('Not found in Trash', 'purdue'),
            );

            add_filter( 'post_type_link', array( $this, 'replace_with_download'), 10, 2 );
            parent::__construct($names, $options, $labels);
            $this->add_newspulbisher_tax();
            $this->add_newsyear_tax();
        }

        private function add_newspulbisher_tax() {
            $names = [
                'name' => 'newspublisher',
                'singular' => 'Publisher',
                'plural' => 'Publisher',
                'slug' => 'newspublisher'
            ];      

            $this->add_taxonomy($names, array());
        }

        private function add_newsyear_tax() {
            $names = [
                'name' => 'newsyear',
                'singular' => 'Year',
                'plural' => 'Years',
                'slug' => 'newsyear'
            ];      

            $this->add_taxonomy($names, array());
        }
        public function replace_with_download( $url, $post ) {
            if ( 'newsList' == get_post_type( $post ) ) {
                $value = get_field( "news_link" );

                if( $value ) {
                    $url = $value;
                }
            }
            return $url;
        }
    }

    $PurdueNewsListCPT = new PurdueNewsListCPT();

endif;