<?php

if ( ! class_exists( 'PurduePostType' ) ) :
    require_once dirname( __FILE__ ) . '/base-cpt.php';
endif;

if ( ! class_exists( 'PurdueEventCPT' ) ) :
	class PurdueEventCPT extends PurduePostType {
        protected $slug = 'event';
        protected $singular = 'Event';
        protected $plural = 'Events';
        protected $classicEditor = true;

        function __construct() {
            
            $names = array(
                'name'     => $this->slug,
                'singular' => __($this->singular, 'purdue'),
                'plural'   => __($this->plural, 'purdue'), 
                'slug'     => $this->slug,
            );

            $options = array( 
                'supports'              => array( 'title', 'editor', 'revisions' ),
                'taxonomies'            => array( 'academic-unit', 'campaigns' ),
                'hierarchical'          => false,
                'public'                => true,
                'show_ui'               => true,
                'show_in_menu'          => true,
                'menu_position'         => 9,
                'menu_icon'             => 'dashicons-calendar-alt',
                'show_in_admin_bar'     => true,
                'show_in_nav_menus'     => true,
                'can_export'            => true,
                'has_archive'           => false,
                'exclude_from_search'   => true,
                'publicly_queryable'    => true,
                'rewrite'               => false,
                'capability_type'       => 'post',
                'show_in_rest'          => true,
            );

            $labels = array(
                'add_new_item'          => __('Add Event', 'purdue'),
                'add_new'               => __('Add New', 'purdue'),
                'new_item'              => __('New Event', 'purdue'),
                'edit_item'             => __('Edit Event', 'purdue'),
                'update_item'           => __('Update Event', 'purdue'),
                'not_found'             => __('Not found', 'purdue'),
                'not_found_in_trash'    => __('Not found in Trash', 'purdue'),
            );

            parent::__construct($names, $options, $labels);
            $this->add_unit_tax();
            $this->add_campaign_tax();
        }

        private function add_unit_tax() {
            $names = [
                'name' => 'academic-unit',
                'singular' => 'Academic Unit',
                'plural' => 'Academic Units',
                'slug' => 'academic-unit'
            ];
            
            $this->add_taxonomy($names, array(), array());
        }

        private function add_campaign_tax() {
            $names = [
                'name' => 'campaigns',
                'singular' => 'Campaign',
                'plural' => 'Campaigns',
                'slug' => 'campaigns'
            ];

            $terms = array();

            $this->add_taxonomy($names, array('show_in_rest' => true), array() );
        }

    }

    $PurdueEventCPT = new PurdueEventCPT();

endif;