<?php

if ( ! class_exists( 'PurduePostType' ) ) :
    require_once dirname( __FILE__ ) . '/base-cpt.php';
endif;

if ( ! class_exists( 'PurdueTemplateCPT' ) ) :
	class PurdueTemplateCPT extends PurduePostType {
        protected $slug = 'template';
        protected $singular = 'Template';
        protected $plural = 'Templates';
        protected $classicEditor = true;

        function __construct() {
            
            $names = array(
                'name'     => $this->slug,
                'singular' => __($this->singular, 'purdue'),
                'plural'   => __($this->plural, 'purdue'), 
                'slug'     => $this->slug,
            );

            $options = array( 
                'supports'              => array( 'title', 'thumbnail', 'revisions' ),
                'taxonomies'            => array( 'platform', 'temptype' ),
                'hierarchical'          => false,
                'public'                => true,
                'show_ui'               => true,
                'show_in_menu'          => true,
                'menu_position'         => 9,
                'menu_icon'             => 'dashicons-layout',
                'show_in_admin_bar'     => true,
                'show_in_nav_menus'     => true,
                'can_export'            => true,
                'has_archive'           => false,
                'exclude_from_search'   => true,
                'publicly_queryable'    => true,
                'rewrite'               => false,
                'capability_type'       => 'post',
                'show_in_rest'          => false,
            );

            $labels = array(
                'add_new_item'          => __('Add Template', 'purdue'),
                'add_new'               => __('Add New', 'purdue'),
                'new_item'              => __('New Template', 'purdue'),
                'edit_item'             => __('Edit Template', 'purdue'),
                'update_item'           => __('Update Template', 'purdue'),
                'not_found'             => __('Not found', 'purdue'),
                'not_found_in_trash'    => __('Not found in Trash', 'purdue'),
            );


            add_action( 'template_redirect', array($this, 'template_redirects' ) );
            parent::__construct($names, $options, $labels);
            $this->add_tempmedia_tax();
            // $this->add_tempformat_tax();
            $this->add_temptype_tax();
        }

        private function add_tempmedia_tax() {
            $names = [
                'name' => 'media',
                'singular' => 'Media',
                'plural' => 'Media',
                'slug' => 'media'
            ];

            $terms = array (
                array( 'term' => 'Print', 'slug' => 'print'),
                array( 'term' => 'Digital', 'slug' => 'digital'),
                array( 'term' => 'Social', 'slug' => 'social'),
            );
        

            $this->add_taxonomy($names, array(), $terms);
        }

        private function add_tempformat_tax() {
            $names = [
                'name' => 'tempformat',
                'singular' => 'Format',
                'plural' => 'Formats',
                'slug' => 'tempformat'
            ];

            $terms = array (
                array( 'term' => 'InDesign', 'slug' => 'indesign'),
                array( 'term' => 'Microsoft Office', 'slug' => 'ms-office'),
               
            );
        

            $this->add_taxonomy($names, array(), $terms);
        }

        private function add_temptype_tax() {
            $names = [
                'name' => 'temptype',
                'singular' => 'Format',
                'plural' => 'Format',
                'slug' => 'temptype'
            ];

            
            $terms = array (
                array( 'term' => 'Brochure', 'slug' => 'indesign'),
                array( 'term' => 'Flyer', 'slug' => 'ms-office'),
                array( 'term' => 'Postcard', 'slug' => 'social-media'),
                array( 'term' => 'Poster', 'slug' => 'poster'),
                array( 'term' => 'Calendar', 'slug' => 'calendar'),
                array( 'term' => 'Schedule/Agenda', 'slug' => 'schedule'),
                array( 'term' => 'Rack Card', 'slug' => 'rackcard'),
                array( 'term' => 'Certificate/Award', 'slug' => 'certificate'),
                array( 'term' => 'Newsletter', 'slug' => 'newsletter'),
                array( 'term' => 'Note Card', 'slug' => 'note-card'),
                array( 'term' => 'Half Sheet', 'slug' => 'half-sheet'),
                array( 'term' => 'Presentation', 'slug' => 'presentation'),
                array( 'term' => 'PowerPoint', 'slug' => 'powerpoint'),
                array( 'term' => 'Word', 'slug' => 'word'),
                array( 'term' => 'Facebook', 'slug' => 'facebook'),
                array( 'term' => 'Instagram', 'slug' => 'instagram'),
                array( 'term' => 'Twitter', 'slug' => 'twitter'),
                array( 'term' => 'LinkedIn', 'slug' => 'linkedin'),
                array( 'term' => 'Profile', 'slug' => 'profile'),
                array( 'term' => 'Animation', 'slug' => 'animation'),
                array( 'term' => 'Lower Third', 'slug' => 'lower-third'),
                array( 'term' => 'Social Media', 'slug' => 'social-media'),
                array( 'term' => 'Videos', 'slug' => 'video'),
                array( 'term' => 'Zoom/Teams', 'slug' => 'conference'),
                array( 'term' => 'Digital Signs', 'slug' => 'digital-signs'),
            );

            $this->add_taxonomy($names, array(), $terms);
        }
    
        public function template_redirects() {

            if ( get_post_type() === 'template' ) {
                $value = get_field( "asset_file" );

                if( $value ) {
                    wp_redirect(  $value  );
                    die;
                }
                
            }
         
        }
    }

    $PurdueTemplateCPT = new PurdueTemplateCPT();

endif;