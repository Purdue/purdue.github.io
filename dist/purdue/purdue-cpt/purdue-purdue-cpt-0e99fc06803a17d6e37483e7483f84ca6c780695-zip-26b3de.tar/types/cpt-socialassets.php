<?php

if ( ! class_exists( 'PurduePostType' ) ) :
    require_once dirname( __FILE__ ) . '/base-cpt.php';
endif;

if ( ! class_exists( 'PurdueSocialCPT' ) ) :
	class PurdueSocialCPT extends PurduePostType {
        protected $slug = 'socialasset';
        protected $singular = 'Social Asset';
        protected $plural = 'Social Assets';
        protected $classicEditor = true;

        function __construct() {
            
            $names = array(
                'name'     => $this->slug,
                'singular' => __($this->singular, 'purdue'),
                'plural'   => __($this->plural, 'purdue'), 
                'slug'     => $this->slug,
            );

            $options = array( 
                'supports'              => array( 'title', 'thumbnail', 'revisions' ),
                'taxonomies'            => array(  'campaigns', 'assettype', 'assetmsg' ),
                'hierarchical'          => false,
                'public'                => true,
                'show_ui'               => true,
                'show_in_menu'          => true,
                'menu_position'         => 8,
                'menu_icon'             => 'data:image/svg+xml;base64,' . base64_encode('<svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"	 viewBox="0 0 55 55" style="enable-background:new 0 0 55 55;" xml:space="preserve"><path d="M49,0c-3.309,0-6,2.691-6,6c0,1.035,0.263,2.009,0.726,2.86l-9.829,9.829C32.542,17.634,30.846,17,29,17	s-3.542,0.634-4.898,1.688l-7.669-7.669C16.785,10.424,17,9.74,17,9c0-2.206-1.794-4-4-4S9,6.794,9,9s1.794,4,4,4	c0.74,0,1.424-0.215,2.019-0.567l7.669,7.669C21.634,21.458,21,23.154,21,25s0.634,3.542,1.688,4.897L10.024,42.562	C8.958,41.595,7.549,41,6,41c-3.309,0-6,2.691-6,6s2.691,6,6,6s6-2.691,6-6c0-1.035-0.263-2.009-0.726-2.86l12.829-12.829	c1.106,0.86,2.44,1.436,3.898,1.619v10.16c-2.833,0.478-5,2.942-5,5.91c0,3.309,2.691,6,6,6s6-2.691,6-6c0-2.967-2.167-5.431-5-5.91	v-10.16c1.458-0.183,2.792-0.759,3.898-1.619l7.669,7.669C41.215,39.576,41,40.26,41,41c0,2.206,1.794,4,4,4s4-1.794,4-4	s-1.794-4-4-4c-0.74,0-1.424,0.215-2.019,0.567l-7.669-7.669C36.366,28.542,37,26.846,37,25s-0.634-3.542-1.688-4.897l9.665-9.665	C46.042,11.405,47.451,12,49,12c3.309,0,6-2.691,6-6S52.309,0,49,0z M11,9c0-1.103,0.897-2,2-2s2,0.897,2,2s-0.897,2-2,2	S11,10.103,11,9z M6,51c-2.206,0-4-1.794-4-4s1.794-4,4-4s4,1.794,4,4S8.206,51,6,51z M33,49c0,2.206-1.794,4-4,4s-4-1.794-4-4	s1.794-4,4-4S33,46.794,33,49z M29,31c-3.309,0-6-2.691-6-6s2.691-6,6-6s6,2.691,6,6S32.309,31,29,31z M47,41c0,1.103-0.897,2-2,2	s-2-0.897-2-2s0.897-2,2-2S47,39.897,47,41z M49,10c-2.206,0-4-1.794-4-4s1.794-4,4-4s4,1.794,4,4S51.206,10,49,10z"/><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g></svg>'),
                'show_in_admin_bar'     => true,
                'show_in_nav_menus'     => true,
                'can_export'            => true,
                'has_archive'           => false,
                'exclude_from_search'   => true,
                'publicly_queryable'    => true,
                'rewrite'               => false,
                'capability_type'       => 'post',
                'show_in_rest'          => false,
            );

            $labels = array(
                'add_new_item'          => __('Add Social Assset', 'purdue'),
                'add_new'               => __('Add New', 'purdue'),
                'new_item'              => __('New Assset', 'purdue'),
                'edit_item'             => __('Edit Assset', 'purdue'),
                'update_item'           => __('Update Assset', 'purdue'),
                'not_found'             => __('Not found', 'purdue'),
                'not_found_in_trash'    => __('Not found in Trash', 'purdue'),
            );


            add_action( 'template_redirect', array($this, 'social_rdirects' ) );
            add_filter( 'post_type_link', array( $this, 'replace_with_download'), 10, 2 );
            parent::__construct($names, $options, $labels);
            $this->add_assettype_tax();
            $this->add_assetmsg_tax();
        }

        private function add_assettype_tax() {
            $names = [
                'name' => 'assettype',
                'singular' => 'Asset Type',
                'plural' => 'Asset Types',
                'slug' => 'assettype'
            ];

            $terms = array (
                array( 'term' => 'Digital Sign', 'slug' => 'digital-signs'),
                array( 'term' => 'Operational Sign', 'slug' => 'operational-signs'),
                array( 'term' => 'Posters', 'slug' => 'posters'),
                array( 'term' => 'Social Graphics', 'slug' => 'social-graphics'),
                array( 'term' => 'Yard Signs', 'slug' => 'yard-signs'),
            );
        

            $this->add_taxonomy($names, array(), $terms);
        }

        private function add_assetmsg_tax() {
            $names = [
                'name' => 'assetmsg',
                'singular' => 'Message',
                'plural' => 'Message',
                'slug' => 'assetmsg'
            ];


            $this->add_taxonomy($names, array());
        }

        public function social_rdirects() {

            if ( get_post_type() === 'socialasset' ) {
                $value = get_field( "asset_file" );

                if( $value ) {
                    wp_redirect(  $value  );
                    die;
                }
                
            }
         
        }
        
        public function replace_with_download( $url, $post ) {
            if ( 'socialasset' == get_post_type( $post ) ) {
                $value = get_field( "asset_file" );

                if( $value ) {
                    $url = $value;
                }
            }
            return $url;
        }
        
    
    }

    $PurdueSocialCPT = new PurdueSocialCPT();

endif;