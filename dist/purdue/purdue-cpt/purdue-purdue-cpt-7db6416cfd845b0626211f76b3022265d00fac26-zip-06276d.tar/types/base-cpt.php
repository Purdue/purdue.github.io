<?php

if ( !defined('ABSPATH') ) {
	header( 'HTTP/1.0 403 Forbidden' );
	die;
}

use PostTypes\PostType;
use PostTypes\Taxonomy;

if ( ! class_exists( 'PurduePostType' ) ) :
	abstract class PurduePostType {
        protected $slug = null;
        protected $singular = null;
        protected $plural = null;
        protected $classicEditor = false;

        private $_names = null;
        private $_labels = null;
        private $_options = array(
            'supports'              => array('title', 'thumbnail', 'editor', 'revisions'),
            'taxonomies'            => array( ),
            'public'                => true,
            'menu_position'         => 5,
            'show_in_admin_bar'     => true,
            'show_in_nav_menus'     => false,
            'can_export'            => true,
            'has_archive'           => true,
            'capability_type'       => 'page',
            'show_in_rest'      => true,
            'rewrite'           => ['with_front' => false, 'feeds' => false],
        );
        private $_taxes = array();

        private $_tax_options = [
            'hierarchical'      => true, // make it hierarchical (like categories)
            'public'            => true,
            'show_in_nav_menus' => false,
            'show_admin_column' => true,
            'show_in_rest'      => false,
            'show_tagcloud'     => false,
            'rewrite'           => false,
        ];

        private $cpt = null;

        // was __construct
		function __construct(array $names = null, $options = array(), $labels = null ) {
            $this->_names = $names;
            $this->_options = array_merge($this->_options, $options);
            $this->_labels = $labels;
            
            write_log("Construct: " . 'purdue-' . $this->_names['slug'] . '-cpt');
            if ( empty(get_option('purdue-' . $this->_names['slug'] . '-cpt')) === false ) {
                write_log('ADDED' . $this->getClassName() );
                $this->add();
            } else {
                write_log('REMOVED' . $this->getClassName() );
                $this->remove();
            }
        }
        
        private function add() {
            add_action( 'init', array( $this, 'create_post_type') , 0 );
            add_action( 'init', array( $this, 'create_custom_taxonomies') , 0);
            add_action( 'init', array( $this, 'insert_taxonomy_terms') , 10);
			add_action( 'init', array( $this, 'acf_fields'));
        }

        private function remove() {
            if (isset($this->slug)) {
                if (post_type_exists($this->slug)) {
                    unregister_post_type($this->slug);
                }
            }
        }

        public function getClassName() {
            // return $this->className;
            return get_called_class();
        }

        public function getName() {
            return $this->singular;
        }

        public function getPath() {
            return $this->slug;
        }

        public function isClassic() {
            return $this->classicEditor;
        }

        public function create_post_type() {
            
            $this->cpt = new PostType( $this->_names, $this->_options );
        
            if ( is_array($this->_labels) ) {
                $this->cpt->labels( $this->_labels );
            }

            // Register the post type to WordPress.
            $this->cpt->register();
        }


        protected function add_taxonomy(array $name, $options = array(), $terms = array(), bool $filter = true) {
            if (array_key_exists('name', $name)) {
                $newtax = array($name['name'] => array('names' => $name, 'options' => $options, 'terms' => $terms, 'filter' => $filter));
                $this->_taxes = array_merge($this->_taxes, $newtax);
            }
            
        }

        public function create_custom_taxonomies() { 
            if ( !empty($this->_taxes) ) {
                $filters = array();

                foreach($this->_taxes as $tax) {
                    // error_log(print_r($tax, true));

                    $names = $tax['names'];
                    $options = (array_key_exists('options', $tax)) ? array_merge($this->_tax_options,$tax['options']) : $this->_tax_options;

                    $thetax = new Taxonomy( $names, $options );
                    // $thetax->posttype( $this->_names['name'] );
        
                    // Register the taxonomy to WordPress
                    $thetax->register();

                    $thetax->posttype( $this->_names['name'] );
                    // Register the taxonomy to WordPress
                    $thetax->register();

                    if ($tax['filter'] === true) $filters[] = $names['name'];
                }

                // Set Admin Filter
                if (!empty($filters)) $this->cpt->filters( $filters );
            }
        }

        public function insert_taxonomy_terms() { 
            if ( !empty($this->_taxes) ) {
                $filters = array();

                foreach($this->_taxes as $tax) {
                    // error_log(print_r($tax, true));

                    $names = $tax['names'];
                    
                    $hasTerms = get_terms( array(
                        'taxonomy' => $names,
                        'parent' => 0
                    ));

                    // Load Default Terms (if any) but only if no terms currently exist
                    if ( (!empty($tax['terms'])) && (empty($hasTerms)) ) {
                        foreach($tax['terms'] as $term) {
                            error_log ("Insert Term: " . $names['name'] . " " . print_r($term, true) );

                            if ( (!empty($term['term'])) && (!empty($term['slug'])) )  {
                                $termChk = term_exists( $term['term'], $names['name'] );
                                if ($termChk === null) {
                                    $insterm = wp_insert_term(
                                        $term['term'],   // the term 
                                        $names['name'], // the taxonomy
                                        array(
                                            'slug'        => $term['slug'],
                                        )
                                    ); 

                                    error_log ("Insert Term: " . print_r($insterm, true) );
                                }
                                
                            }
                        }
                    }

                    if ($tax['filter'] === true) $filters[] = $names['name'];
                }

                // Set Admin Filter
                if (!empty($filters)) $this->cpt->filters( $filters );
            }
        }

        public function acf_fields() { 
            $filename = dirname( __FILE__ ) . '/fields-' . $this->_names['name'] . '.php';

            if (file_exists($filename)) {
                require_once $filename;
            }
        }

    }

endif;
/*
$names = [
                'name'     => 'faculty',
                'singular' => __('Faculty', 'purdue'),
                'plural'   => __('Faculty', 'purdue'),
                'slug'     => 'faculty',
            ];

private static function on_activation() {
    self::faculty_cpt(); 
    self::create_unit_tax();
    $this->load_units();
    
    // Clear the permalinks after the post type has been registered.
    flush_rewrite_rules(); 
}

private static function on_deactivation() {
    unregister_post_type( 'faculty' ); 
    // Clear the permalinks after the post type has been registered.
    flush_rewrite_rules(); 
}

*/