<?php

if ( ! class_exists( 'PurduePostType' ) ) :
    require_once dirname( __FILE__ ) . '/base-cpt.php';
endif;

if ( ! class_exists( 'PurduePublicationCPT' ) ) :
	class PurduePublicationCPT extends PurduePostType {
        protected $slug = 'publication';
        protected $singular = 'Publication';
        protected $plural = 'Publications';
        
        function __construct() {
            
            $names = array(
                'name'     => 'pub_post',
                'singular' => __($this->singular, 'purdue'),
                'plural'   => __($this->plural, 'purdue'), 
                'slug'     => $this->slug,
            );
    
            $labels = array(
                'archives'              => __('Publication Archives', 'purdue'),
                'attributes'            => __('Post Attributes', 'purdue'),
                'parent_item_colon'     => __('Parent Publication:', 'purdue'),
                'all_items'             => __('All Publications', 'purdue'),
                'add_new_item'          => __('Add New Publication', 'purdue'),
                'new_item'              => __('New Publication', 'purdue'),
                'edit_item'             => __('Edit Publication', 'purdue'),
                'update_item'           => __('Update Publication', 'purdue'),
                'view_item'             => __('View Publication', 'purdue'),
                'view_items'            => __('View Publications', 'purdue'),
                'search_items'          => __('Search Publications', 'purdue'),
              );
    
            $options = array(
                'label'                 => __('publication-post', 'purdue'),
                'description'           => __('Publication post type', 'purdue'),
                'labels'                => $labels,
                'supports'              => array('title', 'editor', 'thumbnail', 'comments', 'trackbacks', 'revisions', 'custom-fields', 'page-attributes', 'post-formats'),
                'taxonomies'            => array('dept_tax', 'pub_tax', 'category', 'post_tag'),
                'hierarchical'          => false,
                'public'                => true,
                'show_ui'               => true,
                'show_in_menu'          => true,
                'menu_position'         => 5,
                'menu_icon'             => 'dashicons-book',
                'show_in_admin_bar'     => true,
                'show_in_nav_menus'     => true,
                'can_export'            => true,
                'has_archive'           => true,
                'exclude_from_search'   => false,
                'publicly_queryable'    => true,
                'capability_type'       => 'page',
                'show_in_rest'      => true,
                'rewrite'           => ['slug' => 'publication', 'with_front' => false],
              );

            parent::__construct($names, $options, $labels);
            $this->add_unit_tax();
        }

        private function add_unit_tax() {
            $names = [
                'name' => 'academic-unit',
                'singular' => 'Academic Unit',
                'plural' => 'Academic Units',
                'slug' => 'academic-unit'
            ];

            $terms = array (
                array( 'term' => 'College of Agriculture', 'slug' => 'agriculture'),
                array( 'term' => 'College of Education', 'slug' => 'education'),
                array( 'term' => 'College of Engineering', 'slug' => 'engineering'),
                array( 'term' => 'Exploratory Studies', 'slug' => 'exploratory-studies'),
                array( 'term' => 'College of Health and Human Sciences', 'slug' => 'hhs'),
                array( 'term' => 'College of Liberal Arts', 'slug' => 'liberal-arts'),
                array( 'term' => 'Krannert School of Management', 'slug' => 'management'),
                array( 'term' => 'College of Pharmacy', 'slug' => 'pharmacy'),
                array( 'term' => 'Purdue Polytechnic Institute', 'slug' => 'polytechnic'),
                array( 'term' => 'College of Science', 'slug' => 'science'),
                array( 'term' => 'College of Veterinary Medicine', 'slug' => 'vet'),
                array( 'term' => 'The Honors College', 'slug' => 'honors'),
                array( 'term' => 'The Graduate School', 'slug' => 'graduate'),
            );

            $this->add_taxonomy($names, array(), $terms);
        }
    
    }

    $PurduePublicationCPT = new PurduePublicationCPT();

endif;