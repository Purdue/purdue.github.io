<?php

/*
Plugin Name: Purdue Post Types
Description: Create custom post types used by Purdue University WordPress websites
Author: Purdue MarCom Digital Solutions Team
Author URI: https://marcom.purdue.edu/what-we-do/#digital-solutions
Version: 0.6.0
 
License:     GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

------------------------------------------------------------------------

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/

if ( !defined('ABSPATH') ) {
	header( 'HTTP/1.0 403 Forbidden' );
	die;
}

require __DIR__ . '/vendor/autoload.php';

if ( ! class_exists( 'PurduePostTypes' ) ) :

    class PurduePostTypes {
        private $_settings = array();
        private $_classic = array();

        public function __construct() {
            $this->includes();
            $this->hooks();
        }

        private function includes() {
            require_once dirname( __FILE__ ) . '/admin/posttype-config-options.php';
            require_once dirname( __FILE__ ) . '/inc/class-purdue-posttype.php';

            // unregister_taxonomy('academic-unit');
            // unregister_post_type('faculty');
            // $addFaculty = (empty(checked(1, get_option('purdue-faculty-cpt'), false)));
           
            if ( empty(get_option('purdue-faculty-cpt')) === false ) {
                // require_once dirname( __FILE__ ) . '/inc/faculty-cpt.php';
                $this->create_faculty();
            } elseif (post_type_exists('faculty')) {
                unregister_post_type('faculty');
            }

            if ( empty(get_option('purdue-publication-cpt')) === false ) {
                // require_once dirname( __FILE__ ) . '/inc/faculty-cpt.php';
                $this->create_publication();
            } elseif (post_type_exists('publication')) {
                unregister_post_type('publication');
            }

            /*
            if ( empty(get_option('purdue-casestudies-cpt')) === false ) {
                // require_once dirname( __FILE__ ) . '/inc/faculty-cpt.php';
                $this->create_casestudies();
            } elseif (post_type_exists('purdue-casestudies')) {
                unregister_post_type('purdue-casestudies');
            }

            if ( empty(get_option('purdue-contentpkg-cpt')) === false ) {
                // require_once dirname( __FILE__ ) . '/inc/faculty-cpt.php';
                $this->create_contentpkg();
            } elseif (post_type_exists('purdue-contentpkg')) {
                unregister_post_type('purdue-contentpkg');
            }
            */

            if ( empty(get_option('purdue-templates-cpt')) === false ) {
                // require_once dirname( __FILE__ ) . '/inc/faculty-cpt.php';
                $this->create_templates();
            } elseif (post_type_exists('purdue-templates')) {
                unregister_post_type('purdue-templates');
            }

        }

        private function hooks() {
            add_filter('use_block_editor_for_post_type', array( $this, 'disable_gutenberg'), 10, 2);
        }

        public function disable_gutenberg ($is_enabled, $post_type) {
            if ( in_array($post_type,  $this->_classic) ) {
                return false;
            }

            return $is_enabled;
        }

        private function create_faculty() {
            $names = [
                'name'     => 'faculty',
                'singular' => __('Faculty', 'purdue'),
                'plural'   => __('Faculty', 'purdue'),
                'slug'     => 'faculty',
            ];

            $options = array( 
                'menu_icon' => 'dashicons-groups'
            );

            $labels = array(
                'add_new_item'          => __('Add Faculty Member', 'purdue'),
                'add_new'               => __('Add New', 'purdue'),
                'new_item'              => __('New Faculty Member', 'purdue'),
                'edit_item'             => __('Edit Faculty Member', 'purdue'),
                'update_item'           => __('Update Faculty Member', 'purdue'),
                'not_found'             => __('Not found', 'purdue'),
                'not_found_in_trash'    => __('Not found in Trash', 'purdue'),
            );

            $faculty = new PurduePostType($names, $options, $labels);
            $this->add_unit_tax($faculty);
            $this->add_expertise_tax($faculty);

            $this->_classic[] = 'faculty';
        }

        private function create_casestudies() {
            $labels = array(
                'archives'              => __('Case Study Archives', 'purdue'),
                'attributes'            => __('Post Attributes', 'purdue'),
                'parent_item_colon'     => __('Parent Case Study:', 'purdue'),
                'all_items'             => __('All Case Studies', 'purdue'),
                'add_new_item'          => __('Add New Case Study', 'purdue'),
                'new_item'              => __('New Case Study', 'purdue'),
                'edit_item'             => __('Edit Case Study', 'purdue'),
                'update_item'           => __('Update Case Study', 'purdue'),
                'view_item'             => __('View Case Study', 'purdue'),
                'view_items'            => __('View Case Studies', 'purdue'),
                'search_items'          => __('Search Case Studies', 'purdue'),
              );
              
              $args = array(
                'label'                 => __('casestudy-post', 'purdue'),
                'description'           => __('Case Study post type', 'purdue'),
                'labels'                => $labels,
                'supports'              => array('title', 'editor', 'thumbnail', 'revisions', 'custom-fields', 'page-attributes', 'post-formats'),
                'taxonomies'            => array('dept_tax', 'category', 'post_tag'),
                'hierarchical'          => false,
                'public'                => true,
                'show_ui'               => true,
                'show_in_menu'          => true,
                'menu_position'         => 5,
                'show_in_admin_bar'     => true,
                'show_in_nav_menus'     => true,
                'can_export'            => true,
                'has_archive'           => true,
                'exclude_from_search'   => false,
                'publicly_queryable'    => true,
                'capability_type'       => 'page',
                'show_in_rest'      => true,
                'rewrite'           => ['slug' => 'casestudy', 'with_front' => false],
              );

            $names = [
                'name'     => 'casestudy_post',
                'singular' => __('Case Study', 'purdue'),
                'plural'   => __('Case Studies', 'purdue'),
                'slug'     => 'casestudy',
            ];

            $options = array( 
                'menu_icon' => 'data:image/svg+xml;base64,' . base64_encode('<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 1000 1000" enable-background="new 0 0 1000 1000" xml:space="preserve"><g><g transform="translate(0.000000,512.000000) scale(0.100000,-0.100000)"><path d="M414,5007.7c-101.5-24.9-197.2-95.7-252.8-189.6l-51.7-90l-5.7-3724.4L100-2720.7l1026.4-1030.2l1026.4-1028.3l2502.7,3.8c2286.4,5.7,2506.6,7.6,2558.3,38.3c120.6,65.1,203,174.3,225.9,298.7l13.4,61.3h-2451H2553l-5.8,875.1l-5.7,877l-53.6,90c-34.5,59.4-84.3,109.1-143.6,143.6l-90,53.6l-875.1,5.7l-877,5.8v3473.6v3475.5h3274.4H7051V2583.5V544.1h201.1h201.1l-3.8,2093l-5.7,2091l-53.6,90c-34.5,59.4-84.3,109.1-143.6,143.6l-90,53.6l-3341.5,3.8C1976.6,5019.2,446.6,5015.4,414,5007.7z"/><path d="M6227.6,2573.9V1348.4h201.1h201.1v1225.5v1225.5h-201.1h-201.1V2573.9z"/><path d="M1813.8,3743.9c-386.8-111.1-704.7-417.4-823.4-790.8c-26.8-84.2-47.9-155.1-47.9-160.8c0-3.8,224-7.7,497.9-7.7h497.9v497.9c0,273.8-1.9,497.9-3.8,495.9C1930.6,3778.4,1877,3763.1,1813.8,3743.9z"/><path d="M2359.6,3209.7v-549.6l390.6-390.6l390.6-390.6l57.4,88.1c105.3,168.5,147.5,338.9,147.5,607c0,289.1-44,446.2-181.9,658.7c-149.4,227.9-344.7,384.9-603.2,480.6C2340.4,3797.5,2359.6,3843.5,2359.6,3209.7z"/><path d="M5423.4,2363.3V1348.4h191.5h191.5v1014.9v1014.9h-191.5h-191.5V2363.3z"/><path d="M4600,1961.2v-612.8H4801h201.1v612.8v612.8H4801H4600V1961.2z"/><path d="M942.5,2355.6c0-5.8,21.1-78.5,47.9-162.8c116.8-365.7,400.2-649.1,777.4-777.4c212.6-70.9,509.4-74.7,716.2-9.6c109.2,34.5,314,130.2,354.3,166.6c3.8,3.8-168.5,183.8-383,398.3l-392.5,392.5h-559.1C1195.3,2363.3,942.5,2359.4,942.5,2355.6z"/><path d="M3776.6,1750.5v-402.1h201.1h201.1v402.1v402.1h-201.1h-201.1V1750.5z"/><path d="M1325.5-78.2v-201.1h1426.6h1426.6v201.1v201.1H2752.1H1325.5V-78.2z"/><path d="M6723.6,103.7c-281.5-34.5-612.8-158.9-861.7-325.5c-157-107.2-407.9-358.1-515.1-515.1c-478.7-712.4-442.3-1654.5,90-2318.9c383-474.9,913.4-729.6,1528.1-729.6c337,0,639.6,74.7,928.7,231.7l67,36.4l603.2-601.3c587.9-586,605.1-601.3,716.2-631.9c273.8-78.5,549.6,90,608.9,373.4c17.2,88.1,15.3,124.5-11.5,220.2c-32.5,113-44,126.4-633.8,718.1l-601.3,603.2l36.4,67c266.2,492.1,306.4,1080,113,1618.1C8491-319.5,7619.7,207.1,6723.6,103.7z M7303.8-403.7c503.6-130.2,896.2-492.1,1060.8-976.6c42.1-126.4,53.6-197.2,61.3-396.4c11.5-310.2-23-465.3-155.1-729.6c-82.3-166.6-122.6-222.1-270-369.6c-147.4-147.4-203-187.7-369.6-270c-264.3-132.1-419.4-166.6-729.6-155.1c-281.5,9.6-457.7,59.4-683.6,191.5c-162.8,95.7-432.8,363.8-524.7,518.9c-530.4,901.9,21.1,2052.8,1060.9,2213.6C6895.9-353.9,7165.9-367.3,7303.8-403.7z"/><path d="M1325.5-901.6v-201.1h1426.6h1426.6v201.1v201.1H2752.1H1325.5V-901.6z"/><path d="M1325.5-1715.4v-191.5h1426.6h1426.6v191.5v191.5H2752.1H1325.5V-1715.4z"/></g></g></svg>')
            );
            
            $labels = array(
                'add_new_item'          => __('Add Case Study', 'purdue'),
                'add_new'               => __('Add New', 'purdue'),
                'new_item'              => __('New Case Study', 'purdue'),
                'edit_item'             => __('Edit Case Study', 'purdue'),
                'update_item'           => __('Update Case Study', 'purdue'),
                'not_found'             => __('Not found', 'purdue'),
                'not_found_in_trash'    => __('Not found in Trash', 'purdue'),
            );

            $casestudy = new PurduePostType($names, $options, $labels);

        }

        private function create_publication() {
            $labels = array(
                'archives'              => __('Publication Archives', 'purdue'),
                'attributes'            => __('Post Attributes', 'purdue'),
                'parent_item_colon'     => __('Parent Publication:', 'purdue'),
                'all_items'             => __('All Publications', 'purdue'),
                'add_new_item'          => __('Add New Publication', 'purdue'),
                'new_item'              => __('New Publication', 'purdue'),
                'edit_item'             => __('Edit Publication', 'purdue'),
                'update_item'           => __('Update Publication', 'purdue'),
                'view_item'             => __('View Publication', 'purdue'),
                'view_items'            => __('View Publications', 'purdue'),
                'search_items'          => __('Search Publications', 'purdue'),
              );
              
              $args = array(
                'label'                 => __('publication-post', 'purdue'),
                'description'           => __('Publication post type', 'purdue'),
                'labels'                => $labels,
                'supports'              => array('title', 'editor', 'thumbnail', 'comments', 'trackbacks', 'revisions', 'custom-fields', 'page-attributes', 'post-formats'),
                'taxonomies'            => array('dept_tax', 'pub_tax', 'category', 'post_tag'),
                'hierarchical'          => false,
                'public'                => true,
                'show_ui'               => true,
                'show_in_menu'          => true,
                'menu_position'         => 5,
                'show_in_admin_bar'     => true,
                'show_in_nav_menus'     => true,
                'can_export'            => true,
                'has_archive'           => true,
                'exclude_from_search'   => false,
                'publicly_queryable'    => true,
                'capability_type'       => 'page',
                'show_in_rest'      => true,
                'rewrite'           => ['slug' => 'publication', 'with_front' => false],
              );

            $names = [
                'name'     => 'pub_post',
                'singular' => __('Publication', 'purdue'),
                'plural'   => __('Publications', 'purdue'),
                'slug'     => 'publication',
            ];

            $options = array( 
                'menu_icon' => 'dashicons-book'
            );
            
            $labels = array(
                'add_new_item'          => __('Add Faculty Member', 'purdue'),
                'add_new'               => __('Add New', 'purdue'),
                'new_item'              => __('New Faculty Member', 'purdue'),
                'edit_item'             => __('Edit Faculty Member', 'purdue'),
                'update_item'           => __('Update Faculty Member', 'purdue'),
                'not_found'             => __('Not found', 'purdue'),
                'not_found_in_trash'    => __('Not found in Trash', 'purdue'),
            );

            $pub = new PurduePostType($names, $options, $labels);
            $this->add_unit_tax($pub);
        }

        private function add_unit_tax($cpt) {
            $names = [
                'name' => 'academic-unit',
                'singular' => 'Academic Unit',
                'plural' => 'Academic Units',
                'slug' => 'academic-unit'
            ];

            $terms = array (
                array( 'term' => 'College of Agriculture', 'slug' => 'agriculture'),
                array( 'term' => 'College of Education', 'slug' => 'education'),
                array( 'term' => 'College of Engineering', 'slug' => 'engineering'),
                array( 'term' => 'Exploratory Studies', 'slug' => 'exploratory-studies'),
                array( 'term' => 'College of Health and Human Sciences', 'slug' => 'hhs'),
                array( 'term' => 'College of Liberal Arts', 'slug' => 'liberal-arts'),
                array( 'term' => 'Krannert School of Management', 'slug' => 'management'),
                array( 'term' => 'College of Pharmacy', 'slug' => 'pharmacy'),
                array( 'term' => 'Purdue Polytechnic Institute', 'slug' => 'polytechnic'),
                array( 'term' => 'College of Science', 'slug' => 'science'),
                array( 'term' => 'College of Veterinary Medicine', 'slug' => 'vet'),
                array( 'term' => 'The Honors College', 'slug' => 'honors'),
                array( 'term' => 'The Graduate School', 'slug' => 'graduate'),
            );

            $cpt->add_taxonomy($names, array(), $terms);
        }

        private function add_expertise_tax($cpt) {
            $names = [
                'name' => 'expertise',
                'singular' => 'Expertise',
                'plural' => 'Expertise',
                'slug' => 'expertise'
            ];
            $terms = array();

            $cpt->add_taxonomy($names, array(), $terms);
        }

        private function add_subnav_tax($cpt) {
            $names = [
                'name' => 'subnav',
                'singular' => 'Sub Nave Menu',
                'slug' => 'subnav',
                'public' => false
            ];

            $terms = array();

            $cpt->add_taxonomy($names, array(), $terms);
        }
        
        private function create_templates() {
            $names = [
                'name'     => 'template',
                'singular' => __('Template', 'purdue'),
                'plural'   => __('Templates', 'purdue'),
                'slug'     => 'template',
            ];

            $options = array( 
                'supports'              => array( 'title', 'thumbnail', 'revisions' ),
                'taxonomies'            => array( 'post_tag', 'platform', 'temptype' ),
                'hierarchical'          => false,
                'public'                => true,
                'show_ui'               => true,
                'show_in_menu'          => true,
                'menu_position'         => 5,
                'menu_icon'             => 'dashicons-layout',
                'show_in_admin_bar'     => true,
                'show_in_nav_menus'     => true,
                'can_export'            => true,
                'has_archive'           => false,
                'exclude_from_search'   => true,
                'publicly_queryable'    => true,
                'rewrite'               => false,
                'capability_type'       => 'post',
                'show_in_rest'          => true,
            );

            $labels = array(
                'add_new_item'          => __('Add Template', 'purdue'),
                'add_new'               => __('Add New', 'purdue'),
                'new_item'              => __('New Template', 'purdue'),
                'edit_item'             => __('Edit Template', 'purdue'),
                'update_item'           => __('Update Template', 'purdue'),
                'not_found'             => __('Not found', 'purdue'),
                'not_found_in_trash'    => __('Not found in Trash', 'purdue'),
            );

            $template = new PurduePostType($names, $options, $labels);
            $this->add_tempformat_tax($template);
            $this->add_temptype_tax($template);

            $this->_classic[] = 'template';
        }

        private function add_tempformat_tax($cpt) {
            $names = [
                'name' => 'tempformat',
                'singular' => 'Template Format',
                'plural' => 'Template Format',
                'slug' => 'tempformat'
            ];

            $terms = array (
                array( 'term' => 'InDesign', 'slug' => 'indesign'),
                array( 'term' => 'Microsoft Office', 'slug' => 'ms-office'),
                array( 'term' => 'Social Media', 'slug' => 'social-media'),
                array( 'term' => 'Videos', 'slug' => 'video'),
                array( 'term' => 'Zoom/Teams', 'slug' => 'conference'),
                array( 'term' => 'Digital Signs', 'slug' => 'digital-signs'),
            );
        

            $cpt->add_taxonomy($names, array(), $terms);
        }

        private function add_temptype_tax($cpt) {
            $names = [
                'name' => 'temptype',
                'singular' => 'Template Type',
                'plural' => 'Template Type',
                'slug' => 'temptype'
            ];

            
            $terms = array (
                array( 'term' => 'Brochure', 'slug' => 'indesign'),
                array( 'term' => 'Flyer', 'slug' => 'ms-office'),
                array( 'term' => 'Postcard', 'slug' => 'social-media'),
                array( 'term' => 'Poster', 'slug' => 'poster'),
                array( 'term' => 'Calendar', 'slug' => 'calendar'),
                array( 'term' => 'Schedule/Agenda', 'slug' => 'schedule'),
                array( 'term' => 'Rack Card', 'slug' => 'rackcard'),
                array( 'term' => 'Certificate/Award', 'slug' => 'certificate'),
                array( 'term' => 'Newsletter', 'slug' => 'newsletter'),
                array( 'term' => 'Note Card', 'slug' => 'note-card'),
                array( 'term' => 'Half Sheet', 'slug' => 'half-sheet'),
                array( 'term' => 'Presentation', 'slug' => 'presentation'),
                array( 'term' => 'PowerPoint', 'slug' => 'powerpoint'),
                array( 'term' => 'Word', 'slug' => 'word'),
                array( 'term' => 'Facebook', 'slug' => 'facebook'),
                array( 'term' => 'Instagram', 'slug' => 'instagram'),
                array( 'term' => 'Twitter', 'slug' => 'twitter'),
                array( 'term' => 'LinkedIn', 'slug' => 'linkedin'),
                array( 'term' => 'Profile', 'slug' => 'profile'),
                array( 'term' => 'Animation', 'slug' => 'animation'),
                array( 'term' => 'Lower Third', 'slug' => 'lower-third'),
            );
        

            $cpt->add_taxonomy($names, array(), $terms);
        }
    }

    $PurdueCPT = new PurduePostTypes();
endif;
