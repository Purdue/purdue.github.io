document.addEventListener('DOMContentLoaded', () => {
	document.body.classList.add('no-outline-carousel-nav');
});

window.addEventListener('keydown', (event) => {
	if (9 === event.keyCode) {
		// tab key.
		document.body.classList.remove('no-outline-carousel-nav');
	}
});
