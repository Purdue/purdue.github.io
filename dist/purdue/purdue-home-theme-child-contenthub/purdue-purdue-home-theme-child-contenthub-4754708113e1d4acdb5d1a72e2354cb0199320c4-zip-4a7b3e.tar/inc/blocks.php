<?php
/**
 * Blocks Initializer
 *
 * @since   1.0.0
 * @package purdue-home-theme
 */

$tppBlocks = array();

$tppBlocks[] = 'link-hero-tpp';

function purdue_load_block_init_tpp() {
	
	global $tppBlocks;

	foreach($tppBlocks as $block){
		register_block_type( get_stylesheet_directory() . '/build/blocks/' . $block);
	}
	
}
add_action( 'init', 'purdue_load_block_init_tpp' );
