// TinySlider
import { tns } from '../../../node_modules/tiny-slider/src/tiny-slider';
if (document.querySelector('.rkv-slider-box-title-button.purdue-variation-5') !== null) {
	// Content slider
	const variation_5_sliders = document.querySelectorAll(
		'.rkv-slider-box-title-button.purdue-variation-5'
	);

	variation_5_sliders.forEach((variation_5_slider, i) => {
		tns({
			container: variation_5_sliders[i].querySelector('.rkv-slider-box-title-button-slides'),
			autoplay: false,
			mouseDrag: true,
			navPosition: 'bottom',
			controls: true,
			controlsPosition: 'bottom',
			loop: true,
			speed: 400,
			swipeAngle: false,
			gutter: 25,
			fixedWidth: 318,
			preventScrollOnTouch: 'auto',
			navAsThumbnails: true,
		});
	});
}
