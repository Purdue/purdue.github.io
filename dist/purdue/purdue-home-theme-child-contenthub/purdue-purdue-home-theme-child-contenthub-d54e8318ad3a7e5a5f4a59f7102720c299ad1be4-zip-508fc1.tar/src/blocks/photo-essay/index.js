import { registerBlockType } from '@wordpress/blocks';
import { InnerBlocks } from "@wordpress/block-editor";
import edit from './edit';
import './style.scss';
import metadata from './block.json';
import './editor.scss';
//import icon from './icon';

registerBlockType( metadata.name, {
 // import: icon, 
  edit: edit,
  save: () => {
    return <InnerBlocks.Content />;
  },
} );