<?php

$block_wrapper_attributes = get_block_wrapper_attributes( array(
    'class' => 'storytelling-content-block section'.($attributes['background'] ? ' has-background-' . $attributes['background'] : '' ),
) );
?>

<div <?php echo wp_kses_post( $block_wrapper_attributes ); ?>>

    <?php if ( ! empty( $attributes['factTitle'] ) ) : ?>
        <p><?php echo esc_html( $attributes['factTitle'] ); ?></p>
    <?php endif; ?>

     <?php if ( ! empty( $attributes['factText'] ) ) : ?>
        <p><?php echo esc_html( $attributes['factText'] ); ?></p>
    <?php endif; ?>

    <?php if ( ! empty( $attributes['factTitle2'] ) ) : ?>
        <p><?php echo esc_html( $attributes['factTitle2'] ); ?></p>
    <?php endif; ?>
    

     <?php if ( ! empty( $attributes['factText2'] ) ) : ?>
        <p><?php echo esc_html( $attributes['factText2'] ); ?></p>
    <?php endif; ?>

    <?php if ( ! empty( $attributes['factTitle3'] ) ) : ?>
        <p><?php echo esc_html( $attributes['factTitle3'] ); ?></p>
    <?php endif; ?>

     <?php if ( ! empty( $attributes['factText3'] ) ) : ?>
        <p><?php echo esc_html( $attributes['factText3'] ); ?></p>
    <?php endif; ?>

</div>

