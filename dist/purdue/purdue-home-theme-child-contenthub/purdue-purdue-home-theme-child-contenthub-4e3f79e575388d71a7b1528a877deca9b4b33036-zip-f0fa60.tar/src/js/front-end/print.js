document.addEventListener('DOMContentLoaded', function () {
	var printIcon = document.querySelector('.icon.print-icon');
	if(printIcon){
		printIcon.addEventListener('click', (event)=>{
			event.preventDefault;
			window.print();
		});
	}
});