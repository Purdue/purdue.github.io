document.addEventListener('DOMContentLoaded', function () {
	var sortForm = document.getElementById('search-sort-form');
	if(sortForm){
		var sortRadios = [...sortForm.elements['search_sort']];
		sortRadios.forEach(function(radio) {
			radio.addEventListener('change', handleSortChange);
		});
	}

	function handleSortChange(event) {
		event.preventDefault(); // Prevent default form submission
		sortForm.submit();
	}
});