const defaultConfig = require( '@wordpress/scripts/config/webpack.config.js' );

module.exports = {
  ...defaultConfig,
  entry: {
    app:['./src/js/front-end/app.js', './src/style/front-end/app.scss'],
    admin:['./src/js/back-end/admin.js', './src/style/back-end/admin.scss'],
  },
  
  optimization: {
    splitChunks: {
      cacheGroups: {
        ...defaultConfig.optimization.splitChunks.cacheGroups,
      }
    }
  }
}