// TinySlider
import { tns } from '../../../node_modules/tiny-slider/src/tiny-slider';
if (document.querySelector('.rkv-block-cover-card-slider.purdue-variation-2') !== null) {
	// Content slider
	const variation_2_sliders = document.querySelectorAll(
		'.rkv-block-cover-card-slider.purdue-variation-2 .rkv-block-cover-card-slider-slides'
	);

	const variation_2_slider_containers = [];

	variation_2_sliders.forEach((variation_2_slider, i) => {
		variation_2_slider_containers[i] = tns({
			container: variation_2_slider,
			autoplay: false,
			mouseDrag: true,
			navPosition: 'bottom',
			controls: true,
			controlsPosition: 'bottom',
			loop: true,
			rewind: false,
			speed: 400,
			swipeAngle: false,
			gutter: 25,
			navAsThumbnails: true,
			responsive: {
				0: {
					fixedWidth: 318,
				},
				768: {
					fixedWidth: 660,
				},
			},
			preventScrollOnTouch: 'auto',
		});
		// variation_2_slider.style.transform = 'translateX(0px)';
	});
	document.addEventListener('load', () => {
		variation_2_sliders.forEach((slider) => {
			slider.style.transform = 'translateX(0px)';
		});
	});
}
