<?php
/**
 * genre custom taxonomy.
 *
 * @package rkv-theme
 */
add_action( 'acf/include_fields', function() {
	if ( ! function_exists( 'acf_add_local_field_group' ) ) {
		return;
	}

	acf_add_local_field_group( array(
	'key' => 'group_65df9a13c20c6',
	'title' => 'Page Hero',
	'fields' => array(
		array(
			'key' => 'field_65df9a14c5d57',
			'label' => 'Add a simple hero with social share links?',
			'name' => 'add_a_simple_hero',
			'aria-label' => '',
			'type' => 'checkbox',
			'instructions' => '',
			'required' => 0,
			'conditional_logic' => 0,
			'wrapper' => array(
				'width' => '',
				'class' => '',
				'id' => '',
			),
			'choices' => array(
				'Yes' => 'Yes',
			),
			'default_value' => array(
				0 => 'Yes',
			),
			'return_format' => 'value',
			'allow_custom' => 0,
			'layout' => 'vertical',
			'toggle' => 0,
			'save_custom' => 0,
			'custom_choice_button_text' => 'Add new choice',
		),
	),
	'location' => array(
		array(
			array(
				'param' => 'post_type',
				'operator' => '==',
				'value' => 'topic',
			),
		),
	),
	'menu_order' => 0,
	'position' => 'side',
	'style' => 'default',
	'label_placement' => 'top',
	'instruction_placement' => 'label',
	'hide_on_screen' => '',
	'active' => true,
	'description' => '',
	'show_in_rest' => 0,
) );

acf_add_local_field_group( array(
    'key' => 'group_related_post_for_template',
    'title' => 'Featured Image Position',
    'fields' => array(
        array(
            'key' => 'field_related_post',
            'label' => 'Featured Image Position',
            'name' => 'featued_image_position',
            'type' => 'select',
            'allow_null' => 1,
            'multiple' => 0,
            'return_format' => 'id',
            'ui' => 1,
            'instructions' => 'Select the focus area of the featured image.',
			'required' => 0,
            'conditional_logic' => 0,
            'wrapper' => array(
                'width' => '',
                'class' => '',
                'id' => '',
            ),
            'choices' => array(                
                'top'   => 'Top',
                'center' => 'Center',
                'bottom'   => 'Bottom',
            ),
            'default_value' => array(
                0 => 'center',
            ),
        ),
    ),
    'location' => array(
        array(
            array(
                'param' => 'post_type',
                'operator' => '==',
                'value' => 'post',
            ),
            array(
                'param' => 'post_template',
                'operator' => '==',
                'value' => 'single-photo-essay.php', 
            ),
        ),
    ),
    'menu_order' => 0,
    'position' => 'side',
    'style' => 'default',
    'label_placement' => 'top',
    'instruction_placement' => 'label',
    'hide_on_screen' => '',
    'active' => true,
    'description' => '',
    'show_in_rest' => 0,
) );

} );

