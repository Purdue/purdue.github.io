const toggleClass = (el, className) => el.classList.toggle(className);

const accordions = document.querySelectorAll('.rkv-accordion__title');
if (accordions.length > 0) {
	for (let i = 0; i < accordions.length; i++) {
		accordions[i].addEventListener('click', (event) => {
			toggleClass(accordions[i].parentNode, 'expandChildMenu');
			event.preventDefault();
		});
	}
}
const id = window.location.hash;
if (id) {
	const el = document.querySelector(id);
	if (el) {
		if (el.classList.contains('rkv-accordion')) {
			window.scrollTop = el.offsetTop - 100;
			el.classList.add('expandChildMenu');
		}
		if (el.parentElement && el.parentElement.classList.contains('rkv-accordion')) {
			window.scrollTop = el.offsetTop - 100;
			el.parentElement.classList.add('expandChildMenu');
		}
		if (el.parentElement && el.parentElement.classList.contains('rkv-accordion__content')) {
			window.scrollTop = el.offsetTop - 100;
			el.parentElement.parentElement.classList.add('expandChildMenu');
		}
	}
}
