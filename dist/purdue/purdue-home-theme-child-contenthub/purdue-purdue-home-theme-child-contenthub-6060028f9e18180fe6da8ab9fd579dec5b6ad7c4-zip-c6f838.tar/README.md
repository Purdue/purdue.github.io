# purdue-home-theme-child-contenthub
Child theme for content hub site
