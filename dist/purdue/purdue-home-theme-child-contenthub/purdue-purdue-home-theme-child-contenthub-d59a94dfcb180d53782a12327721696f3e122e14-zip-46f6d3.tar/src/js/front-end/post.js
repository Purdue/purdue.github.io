document.addEventListener('DOMContentLoaded', function () {
    stories = document.querySelectorAll('.purdue-home-cta-card--story');
    if (stories) {
        stories.forEach(story => {
            if (story.classList.contains('post-type-podcast')) {
                story.querySelector('.purdue-home-button').innerText = "Listen"
            }
            if (story.classList.contains('post-type-article')) {
                story.querySelector('.purdue-home-button').innerText = 'Read';
            }
            if (story.classList.contains('post-type-video')) {
                story.querySelector('.purdue-home-button').innerText = 'Watch';
            }
        });
    }
}
)
