import { registerBlockType } from "@wordpress/blocks";
import { InnerBlocks } from "@wordpress/block-editor";
import Edit from "./edit";
import metadata from "./block.json";
import './editor.scss';
import './style.scss';
import icon from './icon';

registerBlockType( metadata.name, {
 icon: icon, 
  edit: Edit,
  save: () => {
    return <InnerBlocks.Content />;
  },
} );