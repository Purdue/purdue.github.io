<?php

/*$block_wrapper_attributes = get_block_wrapper_attributes( array(
    'class' => 'storytelling-featured section'),
);*/

$block_wrapper_attributes = "class='wp-block-purdue-storytelling-featured storytelling-featured'";
$image_url = $attributes['featuredImageURL'] ?? '';
$image_alt = $attributes['featuredImageAlt'] ?? '';

?>

<div <?php echo wp_kses_post( $block_wrapper_attributes ); ?>>

    <div class="featured-texture">
        <img src="<?php echo esc_url( get_stylesheet_directory_uri() .  '/imgs/Student-storytelling-texture-background.png' ); ?>" alt="" aria-hidden="true" />
    </div>

    <?php if ( ! empty( $image_url ) ) : ?>
        <div class="featured-image-wrapper image is-16by9">
            <img class="featured-image" src="<?php echo esc_url( $image_url ); ?>" alt="<?php echo esc_attr( $image_alt ); ?>" />
        </div>
    <?php endif; ?>
    <div class="columns featured-content-wrapper is-mobile">
        <div class="column is-6 is-offset-3">
            <?php echo $content;?>  
        </div>
    </div>

   

</div>