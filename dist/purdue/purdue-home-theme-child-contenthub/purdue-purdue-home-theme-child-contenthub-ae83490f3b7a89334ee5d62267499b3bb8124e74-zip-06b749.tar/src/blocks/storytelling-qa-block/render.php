<?php

$block_wrapper_attributes = get_block_wrapper_attributes( array(
    'class' => 'storytelling-qa-block section'.($attributes['background'] ? ' has-background-' . $attributes['background'] : '' ),
) );
?>

<div <?php echo wp_kses_post( $block_wrapper_attributes ); ?>>

     <div class="storytelling-qa-block__qa"><p><span>Q+A</span></p></div>

    <?php if ( ! empty( $attributes['question'] ) ) : ?>
        <p class="qa-question"><?php echo wp_kses_post( $attributes['question'] ); ?></p>
    <?php endif; ?>

     <?php if ( ! empty( $attributes['answer'] ) ) : ?>
        <p class="qa-answer"><?php echo wp_kses_post( $attributes['answer'] ); ?></p>
    <?php endif; ?>    

</div>

