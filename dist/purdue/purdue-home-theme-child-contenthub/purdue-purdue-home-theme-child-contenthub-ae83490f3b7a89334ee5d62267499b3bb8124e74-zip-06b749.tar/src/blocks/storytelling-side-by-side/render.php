<div class="purdue-storytelling-side-by-side columns is-gapless">
      <?php echo $content;?>
</div>