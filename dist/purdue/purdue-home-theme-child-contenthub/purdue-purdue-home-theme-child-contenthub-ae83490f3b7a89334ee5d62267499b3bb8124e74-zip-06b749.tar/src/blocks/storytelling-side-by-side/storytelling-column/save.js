import { InnerBlocks, useBlockProps } from '@wordpress/block-editor';

export default function save(props) {

  return (
    <div className={`column is-half`}>
      <InnerBlocks.Content />
    </div>
  );
}
