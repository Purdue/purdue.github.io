<?php
/**
 * Blocks Initializer
 *
 * @since   1.0.0
 * @package purdue-home-theme
 */

$tppBlocks = array();

$tppBlocks[] = 'link-hero-tpp';
$tppBlocks[] = 'at-a-glance';
$tppBlocks[] = 'photo-essay';
$tppBlocks[] = 'photo-essay/photo-essay-column';
$tppBlocks[] = 'storytelling-side-by-side';
$tppBlocks[] = 'storytelling-side-by-side/storytelling-column';
$tppBlocks[] = 'storytelling-content-block';
$tppBlocks[] = 'storytelling-qa-block';
$tppBlocks[] = 'storytelling-hero';
$tppBlocks[] = 'storytelling-featured-content';

function purdue_load_block_init_tpp() {
	
	global $tppBlocks;

	foreach($tppBlocks as $block){
		if($block === 'storytelling-hero'){
			register_block_type( get_stylesheet_directory() . '/build/blocks/' . $block, array(
				'render_callback' => '__return_empty_string',
			) );
			continue;
		}
		register_block_type( get_stylesheet_directory() . '/build/blocks/' . $block);
	}
	
}
add_action( 'init', 'purdue_load_block_init_tpp' );
