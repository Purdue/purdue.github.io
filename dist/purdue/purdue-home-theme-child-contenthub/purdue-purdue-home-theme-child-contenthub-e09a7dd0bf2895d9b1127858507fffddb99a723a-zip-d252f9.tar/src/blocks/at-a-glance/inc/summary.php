<?php function splitSummary($text, $wordLimit, $id, $spanClass = 'details-text') {
    // Split text into words
    $fullText = explode(' ', $text);

    // Check if the text exceeds the word limit
    if (count($fullText) > $wordLimit) {
        // Extract the visible and extra words
        $teaser = array_slice($fullText, 0, $wordLimit);
        $details = array_slice($fullText, $wordLimit);

        // Join the visible words
        $visibleText = implode(' ', $teaser);
        // Join the extra words and wrap them in a <span>
        $detailsText = '<span id="' .$id. '" class="' . htmlspecialchars($spanClass) . '">' . implode(' ', $details). '</span>';

        // Return the combined text
        return $visibleText . ' <span class="purdue-at-a-glance__wrapper">' . $detailsText . '<button aria-expanded="false" aria-controls="' .$id. '" class="purdue-at-a-glance__expand">&hellip;Expand</button></span>';
    }

    // If text doesn't exceed the limit, return it as is
    return $text;
}