let expandBtn = document.querySelector('.purdue-at-a-glance__expand');
let wrapper = document.querySelector('.purdue-at-a-glance');
let extraText = document.querySelector('.extra-text');

if(expandBtn){
  expandBtn.addEventListener('click', () => {
    if(wrapper.classList.contains('is-open')){
      wrapper.classList.remove('is-open');
      expandBtn.setAttribute('aria-expanded', false);
      expandBtn.textContent = "Expand";
    }else{
      wrapper.classList.add('is-open');
      expandBtn.setAttribute('aria-expanded', true);
      expandBtn.textContent = "Collapse"      
    }
    
  })
}