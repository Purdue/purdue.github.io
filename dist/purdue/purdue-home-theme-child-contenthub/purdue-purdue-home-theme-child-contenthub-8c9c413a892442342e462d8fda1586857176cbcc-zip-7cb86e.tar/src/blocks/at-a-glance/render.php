<?php

include_once("inc/summary.php");

$text = $content;
$wordLimit = 10;

?>



<div class="purdue-at-a-glance">
    <div class="section"> 
            <p><strong>At a Glance:</strong> <?php echo splitSummary($text, $wordLimit, $attributes['id']); ?> </p> 
    </div>
</div>