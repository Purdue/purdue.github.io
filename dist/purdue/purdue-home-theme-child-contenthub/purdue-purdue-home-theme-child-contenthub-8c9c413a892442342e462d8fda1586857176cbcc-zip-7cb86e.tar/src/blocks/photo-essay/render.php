<div class="photo-essay columns is-centered">
      <?php echo $content;?>
</div>