<?php

add_action( 'gform_post_process', 'after_form_submits', 10, 2 );

function after_form_submits($entry, $form){
    set_query_var('form_check', 'yes');
    get_template_part('single-tldr');
}