# Email Signature Builder

Build branded HTML Email Signatures

## Changelog

Relevant changes to the Email Signature Builder are documented below as a resource for users.
### [0.2.4] - 2023-01-20
#### Changed
- Add the pursistant pursuit banner option

### [0.2.2] - 2020-06-09
#### Changed
- Fixed typo in signature image tag "witdh" to "width"
- Added title to <img> tag


### [0.2.1] - 2020-05-28
#### Changed
- Pulled from Brand Site codebase added to Purdue repository

### [0.2.0] - 2020-05-28
#### Added
- Added support of approved promotional banner


### [0.1.0] - 2020-01-29
#### Added
- Initial Release based on Code from UGA (brand.uga.edu)
