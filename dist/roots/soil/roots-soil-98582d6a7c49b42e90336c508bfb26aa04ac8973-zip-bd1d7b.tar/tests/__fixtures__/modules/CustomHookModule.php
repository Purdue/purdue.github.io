<?php

namespace Roots\Soil\Tests\Fixtures\Modules;

class CustomHookModule extends StubModule
{
    protected $hook = 'custom-hook';
}
