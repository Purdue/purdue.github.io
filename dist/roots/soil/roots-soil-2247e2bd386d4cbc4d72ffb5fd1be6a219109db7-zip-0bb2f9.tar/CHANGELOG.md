### 3.0.0: March 31st, 2014
* Rewrite, Soil is now a plugin with functionality migrated out of the Roots starter theme: clean-up, relative URLs, nice search. Take a look at [Bedrock](https://github.com/roots/bedrock) if you like the ideas from the old Soil, and use Composer to manage plugins on your WP installation.

### 2.0.0: November 1st, 2012
* Add base mu-plugin for all site specific functionality (custom post types, taxonomies, meta boxes, shortcodes)
* Update all plugins
* Remove SLD Custom Content and Taxonomies

### 1.0.0: July 30th, 2012
* Initial commit
