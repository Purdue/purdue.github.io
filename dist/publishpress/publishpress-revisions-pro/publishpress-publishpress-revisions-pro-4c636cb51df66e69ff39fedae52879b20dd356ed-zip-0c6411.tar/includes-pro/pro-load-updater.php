<?php
require_once(RVY_ABSPATH . '/includes-pro/library/Factory.php');
\PublishPress\Revisions\Factory::get_container();
