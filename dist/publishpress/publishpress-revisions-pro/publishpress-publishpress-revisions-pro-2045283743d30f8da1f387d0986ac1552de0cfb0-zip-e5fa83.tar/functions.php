<?php

function revisionary() {
    return \PublishPress\Revisions::instance();
}
