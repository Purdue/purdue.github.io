<?php
require_once(REVISIONARY_PRO_ABSPATH . '/includes-pro/library/Factory.php');
\PublishPress\Revisions\Factory::get_container();
