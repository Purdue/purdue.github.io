<?php
namespace PublishPress\Permissions\Teaser\UI;

use \PublishPress\Permissions\UI\SettingsAdmin as SettingsAdmin;

require_once(__DIR__ . '/TeaserUIBaseTrait.php');

/**
 * PressPermit Custom Post Statuses administration panel.
 *
 */

class PostsTeaser
{
    use TeaserUIBaseTrait;

	var $blockEditorActive = true;

    function __construct() {
        add_filter('presspermit_option_tabs', [$this, 'optionTabs'], 7);
        add_filter('presspermit_section_captions', [$this, 'sectionCaptions']);
        add_filter('presspermit_option_captions', [$this, 'optionCaptions']);
        add_filter('presspermit_option_sections', [$this, 'optionSections']);

		$this->blockEditorActive = PWP::isBlockEditorActive();

        // This script executes on admin.php plugin page load (called by Dashboard\DashboardFilters::actMenuHandler)
        //
        $this->display();
    }

    function optionTabs($tabs)
    {
        $tabs['teaser'] = esc_html__('Teaser', 'press-permit-core');
        return $tabs;
    }

    function sectionCaptions($sections)
    {
        $new = [
            'teaser_type' => esc_html__('Teaser Type', 'press-permit-core'),
            'coverage' => esc_html__('Coverage', 'press-permit-core'),
            'teaser_text' => esc_html__('No Teaser Text', 'press-permit-core'),
            'redirect' => esc_html__('Redirect', 'press-permit-core'),
            'options' => esc_html__('Options', 'press-permit-core'),

            'hidden_content_teaser' => esc_html__('Hidden Content Teaser', 'press-permit-core'),
        ];
        $key = 'teaser';
        $sections[$key] = (isset($sections[$key])) ? array_merge($sections[$key], $new) : $new;
        return $sections;
    }

    function optionCaptions($captions)
    {
        $opt = [
            'rss_private_feed_mode' => esc_html__('Display mode for readable private posts', 'press-permit-core'),
            'rss_nonprivate_feed_mode' => esc_html__('Display mode for readable non-private posts', 'press-permit-core'),
            'feed_teaser' => esc_html__('Feed Replacement Text (use %permalink% for post URL)', 'press-permit-core'),
            'teaser_opt_direct_access_only' => esc_html__('Apply teaser to list view as well as single view', 'press-permit-core'),
            'teaser_opt_logged_only' => esc_html__('Apply teaser to logged in and/or logged out users', 'press-permit-core'),
            'teaser_opt_hide_menu_links' => esc_html__('Hide navigation menu links to restricted content', 'press-permit-core'),
            'teaser_opt_public_posts_only' => esc_html__('Apply teaser to private posts', 'press-permit-core'),
            'teaser_opt_hide_thumbnail' => esc_html__('Hide Featured Image when Teaser is applied', 'press-permit-core'),
            'teaser_opt_disable_comments' => esc_html__('Disable Comments when Teaser is applied', 'press-permit-core'),
            'teaser_hide_custom_private_only' => esc_html__('"Hide Private" settings only apply to custom privacy (Member, Premium, Staff, etc.)', 'press-permit-core'),
        ];

        return array_merge($captions, $opt);
    }

    function optionSections($sections)
    {
        $new = [
            'teaser_type' => ['use_teaser'],
            'coverage' => ['teaser_hide_custom_private_only'],
            'menu' => [''],
            'redirect' => ['teaser_redirect_anon', 'teaser_redirect_anon_page', 'teaser_redirect', 'teaser_redirect_page', 'teaser_redirect_custom_login_page_anon', 'teaser_redirect_custom_login_page'],
            'teaser_text' => ['tease_replace_content', 'tease_prepend_content', 'tease_prepend_content_anon',
                              'tease_append_content', 'tease_append_content_anon', 'tease_prepend_name', 'tease_prepend_name_anon',
                              'tease_append_name', 'tease_append_name_anon', 'tease_replace_excerpt', 'tease_replace_excerpt_anon',
                              'tease_prepend_excerpt', 'tease_prepend_excerpt_anon', 'tease_append_excerpt', 'tease_append_excerpt_anon'],
            'hidden_content_teaser' => ['teaser_hide_custom_private_only'],
            'options' => [
                'teaser_opt_direct_access_only', 'teaser_opt_logged_only', 'teaser_opt_hide_menu_links',
                'teaser_opt_public_posts_only', 'teaser_opt_hide_thumbnail', 'teaser_opt_disable_comments',
                'rss_private_feed_mode', 'rss_nonprivate_feed_mode', 'feed_teaser',
            ],
        ];

        $key = 'teaser';
        $sections[$key] = (isset($sections[$key])) ? array_merge($sections[$key], $new) : $new;
        return $sections;
    }

    function getStr($code) {
        return apply_filters('presspermit_admin_get_string', '', $code);
    }

    private function renderTeaserApplicationOptions($ui, $tab, $section) {
        ?>
        <div class="pp-teaser-application-options">
            <table class="widefat fixed striped teaser-table pp-teaser-application-table">
                <colgroup>
                    <col style="width: 25%;">
                    <col style="width: 75%;">
                </colgroup>
                <thead>
                    <tr>
                        <th colspan="2">
                            <strong><?php esc_html_e('Application', 'press-permit-core'); ?></strong>
                        </th>
                    </tr>
                </thead>
                <tbody>
                <?php
                if (in_array('teaser_opt_direct_access_only', $ui->form_options[$tab][$section], true)) :
                    $id = 'teaser_opt_direct_access_only';
                    $ui->all_options[] = $id;
                    $val = (int) $ui->getOption($id);
                    ?>
                    <tr>
                        <th><?php esc_html_e('Teaser Application', 'press-permit-core'); ?></th>
                        <td>
                            <label style="margin-right: 20px;">
                                <input type="radio" name="<?php echo esc_attr($id); ?>" value="0"<?php checked($val, 0); ?>>
                                <?php esc_html_e('List and Single view', 'press-permit-core'); ?>
                            </label>
                            <label>
                                <input type="radio" name="<?php echo esc_attr($id); ?>" value="1"<?php checked($val, 1); ?>>
                                <?php esc_html_e('Single view only', 'press-permit-core'); ?>
                            </label>
                        </td>
                    </tr>
                <?php endif; ?>

                <?php
                if (in_array('teaser_opt_logged_only', $ui->form_options[$tab][$section], true)) :
                    $id = 'teaser_opt_logged_only';
                    $ui->all_options[] = $id;
                    $val = (string) $ui->getOption($id);
                    ?>
                    <tr>
                        <th><?php esc_html_e('User Application', 'press-permit-core'); ?></th>
                        <td>
                            <label style="margin-right: 20px;">
                                <input type="radio" name="<?php echo esc_attr($id); ?>" value="0"<?php checked($val === '0' || '' === $val, true); ?>>
                                <?php esc_html_e('Both', 'press-permit-core'); ?>
                            </label>
                            <label style="margin-right: 20px;">
                                <input type="radio" name="<?php echo esc_attr($id); ?>" value="anon"<?php checked($val, 'anon'); ?>>
                                <?php esc_html_e('Not Logged In Users', 'press-permit-core'); ?>
                            </label>
                            <label>
                                <input type="radio" name="<?php echo esc_attr($id); ?>" value="1"<?php checked($val, '1'); ?>>
                                <?php esc_html_e('Logged In Users', 'press-permit-core'); ?>
                            </label>
                        </td>
                    </tr>
                <?php endif; ?>

                <?php
                if (in_array('teaser_opt_hide_menu_links', $ui->form_options[$tab][$section], true)) :
                    $id = 'teaser_opt_hide_menu_links';
                    $ui->all_options[] = $id;
                    $val = (int) $ui->getOption($id);
                    ?>
                    <tr>
                        <th><?php esc_html_e('Navigation Menus', 'press-permit-core'); ?></th>
                        <td>
                            <label style="margin-right: 20px;">
                                <input type="radio" name="<?php echo esc_attr($id); ?>" value="0"<?php checked($val, 0); ?>>
                                <?php esc_html_e("Display links if user doesn't have access", 'press-permit-core'); ?>
                            </label>
                            <label>
                                <input type="radio" name="<?php echo esc_attr($id); ?>" value="1"<?php checked($val, 1); ?>>
                                <?php esc_html_e("Hide links if user doesn't have access", 'press-permit-core'); ?>
                            </label>
                        </td>
                    </tr>
                <?php endif; ?>

                <?php
                if (in_array('teaser_opt_public_posts_only', $ui->form_options[$tab][$section], true)) :
                    $id = 'teaser_opt_public_posts_only';
                    $ui->all_options[] = $id;
                    $val = (string) $ui->getOption($id);
                    if ('' === $val) {
                        $val = '0';
                    }
                    ?>
                    <tr>
                        <th><?php esc_html_e('Private Posts', 'press-permit-core'); ?></th>
                        <td>
                            <label style="margin-right: 20px;">
                                <input type="radio" name="<?php echo esc_attr($id); ?>" value="0"<?php checked($val, '0'); ?>>
                                <?php esc_html_e('Apply Teaser to Private Posts', 'press-permit-core'); ?>
                            </label>
                            <label style="margin-right: 20px;">
                                <input type="radio" name="<?php echo esc_attr($id); ?>" value="1"<?php checked($val, '1'); ?>>
                                <?php esc_html_e("Hide Private Posts if user doesn't have access", 'press-permit-core'); ?>
                            </label>
                            <?php if (defined('PUBLISHPRESS_STATUSES_VERSION') || class_exists('PublishPress\Statuses\Factory')) : ?>
                            <label>
                                <input type="radio" name="<?php echo esc_attr($id); ?>" value="custom"<?php checked($val, 'custom'); ?>>
                                <?php esc_html_e('Hide for Custom Visibility', 'press-permit-core'); ?>
                            </label>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endif; ?>

                <?php
                if (in_array('teaser_opt_hide_thumbnail', $ui->form_options[$tab][$section], true)) :
                    $id = 'teaser_opt_hide_thumbnail';
                    $ui->all_options[] = $id;
                    $val = (int) $ui->getOption($id);
                    ?>
                    <tr>
                        <th><?php esc_html_e('Featured Image', 'press-permit-core'); ?></th>
                        <td>
                            <label style="margin-right: 20px;">
                                <input type="radio" name="<?php echo esc_attr($id); ?>" value="0"<?php checked($val, 0); ?>>
                                <?php esc_html_e('Show featured image', 'press-permit-core'); ?>
                            </label>
                            <label>
                                <input type="radio" name="<?php echo esc_attr($id); ?>" value="1"<?php checked($val, 1); ?>>
                                <?php esc_html_e('Hide featured image when teaser is applied', 'press-permit-core'); ?>
                            </label>
                        </td>
                    </tr>
                <?php endif; ?>

                <?php
                if (in_array('teaser_opt_disable_comments', $ui->form_options[$tab][$section], true)) :
                    $id = 'teaser_opt_disable_comments';
                    $ui->all_options[] = $id;
                    $default_val = 1;
                    $stored_val = $ui->getOption($id);
                    $val = ('' === $stored_val || false === $stored_val) ? $default_val : (int) $stored_val;
                    ?>
                    <tr>
                        <th><?php esc_html_e('Comments Area', 'press-permit-core'); ?></th>
                        <td>
                            <label>
                                <input type="hidden" name="<?php echo esc_attr($id); ?>" value="0">
                                <input type="checkbox" name="<?php echo esc_attr($id); ?>" value="1"<?php checked($val, 1); ?>>
                                <?php esc_html_e('Disable the comments area when Teaser is applied', 'press-permit-core'); ?>
                            </label>
                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    private function renderRssOptions($ui, $tab, $section) {
        $rss_hint = '';

        if ($ui->display_hints) {
            ob_start();
            SettingsAdmin::echoStr('teaser_block_all_rss');
            $rss_hint = trim(ob_get_clean());
        }

        $captions = [
            'full_content' => esc_html__('Full Content', 'press-permit-core'),
            'excerpt_only' => esc_html__('Excerpt Only', 'press-permit-core'),
            'title_only' => esc_html__('Title Only', 'press-permit-core'),
        ];
        ?>
        <div class="pp-teaser-rss-options">
            <table class="widefat fixed striped teaser-table pp-teaser-rss-table">
                <colgroup>
                    <col style="width: 25%;">
                    <col style="width: 75%;">
                </colgroup>
                <thead>
                    <tr>
                        <th colspan="2">
                            <strong><?php esc_html_e('RSS', 'press-permit-core'); ?></strong>
                        </th>
                    </tr>
                </thead>
                <tbody>
                <?php if ($rss_hint) : ?>
                    <tr class="pp-teaser-rss-description-row">
                        <td colspan="2">
                            <p class="description pp-teaser-rss-description">
                                <?php echo wp_kses_post($rss_hint); ?>
                            </p>
                        </td>
                    </tr>
                <?php endif; ?>

                <?php
                if (in_array('rss_private_feed_mode', $ui->form_options[$tab][$section], true)) :
                    $ui->all_options[] = 'rss_private_feed_mode';
                    ?>
                    <tr>
                        <th>
                            <?php esc_html_e('Display for readable private posts', 'press-permit-core'); ?>
                        </th>
                        <td>
                            <select name="rss_private_feed_mode" id="rss_private_feed_mode" autocomplete="off">
                                <?php
                                foreach ($captions as $key => $caption) :
                                    ?>
                                    <option value="<?php echo esc_attr($key); ?>"<?php selected($ui->getOption('rss_private_feed_mode'), $key); ?>>
                                        <?php echo esc_html($caption); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                <?php endif; ?>

                <?php
                if (in_array('rss_nonprivate_feed_mode', $ui->form_options[$tab][$section], true)) :
                    $ui->all_options[] = 'rss_nonprivate_feed_mode';
                    ?>
                    <tr>
                        <th>
                            <?php esc_html_e('Display for readable non-private posts', 'press-permit-core'); ?>
                        </th>
                        <td>
                            <select name="rss_nonprivate_feed_mode" id="rss_nonprivate_feed_mode" autocomplete="off">
                                <?php
                                foreach ($captions as $key => $caption) :
                                    ?>
                                    <option value="<?php echo esc_attr($key); ?>"<?php selected($ui->getOption('rss_nonprivate_feed_mode'), $key); ?>>
                                        <?php echo esc_html($caption); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                <?php endif; ?>

                <?php
                if (in_array('feed_teaser', $ui->form_options[$tab][$section], true)) :
                    $id = 'feed_teaser';
                    $ui->all_options[] = $id;
                    $val = htmlspecialchars($ui->getOption($id));
                    ?>
                    <tr>
                        <th>
                            <?php esc_html_e('Feed Replacement Text', 'press-permit-core'); ?>
                        </th>
                        <td>
                            <?php
                            // phpcs Note: This option cannot currently be escaped because it supports embedded html
                            $editor_settings = [
                                'textarea_name' => $id,
                                'textarea_rows' => 6,
                                'media_buttons' => false,
                                'teeny' => true,
                                'quicktags' => ['buttons' => 'strong,em,link'],
                                'tinymce' => [
                                    'toolbar1' => 'bold,italic,link,unlink,undo,redo',
                                    'toolbar2' => '',
                                    'toolbar3' => '',
                                ],
                            ];

                            $editor_value = html_entity_decode($val, ENT_QUOTES, 'UTF-8');
                            wp_editor($editor_value, $id, $editor_settings);
                            ?>
                            <p class="description">
                                <?php
                                printf(
                                    esc_html__('Use %s for post URL', 'press-permit-core'),
                                    '<code>%permalink%</code>'
                                );
                                ?>
                            </p>
                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    private function display() {
        $pp = presspermit();
        
        echo '<form id="pp_settings_form" action="" method="post">';
        wp_nonce_field('pp-update-options');
        
        // Default active tab
        if (PWP::is_REQUEST('presspermit_submit')) {
            $current_tab = sanitize_text_field(PWP::REQUEST_key('current_tab'));
            $selected_post_type = PWP::is_REQUEST('selected_post_type') ? sanitize_text_field(PWP::REQUEST_key('selected_post_type')) : '';
        } else {
            $current_tab = 'ppp-tab-teaser-settings';
            $selected_post_type = '';
        }
        ?>
        <input type="hidden" value="<?php echo esc_attr($current_tab);?>" id="current_tab" name="current_tab">
        <input type="hidden" value="<?php echo esc_attr($selected_post_type);?>" id="selected_post_type" name="selected_post_type">
        <div class="wrap pressshack-admin-wrapper">
            <header>
                <h1 class="wp-heading-inline">
                    <?php echo esc_html(__('Posts Teaser', 'press-permit-core')); ?>
                </h1>
                <p class="description">
                    <?php esc_html_e("Use these settings to control what users see when they don't have access to your content.", 'press-permit-core'); ?>
                </p>
            </header>

			<?php
			if ( PWP::is_REQUEST( 'presspermit_submit' ) || PWP::is_REQUEST( 'presspermit_submit_redirect') ) :
				$current_tab = sanitize_text_field(PWP::REQUEST_key('current_tab'));
				?>
                <div id="message" class="updated">
                    <p>
                        <?php esc_html_e( 'All post teaser settings were updated.', 'press-permit-core' ); ?>
                    </p>
                </div>
			<?php
			elseif ( PWP::is_REQUEST( 'presspermit_defaults' ) ) :
                ?>
                <div id="message" class="updated">
                    <p>
                        <?php esc_html_e( 'All post teaser settings were reset to defaults.', 'press-permit-core' ); ?>
                    </p>
                </div>
         		<?php
			endif;
			?>

            <div class="pp-teaser-tabs-header">
                <ul id="publishpress-permissions-teaser-tabs" class="nav-tab-wrapper">
                    <li class="nav-tab<?php if ($current_tab === 'ppp-tab-teaser-settings') echo ' nav-tab-active';?>">
                      <a href="#ppp-tab-teaser-settings">
                          <?php esc_html_e('Teaser Settings', 'press-permit-core') ?>
                      </a>
                    </li>

                    <li class="nav-tab<?php if ($current_tab === 'ppp-tab-text-options') echo ' nav-tab-active';?>">
                      <a href="#ppp-tab-text-options">
                          <?php esc_html_e('Text Options', 'press-permit-core') ?>
                      </a>
                    </li>

                    <li class="nav-tab<?php if ($current_tab === 'ppp-tab-options') echo ' nav-tab-active';?>">
                      <a href="#ppp-tab-options">
                          <?php esc_html_e('Options', 'press-permit-core') ?>
                      </a>
                    </li>
                </ul>
                <?php $this->renderTopSaveButton(); ?>
            </div>

            <div id="pp-teaser">

            <?php
            do_action('presspermit_teaser_settings_ui');

            require_once(PRESSPERMIT_CLASSPATH . '/UI/SettingsAdmin.php');
            $ui = SettingsAdmin::instance();
            $tab = 'teaser';

            $ui->all_options = [];
            $ui->all_otype_options = [];

            $ui->tab_captions = apply_filters('presspermit_option_tabs', []);
            $ui->section_captions = apply_filters('presspermit_section_captions', []);
            $ui->option_captions = apply_filters('presspermit_option_captions', []);
            $ui->form_options = apply_filters('presspermit_option_sections', []);

            $ui->display_hints = presspermit()->getOption('display_hints');

            if ($_hidden = apply_filters('presspermit_hide_options', [])) {
                $hidden = [];
                foreach (array_keys($_hidden) as $option_name) {
                    if (!is_array($_hidden[$option_name]) && strlen($option_name) > 3)
                        $hidden[] = substr($option_name, 3);
                }

                foreach (array_keys($ui->form_options) as $tab_key) {
                    foreach (array_keys($ui->form_options[$tab_key]) as $section)
                        $ui->form_options[$tab_key][$section] = array_diff($ui->form_options[$tab_key][$section], $hidden);
                }
            }

            // Prepare data for new UI
            $default_options = apply_filters('presspermit_teaser_default_options', []);
            
            // Use trait method to get available post types (FREE: only 'post', PRO: all enabled)
            $available_post_types = $this->getAvailablePostTypes($pp);
            $opt_available = array_fill_keys($available_post_types, 0);
            $no_tease_types = \PublishPress\Permissions\Teaser::noTeaseTypes();

            $option_use_teaser = 'tease_post_types';
            $ui->all_otype_options[] = $option_use_teaser;
            $opt_vals = $ui->getOptionArray($option_use_teaser);
            $use_teaser = array_diff_key(array_merge($opt_available, $default_options[$option_use_teaser], $opt_vals), $no_tease_types);
            $use_teaser = array_intersect_key($use_teaser, array_fill_keys($available_post_types, true));
            $use_teaser = $pp->admin()->orderTypes($use_teaser, ['item_type' => 'post']);

            $any_teased_types = array_filter($use_teaser);

            $option_num_chars = 'teaser_num_chars';
            $ui->all_otype_options[] = $option_num_chars;
            $arr_num_chars = $ui->getOptionArray($option_num_chars);

            // Note: "Teaser Application", "User Application", "Navigation Menus", "Private
            // Posts", "Featured Image", and "Comments Area" used to be registered here as
            // per-post-type options (tease_logged_only, tease_public_posts_only,
            // tease_direct_access_only, teaser_hide_menu_links_type, teaser_hide_thumbnail,
            // teaser_disable_comments). They're now global settings on the Options tab - see
            // renderTeaserApplicationOptions() and the teaser_opt_* options (issue #2518). The
            // old per-type options are intentionally left alone in the database (read once by
            // TeaserHooks::pluginUpdated() to seed the new globals on upgrade).

            // Register teaser text options as per-post-type
            $teaser_text_options = [
                'tease_prepend_name',
                'tease_append_name',
                'tease_replace_content',
                'tease_prepend_content',
                'tease_append_content',
                'tease_prepend_name_anon',
                'tease_append_name_anon',
                'tease_prepend_content_anon',
                'tease_append_content_anon',
            ];
            
            foreach ($teaser_text_options as $option_name) {
                $ui->all_otype_options[] = $option_name;
            }

            // Register redirect options as per-post-type
            $redirect_options = [
                'teaser_redirect',
                'teaser_redirect_anon',
                'teaser_redirect_page',
                'teaser_redirect_anon_page',
                'teaser_redirect_url',
                'teaser_redirect_anon_url',
                'teaser_redirect_custom_login_page',
                'teaser_redirect_custom_login_page_anon',
            ];
            
            foreach ($redirect_options as $option_name) {
                $ui->all_otype_options[] = $option_name;
            }

            $use_teaser = array_intersect_key($use_teaser, array_fill_keys($available_post_types, true));
            $use_teaser = $pp->admin()->orderTypes($use_teaser, ['item_type' => 'post']);

            // Sort array to ensure 'post' appears first
            if (isset($use_teaser['post'])) {
                $post_value = $use_teaser['post'];
                unset($use_teaser['post']);
                $use_teaser = array_merge(['post' => $post_value], $use_teaser);
            }

            // Render new Progressive Disclosure UI
            require_once(__DIR__ . '/TeaserProgressiveUI.php');

            $options_data = [
                'arr_num_chars' => $arr_num_chars,
            ];

            $progressive_ui = new TeaserProgressiveUI($pp, $ui, $use_teaser, $options_data, $this->blockEditorActive);

            $section = 'teaser_type';

        if (!empty($ui->form_options[$tab][$section])) : ?>
            <section id="ppp-tab-teaser-settings" style="display:<?php if ($current_tab === 'ppp-tab-teaser-settings') echo 'block'; else echo 'none'; ?>;">
            <?php
            $progressive_ui->render();
            ?>

            </section>
        <?php
        endif; // any options accessable in this section

        if (!empty($ui->form_options[$tab][$section])) : ?>
            <section id="ppp-tab-text-options" style="display:<?php if ($current_tab === 'ppp-tab-text-options') echo 'block'; else echo 'none'; ?>;">
                <?php $progressive_ui->renderTextOptions(); ?>
            </section>
        <?php
        endif;


        $section = 'options';                                // --- OPTIONS SECTION ---
        if (!empty($ui->form_options[$tab][$section])) : ?>
            <section id="ppp-tab-options" style="display:<?php if ($current_tab === 'ppp-tab-options') echo 'block'; else echo 'none'; ?>;">

            <?php
            $style = (!empty($any_teased_types)) ? "display:none" : '';
            ?>
            <p class="pp-teaser-settings-na" style="<?php echo esc_attr($style);?>">
            <?php
            SettingsAdmin::echoStr('teaser_settings_not_applicable');
            ?>
            </p>

            <?php
            $style = (empty($any_teased_types)) ? "display:none" : '';
            ?>

            <div class="pp-teaser-options" style="<?php echo esc_attr($style);?>">
            <?php
            $this->renderTeaserApplicationOptions($ui, $tab, $section);
            $this->renderRssOptions($ui, $tab, $section);
            ?>
            </div>
            </section>
        <?php
        endif; // any options accessable in this section

        echo "<input type='hidden' name='all_options' value='" . esc_attr(implode(',', $ui->all_options)) . "' />";
        echo "<input type='hidden' name='all_otype_options' value='" . esc_attr(implode(',', $ui->all_otype_options)) . "' />";

        echo "<input type='hidden' name='pp_submission_topic' value='options' />";
        ?>

            <p>
                <input type="submit" name="presspermit_submit" class="button button-primary" value="<?php esc_attr_e('Save Changes', 'press-permit-core') ?>">
            </p>
        </div>
        <?php
        presspermit()->admin()->publishpressFooter();
        ?>
    </div>

    </form>
    <?php

    }

    private function renderTopSaveButton()
    {
        ?>
        <div class="pp-teaser-top-actions">
            <button type="submit" name="presspermit_submit" value="1" class="button button-primary pp-teaser-top-save">
                <?php esc_html_e('Save Changes', 'press-permit-core'); ?>
            </button>
        </div>
        <?php
    }
}
