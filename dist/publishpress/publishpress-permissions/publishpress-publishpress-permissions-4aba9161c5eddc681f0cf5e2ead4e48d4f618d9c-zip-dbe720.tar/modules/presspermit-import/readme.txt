== PP Import plugin for WordPress ==
	An extension to the PublishPress Permissions plugin, a flexible and friendly content permissions engine and management interface. 
	
	This extension plugin imports Role Scoper groups, roles, restrictions and settings.
	
	Author: Kevin Behrens - https://agapetry.net/
	
	Copyright 2020 PublishPress

	See license.txt and copyright notices within the code for further details.

	To receive a copy of the current version, one-click updates and expert support, purchase a license key at https://publishpress.com/pricing/
	
== Change Log ==

	When an update is available, bug fixes and other changes made since your currently installed version can be retrieved by clicking the "View version details" link
	in your wp-admin Plugins listing.