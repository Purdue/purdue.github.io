<?php
namespace PublishPress\Permissions\Teaser\UI;

use \PublishPress\Permissions\UI\SettingsAdmin as SettingsAdmin;

class SettingsTabTeaser
{
    function __construct()
    {
        add_filter('presspermit_option_tabs', [$this, 'optionTabs'], 7);
        add_filter('presspermit_section_captions', [$this, 'sectionCaptions']);
        add_filter('presspermit_option_captions', [$this, 'optionCaptions']);
        add_filter('presspermit_option_sections', [$this, 'optionSections']);

        add_action('presspermit_teaser_options_pre_ui', [$this, 'optionsPreUI']);
        add_action('presspermit_teaser_options_ui', [$this, 'optionsUI']);
    }

    function optionTabs($tabs)
    {
        $tabs['teaser'] = esc_html__('Teaser', 'presspermit-pro');
        return $tabs;
    }

    function sectionCaptions($sections)
    {
        $new = [
            'rss_feeds' => esc_html__('RSS Feeds', 'presspermit-pro'),
            'custom_fields' => esc_html__('Custom Fields', 'presspermit-pro'),
            'hidden_content_teaser' => esc_html__('Hidden Content Teaser', 'presspermit-pro'),
        ];
        $key = 'teaser';
        $sections[$key] = (isset($sections[$key])) ? array_merge($sections[$key], $new) : $new;
        return $sections;
    }

    function optionCaptions($captions)
    {
        $opt = [
            'rss_private_feed_mode' => esc_html__('Display mode for readable private posts', 'presspermit-pro'),
            'rss_nonprivate_feed_mode' => esc_html__('Display mode for readable non-private posts', 'presspermit-pro'),
            'feed_teaser' => esc_html__('Feed Replacement Text (use %permalink% for post URL)', 'presspermit-pro'),
            'post_teaser_enabled' => esc_html__('Enable', 'presspermit-pro'),    /* NOTE: SettingsSubmit must sync all other teaser-related options to do_teaser scope setting */
            'teaser_hide_thumbnail' => esc_html__('Hide Featured Image when Teaser is applied', 'presspermit-pro'),
            'teaser_hide_custom_private_only' => esc_html__('"Hide Private" settings only apply to custom privacy (Member, Premium, Staff, etc.)', 'presspermit-pro'),
        ];

        return array_merge($captions, $opt);
    }

    function optionSections($sections)
    {
        $new = [
            'rss_feeds' => ['rss_private_feed_mode', 'rss_nonprivate_feed_mode', 'feed_teaser'],
            'custom_fields' => ['teaser_hide_thumbnail'],
            'hidden_content_teaser' => ['post_teaser_enabled', 'teaser_hide_custom_private_only'] /* NOTE: all teaser options follow scope setting of do_teaser */
            /*, 'tease_public_posts_only', 'tease_direct_access_only', 'use_teaser', 'tease_logged_only',
                                'tease_replace_content', 'tease_replace_content_anon', 'tease_prepend_content', 'tease_prepend_content_anon',
                                'tease_append_content', 'tease_append_content_anon', 'tease_prepend_name', 'tease_prepend_name_anon',
                                'tease_append_name', 'tease_append_name_anon', 'tease_replace_excerpt', 'tease_replace_excerpt_anon',
                                'tease_prepend_excerpt', 'tease_prepend_excerpt_anon', 'tease_append_excerpt', 'tease_append_excerpt_anon' ), */
        ];

        $key = 'teaser';
        $sections[$key] = (isset($sections[$key])) ? array_merge($sections[$key], $new) : $new;
        return $sections;
    }

    function optionsPreUI()
    {
        $ui = \PublishPress\Permissions\UI\SettingsAdmin::instance();

        if (presspermit()->getOption('display_hints')) :
            ?>
            <div class="pp-hint pp-optionhint">
                <?php
                SettingsAdmin::echoStr('teaser_tab');
                ?>
            </div>
        <?php
        endif;
    }

    function optionsUI()
    {
        $pp = presspermit();

        $ui = \PublishPress\Permissions\UI\SettingsAdmin::instance();
        $tab = 'teaser';

        $section = 'rss_feeds';                                // --- RSS FEEDS SECTION ---
        if (!empty($ui->form_options[$tab][$section])) : ?>
            <tr>
                <th scope="row"><?php echo esc_html($ui->section_captions[$tab][$section]); ?></th>
                <td>

                    <?php if (in_array('rss_private_feed_mode', $ui->form_options[$tab][$section], true)) :
                        $ui->all_options[] = 'rss_private_feed_mode';

                        // prefix to RSS content dropdown'
                        esc_html_e('Display', 'presspermit-pro');
                        echo '&nbsp;<select name="rss_private_feed_mode" id="rss_private_feed_mode" autocomplete="off">';

                        $captions = ['full_content' => esc_html__("Full Content", 'presspermit-pro'), 'excerpt_only' => esc_html__("Excerpt Only", 'presspermit-pro'), 'title_only' => esc_html__("Title Only", 'presspermit-pro')];
                        foreach ($captions as $key => $value) {
                            $selected = ($ui->getOption('rss_private_feed_mode') == $key) ? ' selected ' : '';
                            echo "\n\t<option value='" . esc_attr($key) . "' " . esc_attr($selected) . ">" . esc_html($captions[$key]) . "</option>";
                        }
                        echo '</select>&nbsp;';

                        // suffix to RSS content dropdown
                        esc_html_e('for readable private posts', 'presspermit-pro');
                        echo "<br />";
                    endif;
                    ?>

                    <?php if (in_array('rss_nonprivate_feed_mode', $ui->form_options[$tab][$section], true)) :
                        $ui->all_options[] = 'rss_nonprivate_feed_mode';

                        // prefix to RSS content dropdown
                        esc_html_e('Display', 'presspermit-pro');
                        echo '&nbsp;<select name="rss_nonprivate_feed_mode" id="rss_nonprivate_feed_mode" autocomplete="off">';

                        $captions = ['full_content' => esc_html__("Full Content", 'presspermit-pro'), 'excerpt_only' => esc_html__("Excerpt Only", 'presspermit-pro'), 'title_only' => esc_html__("Title Only", 'presspermit-pro')];
                        foreach ($captions as $key => $value) {
                            $selected = ($ui->getOption('rss_nonprivate_feed_mode') == $key) ? ' selected ' : '';
                            echo "\n\t<option value='" . esc_attr($key) . "' " . esc_attr($selected) . ">" . esc_html($captions[$key]) . "</option>";
                        }
                        echo '</select>&nbsp;';

                        // suffix to RSS content dropdown
                        esc_html_e('for readable non-private posts', 'presspermit-pro');

                        echo "<br />";
                        ?>
                        <span class="pp-subtext">
                        <?php
                        if ($ui->display_hints) {
                            SettingsAdmin::echoStr('teaser_block_all_rss');
                        }
                        ?>
                    </span>
                        <br/><br/>
                    <?php endif; ?>

                    <?php if (in_array('feed_teaser', $ui->form_options[$tab][$section], true)) :
                        $id = 'feed_teaser';
                        $ui->all_options[] = $id;
                        $val = htmlspecialchars($ui->getOption($id));

                        echo "<label for='" . esc_attr($id) . "'>";
                        esc_html_e('Feed Replacement Text (use %permalink% for post URL)', 'presspermit-pro');
                        echo "<br /><textarea name='" . esc_attr($id) . "' cols=60 rows=1 id='" . esc_attr($id) . "'>" . esc_html($val) . "</textarea>";
                        echo "</label>";
                    endif;
                    ?>

                </td>
            </tr>
        <?php
        endif; // any options accessable in this section


        $section = 'custom_fields';                                // --- CUSTOM FIELDS SECTION ---
        if (!empty($ui->form_options[$tab][$section])) : ?>
            <tr>
                <th scope="row"><?php echo esc_html($ui->section_captions[$tab][$section]); ?></th>
                <td>

                    <?php
                    if (in_array('teaser_hide_thumbnail', $ui->form_options[$tab][$section], true)) {
                        $ui->optionCheckbox('teaser_hide_thumbnail', $tab, $section, '', '');
                    }
                    ?>

                </td>
            </tr>
        <?php
        endif; // any options accessable in this section


// --- HIDDEN CONTENT TEASER SECTION ---
        $section = 'hidden_content_teaser';

        $default_options = apply_filters('presspermit_teaser_default_options', []);

        if (!empty($ui->form_options[$tab][$section]) && in_array('post_teaser_enabled', $ui->form_options[$tab][$section], true)) : ?>
            <tr>
            <th scope="row"><?php echo esc_html($ui->section_captions[$tab][$section]); ?></th>
            <td>
            <?php
            $option_basename = 'post_teaser_enabled';

            $ui->all_options[] = $option_basename;

            $do_teaser = ['post' => $ui->getOption($option_basename)];

            $opt_available = array_fill_keys($pp->getEnabledPostTypes(), 0);
            $no_tease_types = Teaser::noTeaseTypes();

            $option_use_teaser = 'tease_post_types';
            $ui->all_otype_options[] = $option_use_teaser;
            $opt_vals = $ui->getOptionArray($option_use_teaser);
            $use_teaser = array_diff_key(array_merge($opt_available, $default_options[$option_use_teaser], $opt_vals), $no_tease_types);

            $option_logged_only = 'tease_logged_only';
            $ui->all_otype_options[] = $option_logged_only;
            $opt_vals = $ui->getOptionArray($option_logged_only);
            $logged_only = array_diff_key(array_merge($opt_available, $default_options[$option_logged_only], $opt_vals), $no_tease_types);

            $option_hide_private = 'tease_public_posts_only';
            $ui->all_otype_options[] = $option_hide_private;
            $opt_vals = $ui->getOptionArray($option_hide_private);
            $hide_private = array_diff_key(array_merge($opt_available, $default_options[$option_hide_private], $opt_vals), $no_tease_types);

            $option_direct_only = 'tease_direct_access_only';
            $ui->all_otype_options[] = $option_direct_only;
            $opt_vals = $ui->getOptionArray($option_direct_only);
            $direct_only = array_diff_key(array_merge($opt_available, $default_options[$option_direct_only], $opt_vals), $no_tease_types);

            // loop through each source that has a default do_teaser setting defined
            foreach ($do_teaser as $source_name => $val) {
                $id = $option_basename;

                echo '<div class="agp-vspaced_input">';
                echo "<label for='" . esc_attr($id) . "'>";
                $checked = ($val) ? ' checked ' : '';
                echo "<input name='" . esc_attr($id) . "' type='checkbox' id='" . esc_attr($id) . "' value='1'" . esc_attr($checked) . "/> ";

                esc_html_e('Enable teaser', 'presspermit-pro');
                echo '</label><br />';

                $css_display = ($do_teaser[$source_name]) ? 'block' : 'none';

                $style = "style='margin-left: 1em;'";
                echo "<div id='teaser_usage-" . esc_attr($source_name) . "' style='display:" . esc_attr($css_display) . ";'><table>";

                $use_teaser = array_intersect_key($use_teaser, array_fill_keys($pp->getEnabledPostTypes(), true));
                $use_teaser = $pp->admin()->orderTypes($use_teaser, ['item_type' => 'post']);

                // loop through each object type (for current source) to provide a use_teaser checkbox
                foreach ($use_teaser as $object_type => $teaser_setting) {
                    if ($type_obj = get_post_type_object($object_type)) {
                        $item_label_singular = $type_obj->labels->singular_name;
                    } else {
                        $item_label_singular = $object_type;
                    }

                    if (is_bool($teaser_setting) || is_numeric($teaser_setting))
                        $teaser_setting = intval($teaser_setting);

                    $id = $option_use_teaser . '-' . $object_type;
                    $name = "tease_post_types[$object_type]";

                    echo '<tr><td>';

                    echo "<label style='margin-left: 2em;'>";
                    printf(esc_html__("%s:", 'presspermit-pro'), esc_html($item_label_singular));
                    echo '</label>';

                    echo "</td><td><select name='" . esc_attr($name) . "' id='" . esc_attr($id) . "' autocomplete='off'>";
                    $num_chars = (defined('PP_TEASER_NUM_CHARS')) ? PP_TEASER_NUM_CHARS : 50;
                    $captions = apply_filters(
                        'presspermit_teaser_enable_options', 
                        [
                            0 => esc_html__("no teaser", 'presspermit-pro'), 
                            1 => esc_html__("fixed teaser (specified below)", 'presspermit-pro'), 
                            'excerpt' => esc_html__("excerpt as teaser", 'presspermit-pro'), 
                            'more' => esc_html__("excerpt or pre-more as teaser", 'presspermit-pro'), 
                            'x_chars' => sprintf(__("excerpt, pre-more or first %s chars", 'presspermit-pro'), (int) $num_chars)
                        ], 
                        $object_type, 
                        $teaser_setting
                    );

                    foreach ($captions as $teaser_option_val => $teaser_caption) {
                        $selected = ($teaser_setting === $teaser_option_val) ? ' selected ' : '';
                        echo "\n\t<option value='" . esc_attr($teaser_option_val) . "'" . esc_attr($selected) . ">" . esc_html($teaser_caption) . "</option>";
                    }
                    echo '</select>';
                    echo "<span style='display:none'>" . esc_html($object_type) . "</span>";
                    echo '</td></tr>';

                    // Checkbox option to skip teaser for anonymous users
                    $id = $option_logged_only . '-' . $object_type;
                    $name = "tease_logged_only[$object_type]";
                    $display = ($teaser_setting) ? '' : "display:none";
                    echo "<tr class='teaser_vspace' style='" . esc_attr($display) . "'><td></td><td><span>";

                    // 'teaser: anonymous, logged or both'
                    esc_html_e('for:', 'presspermit-pro');
                    echo "&nbsp;&nbsp;<label for='" . esc_attr($id) . "_logged'>";
                    $checked = (!empty($logged_only[$object_type]) && 'anon' == $logged_only[$object_type]) ? ' checked ' : '';
                    echo "<input name='" . esc_attr($name) . "' type='radio' id='" . esc_attr($id) . "_logged' value='anon'" . esc_attr($checked) . " />";
                    echo "";
                    esc_html_e("anonymous", 'presspermit-pro');
                    echo '</label></span>';

                    // Checkbox option to skip teaser for logged in users
                    echo "<span style='margin-left: 1em'><label for='" . esc_attr($id) . "_anon'>";
                    $checked = (!empty($logged_only[$object_type]) && 'anon' != $logged_only[$object_type]) ? ' checked ' : '';
                    echo "<input name='" . esc_attr($name) . "' type='radio' id='" . esc_attr($id) . "_anon' value='1'" . esc_attr($checked) . " />";
                    echo "";
                    esc_html_e("logged", 'presspermit-pro');
                    echo '</label></span>';

                    // Checkbox option to do teaser for BOTH logged and anon users
                    echo "<span style='margin-left: 1em'><label for='" . esc_attr($id) . "_all'>";
                    $checked = (empty($logged_only[$object_type])) ? ' checked ' : '';
                    echo "<input name='" . esc_attr($name) . "' type='radio' id='" . esc_attr($id) . "_all' value='0'" . esc_attr($checked) . " />";
                    echo "";
                    esc_html_e("both", 'presspermit-pro');
                    echo '</label></span>';

                    do_action('presspermit_teaser_type_row', $object_type, $teaser_setting);

                    echo '</td></tr>';
                }
                echo '</table><div>';

                if (empty($displayed_teaser_caption)) {
                    if ($ui->display_hints) {
                        ?>
                        <span class="pp-subtext pp-options-indent">
                        <?php
                        SettingsAdmin::echoStr('display_teaser');
                        ?>
                        </span><br />

                        <span class="pp-subtext pp-options-indent">
                        <?php
                        SettingsAdmin::echoStr('teaser_prefix_suffix_note');
                        ?>
                        </span>
                        <?php
                    }

                    $displayed_teaser_caption = true;
                }

                echo '</div></div>'; // teaser_usage-post

                // provide hide private (instead of teasing) checkboxes for each pertinent object type
                echo '<br />';

                $display_style = (array_diff($use_teaser, [0])) ? '' : "display:none;";
                echo "<div id='teaser-pvt-" . esc_attr($source_name) . "' style='" . esc_attr($display_style) . "'>";

                $type_obj = get_post_type_object('post');
                $type_caption = $type_obj->labels->name;

                echo '<span>';
                _e("Tease on Direct Access Only", 'presspermit-pro');
                echo '</span><br />';

                $direct_only = array_intersect_key($direct_only, array_fill_keys($pp->getEnabledPostTypes(), true));
                $direct_only = $pp->admin()->orderTypes($direct_only, ['item_type' => 'post']);

                echo '<div style="margin-left:2em">';
                foreach ($direct_only as $object_type => $teaser_setting) {
                    $id = $option_direct_only . '-' . $object_type;
                    $name = "tease_direct_access_only[$object_type]";

                    if ($type_obj = get_post_type_object($object_type))
                        $item_label = $type_obj->labels->name;
                    else
                        $item_label = $object_type;

                    $display = (!empty($use_teaser[$object_type])) ? '' : "display:none";
                    $teaser_direct_only_types = apply_filters('presspermit_teaser_direct_only_types', []);
                    if (!empty($teaser_direct_only_types[$object_type]))
                        $checked = ' checked disabled ';
                    else
                        $checked = ($teaser_setting) ? ' checked ' : '';

                    echo "<input name='" . esc_attr($name) . "' type='hidden' value='0' /> ";
                    echo "<div style='" . esc_attr($display) . "'><label for='" . esc_attr($id) . "'>";
                    echo "<input name='" . esc_attr($name) . "' type='checkbox' id='" . esc_attr($id) . "' value='1'" . esc_attr($checked) . " /> ";

                    echo esc_html($item_label);
                    echo '</label></div>';
                }

                ?>
                </div>

                <span class="pp-subtext pp-options-indent">
                <?php
                if ($ui->display_hints) {
                    SettingsAdmin::echoStr('tease_direct_access_only');
                }
                ?>
                </span><br /><br />

                <span>
                <?php _e("Hide Private Posts (instead of teasing)", 'presspermit-pro') ?>
                </span><br />

                <?php
                $hide_private = array_intersect_key($hide_private, array_fill_keys($pp->getEnabledPostTypes(), true));
                $hide_private = $pp->admin()->orderTypes($hide_private, ['item_type' => 'post']);

                echo '<div style="margin-left: 2em">';
                foreach ($hide_private as $object_type => $teaser_setting) {
                    $id = $option_hide_private . '-' . $object_type;
                    $name = "tease_public_posts_only[$object_type]";

                    if ($type_obj = get_post_type_object($object_type))
                        $item_label = $type_obj->labels->name;
                    else
                        $item_label = $object_type;

                    $display = (!empty($use_teaser[$object_type])) ? '' : "display:none";
                    $teaser_hide_private_types = apply_filters('presspermit_teaser_hide_private_types', []);
                    if (!empty($teaser_hide_private_types[$object_type]))
                        $checked = ' checked disabled';
                    else
                        $checked = ($teaser_setting) ? ' checked ' : '';

                    echo "<input name='" . esc_attr($name) . "' type='hidden' value='0' /> ";
                    echo "<div style='" . esc_attr($display) . "'><label for='" . esc_attr($id) . "'>";
                    echo "<input name='" . esc_attr($name) . "' type='checkbox' id='" . esc_attr($id) . "' value='1'" . esc_attr($checked) . " /> ";

                    echo esc_html($item_label);
                    echo '</label></div>';
                }
                ?>
                </div>

                <span class="pp-subtext pp-options-indent">
                <?php
                if ($ui->display_hints) {
                    SettingsAdmin::echoStr('hide_unreadable_private_posts');
                }
                ?>
                </span>

                <?php
                echo '<br /><div style="margin-top:1em">';
                $ui->optionCheckbox('teaser_hide_custom_private_only', $tab, $section, '', '');
                echo '</div>';

                echo '</div>'; // teaser-pvt-post


                echo '<br /><div><span>';
                esc_html_e("Redirect Page", 'presspermit-pro');
                ?>
                </span><br/>

                <?php
                $id = "teaser_redirect_anon_slug";
                $ui->all_options[] = $id;
                $_setting = $pp->getOption($id);
                ?>
                <table class="pp-teaser-redirect-table pp-form-table pp-options-table" style="margin-left:2em">
                    <tr>
                        <td>
                            <label for='<?php echo esc_attr($id); ?>'>
                                <?php esc_html_e('Page slug (anonymous users):', 'presspermit-pro');
                                ?>
                        </td>
                        <td>
                            <?php
                            echo "<input name='" . esc_attr($id) . "' type='text' id='" . esc_attr($id) . "' placeholder='" . esc_html__('enter page slug or [login]', 'presspermit-pro') . "' value='" . esc_attr($_setting) . "' /> ";
                            ?>
                            </label>
                        </td>
                    </tr>

                    <?php
                    $id = "teaser_redirect_slug";
                    $ui->all_options[] = $id;
                    $_setting = $pp->getOption($id);
                    ?>
                    <tr>
                        <td>
                            <label for='<?php echo esc_attr($id); ?>'>
                                <?php esc_html_e('Page slug (logged in users):', 'presspermit-pro');
                                ?>
                        </td>
                        <td>
                            <?php
                            echo "<input name='" . esc_attr($id) . "' type='text' id='" . esc_attr($id) . "' placeholder='" . esc_html__('enter page slug or [login]', 'presspermit-pro') . "' value='" . esc_attr($_setting) . "' /> ";
                            ?>
                            </label>
                        </td>
                    </tr>
                </table>

                </div><div style="margin-bottom:15px"><span class="pp-subtext pp-options-indent">
                <?php
                if ($ui->display_hints) {
                    SettingsAdmin::echoStr('teaser_redirect_page');
                }
                ?>
                </span></div>

                <?php
                echo '<br /><div><span>';
                esc_html_e("Hide Unreadable Links (instead of teasing)", 'presspermit-pro'); // back compat for existing translations
                ?>
                </span><br/>
                <table id="pptx-options-teaser-links" class="pp-form-table pp-options-table" style="margin-left:2em">
                    <tbody>

                    <?php
                    $id = "teaser_hide_links_type";
                    $ui->all_options[] = $id;
                    $_setting = $pp->getOption($id);
                    ?>
                    <tr class="teaser_vspace">
                        <td style="vertical-align:top">
                            <div>
                                <label for='<?php echo esc_attr($id); ?>'>
                                    <?php esc_html_e('Post Types:', 'presspermit-pro');
                                    ?>
                        </td>
                        <td>
                            <?php
                            echo "<input name='" . esc_attr($id) . "' type='text' id='" . esc_attr($id) . "' value='" . esc_attr($_setting) . "' style='width:550px' /> ";
                            ?>

                            </div><div style="margin-bottom:15px"><span class="pp-subtext pp-options-in-dent">
                            <?php
                            if ($ui->display_hints) {
                                SettingsAdmin::echoStr('teaser_hide_nav_menu_types');
                            }
                            ?>
                            </span></div>
                        </td>
                    </tr>

                    <?php
                    $id = "teaser_hide_links_taxonomy";
                    $ui->all_options[] = $id;
                    $_setting = $pp->getOption($id);
                    ?>
                    <tr class="teaser_vspace">
                        <td style="vertical-align:top">
                            <label for='<?php echo esc_attr($id); ?>'><span style="width:300px">
                            <?php esc_html_e('Taxonomy:', 'presspermit-pro');

                            $_args = (defined('PRESSPERMIT_FILTER_PRIVATE_TAXONOMIES')) ? [] : ['public' => true];
                            $taxonomies = get_taxonomies($_args, 'object');
                            $taxonomies = $pp->admin()->orderTypes($taxonomies);
                            ?>
                        </td>
                        <td>
                            <select name='<?php echo esc_attr($id); ?>' id='<?php echo esc_attr($id); ?>' autocomplete='off'>
                            <option value=''><?php esc_html_e('(none)', 'presspermit'); ?></option>
                            <?php
                            foreach ($taxonomies as $taxonomy => $tx) {
                                $selected = ($_setting === $taxonomy) ? ' selected ' : '';

                                if ($tx->labels->singular_name || $selected) {
                                	echo "\n\t<option value='" . esc_attr($taxonomy) . "' " . esc_attr($selected) . ">" . esc_html($tx->labels->singular_name) . "</option>";
                                }
                            }
                            ?>
                            </label></select>
                        </td>
                    </tr>

                    <?php
                    $id = "teaser_hide_links_term";
                    $ui->all_options[] = $id;
                    $_setting = $pp->getOption($id);
                    ?>
                    <tr class="teaser_vspace">
                        <td style="vertical-align:top;padding-top:10px">
                            <div>
                                <label for='<?php echo esc_attr($id); ?>'>
                                    <?php esc_html_e('Term IDs:', 'presspermit-pro');
                                    ?>
                        </td>
                        <td>
                            <?php
                            echo "<input name='" . esc_attr($id) . "' type='text' id='" . esc_attr($id) . "' value='" . esc_attr($_setting) . "' style='margin-top:10px;width:600px' /> ";
                            ?>

                            </div><div><span class="pp-subtext pp-options-in-dent">
                            <?php
                            if ($ui->display_hints) {
                                SettingsAdmin::echoStr('teaser_hide_nav_menu_terms');
                            }
                            ?>
                            </span></div>

                        </td>
                    </tr>

                    </tbody>
                </table>

                <?php

                echo '</div>';
                ?>
                </div>
                <?php
                // now draw the teaser replacement / prefix / suffix input boxes
                $user_suffixes = ['_anon', ''];
                $item_actions = [
                    'name' => ['prepend', 'append'],
                    'content' => ['replace', 'prepend', 'append'],
                    'excerpt' => ['replace', 'prepend', 'append']
                ];

                $items_display = ['name' => esc_html__('name', 'presspermit-pro'), 'content' => esc_html__('content', 'presspermit-pro'), 'excerpt' => esc_html__('excerpt', 'presspermit-pro')];
                $actions_display = ['replace' => esc_html__('replace with:', 'presspermit-pro'), 'prepend' => esc_html__('prefix with:', 'presspermit-pro'), 'append' => esc_html__('suffix with:', 'presspermit-pro')];

                // first determine all object types
                foreach ($user_suffixes as $anon) {
                    foreach ($item_actions as $item => $actions) {
                        foreach ($actions as $action) {
                            $ui->all_options[] = "tease_{$action}_{$item}{$anon}";
                        }
                    }
                }

                $types = [''];

                $css_display = ($do_teaser[$source_name]) ? 'block' : 'none';
                echo "<div id='teaserdef-" . esc_attr($source_name) . "' style='display:" . esc_attr($css_display) . "; margin-top: 2em;'>";

                // separate input boxes to specify teasers for anon users and unpermitted logged in users
                foreach ($user_suffixes as $anon) {
                    $user_descript = ($anon) ? __('anonymous users', 'presspermit-pro') : __('logged in users', 'presspermit-pro');

                    echo '<strong>';
                    printf(esc_html__('Teaser Text (%s):', 'presspermit-pro'), esc_html($user_descript));
                    echo '</strong>';
                    echo '<ul class="pp-textentries">';

                    // items are name, content, excerpt
                    foreach ($item_actions as $item => $actions) {
                        echo '<li>' . esc_html($items_display[$item]) . ':';
                        echo '<table><tbody>';

                        // actions are prepend / append / replace
                        foreach ($actions as $action) {
                            $option_name = "tease_{$action}_{$item}{$anon}";
                            if (!$opt_val = $pp->getOption($option_name))
                                $opt_val = '';

                            $ui->all_options[] = $option_name;

                            $id = $option_name;
                            $name = $option_name;

                            echo "<tr><td class='td-label'><label for='" . esc_attr($id) . "'>";
                            echo esc_html($actions_display[$action]);
                            echo '</label>';

                            if (('content' == $item) && ('replace' == $action)) {
                                echo '<br /><div class="pp-gray pp-add-login-form" style="padding-left: 15px;"><a href="#">[login_form]</a></div>';
                            }
                            ?>
                            </td>
                            <td>
                                <?php if ('content' == $item) : ?>
                                    <textarea style="width:100%" name="<?php echo esc_attr($name); ?>"
                                              id="<?php echo esc_attr($id); ?>"><?php echo esc_html($opt_val); ?></textarea>
                                <?php else : ?>
                                    <input name="<?php echo esc_attr($name); ?>" type="text" id="<?php echo esc_attr($id); ?>"
                                           value="<?php echo esc_attr($opt_val); ?>"/>
                                <?php endif; ?>

                            </td>
                            </tr>
                            <?php
                        } // end foreach actions

                        echo '</tbody></table></li>';
                    } // end foreach item_actions

                    echo "</ul><br />";
                } // end foreach user_suffixes
                ?>

                <strong><?php esc_html_e('Type-Specific Teaser Text', 'presspermit-pro'); ?></strong>

                <ul class="pp-textentries">
                    <li>
                        <div class="pp_teaser_filter_notes" style="padding:10px">
                            <?php
                            _e("<strong>Copy</strong> the following code into your theme's <strong>functions.php</strong> file (or some other file which is always executed and not auto-updated). You will need to adjust the 'my_custom_type' identifier and text as desired:", 'presspermit-pro');
                            ?>
                            <textarea rows='20' cols='150' readonly='readonly' style="margin-top:5px">
                        add_filter( 'presspermit_teaser_text', 'my_custom_teaser_text', 10, 5 );

                        /*
                         * adjustment_type: replace, prefix or suffix
                         * post_part: content, excerpt or name
                        */
                        function my_custom_teaser_text( $text, $adjustment_type, $post_part, $post_type, $is_anonymous ) {
                            switch ( $post_type ) {
                                case 'page':
                                    if ( ( 'content' == $post_part ) && ( 'replace' == $adjustment_type ) ) {
                                        if ( $is_anonymous ) { // note: if you put a link or other html tags in the text, be sure to use single quotes
                                            $text = "Sorry, you don't have access to this page. Please log in or contact an administrator.";
                                        } else {
                                            $text = "Sorry, this page requires additional permissions. Please contact an administrator for help.";
                                        }
                                    }

                                    break;

                                case 'my_custom_type':
                                    if ( ( 'content' == $post_part ) && ( 'replace' == $adjustment_type ) ) {
                                        if ( $is_anonymous ) {  // note: if you put a link or other html tags in the text, be sure to use single quotes
                                            $text = "Sorry, you don't have access to this custom content. Please log in or contact an administrator.";
                                        } else {
                                            $text = "Sorry, this custom content requires additional permissions. Please contact an administrator for help.";
                                        }
                                    }

                                    break;
                            }

                            return $text;
                        }
                                            </textarea>
                        </div>
                    </li>
                </ul>


                <?php
                if (is_multisite()) : ?>
                    <br/>
                    <strong><?php esc_html_e('Teaser Settings for Networks', 'presspermit-pro'); ?></strong>

                    <ul class="pp-textentries">
                        <li>
                            <div class="pp_teaser_filter_notes" style="max-width:750px;padding:10px">
                                <?php
                                esc_html_e("To modify default settings network-wide, <strong>copy</strong> the following code into your theme's <strong>functions.php</strong> file (or some other file which is always executed and not auto-updated) and modify as desired:", 'presspermit');
                                ?>
                                <textarea rows='12' cols='150' readonly='readonly' style="margin-top:5px">
                                add_filter( 'presspermit_default_options', 'my_presspermit_default_options', 99 );

                                /*
                                 * def_options[option_name] = option_value
                                */
                                function my_presspermit_default_options( $def_options ) {
                                    // option name (array key) corresponds to name attributes of checkboxes, dropdowns and input boxes.  Modify as desired.

                                    return $def_options;
                                }
                                                    </textarea>
                            </div>

                            <div class="pp_teaser_filter_notes" style="max-width:750px;padding:10px">
                                <?php
                                esc_html_e("To force the value of a specific setting network-wide, <strong>copy</strong> the following code into your theme's <strong>functions.php</strong> file (or some other file which is always executed and not auto-updated) and modify as desired:", 'presspermit');
                                ?>
                                <textarea rows='12' cols='150' readonly='readonly' style="margin-top:5px">
                                add_filter( 'presspermit_default_options', 'my_presspermit_default_options', 99 );

                                /*
                                 * def_options[option_name] = option_value
                                */
                                function my_presspermit_default_options( $def_options ) {
                                    // option name (array key) corresponds to name attributes of checkboxes, dropdowns and input boxes.  Modify as desired.

                                    return $def_options;
                                }
                                                    </textarea>
                            </div>

                        </li>
                    </ul>
                <?php endif; ?>

                <?php

                echo '</div>';
            } // end foreach data source
            ?>
            </td>
            </tr>
        <?php
        endif; // any options accessable in this section

    } // end function optionsUI
}

?>

<script type="text/javascript">
    /* <![CDATA[ */
    jQuery(document).ready(function ($) {
        $('#post_teaser_enabled').on('change', function()
        {
            if ($(this).is(':checked')) {
                $('#teaser_usage-post').show();
                $('#teaser-pvt-post').show();
                $('#teaserdef-post').show();
            } else {
                $('#teaser_usage-post').hide();
                $('#teaser-pvt-post').hide();
                $('#teaserdef-post').hide();
            }
        });

        $('#teaser_usage-post select[name!="topics_teaser"]').on('change', function()
        {
            var otype = $(this).next().html();

            if ($(this).val() != '0') {
                $(this).closest('tr').next('tr').show();
                $('#teaser-pvt-post').show();
                $('#tease_public_posts_only-' + otype).closest('div').show();
            } else {
                $(this).closest('tr').next('tr').hide();
                $('#tease_public_posts_only-' + otype).closest('div').hide();
            }

            if ($('#teaser-pvt-post input:visible').length)
                $('#teaser-pvt-post').show();
            else
                $('#teaser-pvt-post').hide();
        });

        $('div.pp-add-login-form a').on('click', function()
        {
            var e;
            if (e = $(this).closest('td').next().find('textarea')) {
                if (-1 == e.val().indexOf('[login_form]')) {
                    e.val(e.val() + '[login_form]');
                }
            }
            return false;
        });
    });
    /* ]]> */
</script>
