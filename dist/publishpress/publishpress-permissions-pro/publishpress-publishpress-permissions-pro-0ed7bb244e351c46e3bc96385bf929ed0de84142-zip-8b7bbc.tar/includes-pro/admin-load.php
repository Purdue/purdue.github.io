<?php
namespace PublishPress\Permissions;

class AdminLoadPro {
    function __construct() {
        add_filter('presspermit_default_options', [$this, 'defaultOptions']);
        add_filter('presspermit_netwide_options', [$this, 'netwideOptions']);
        add_filter('presspermit_option_captions', [$this, 'optionCaptions'], 20);
        add_filter('presspermit_option_sections', [$this, 'optionSections'], 20);

        add_action('presspermit_load_modules', [$this, 'loadModules']);
    }

    public function defaultOptions($options) {
        $options['display_branding'] = 1;
        return $options;
    }

    public function netwideOptions($netwide) {
        $netwide []= 'display_branding';
        return $netwide;
    }
 
    public function optionCaptions($captions)
    {
        $opt = [
            'display_branding' => __('Display PublishPress Branding in Admin', 'presspermit-pro'),
        ];

        return array_merge($captions, $opt);
    }

    public function optionSections($sections)
    {
        $new = [
            'admin' => ['display_branding'],
        ];

        $key = 'core';

        if (isset($sections[$key]['admin'])) {
            $sections[$key]['admin'] = array_merge($sections[$key]['admin'], $new['admin']);
        } else {
            $sections[$key] = (isset($sections[$key])) ? array_merge($sections[$key], $new) : $new;
        }

        return $sections;
    }


    public function loadModules($args)
    {
        $defaults = ['available_modules' => [], 'inactive_modules' => []];
        foreach(array_keys($defaults) as $var) {
            $$var = $args[$var];
        }

        $dir = PRESSPERMIT_PRO_ABSPATH . '/modules/';

        foreach($available_modules as $module) {
            if (empty($inactive_modules[$module]) && file_exists("$dir/$module/$module.php")) {
                include_once("$dir/$module/$module.php");
            }
        }
    }

}
