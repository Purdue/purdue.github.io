<?php
namespace PublishPress\StatusCapabilities;

class StatusSave
{
    public static function save($status, $new = false)
    {
        check_admin_referer('edit-status');
        
        if (isset($_REQUEST['status_capability_status'])) {
            if (!$capability_status = get_option('presspermit_status_capability_status')) {
                $capability_status = [];
            }

            $status_capability_status = sanitize_key($_REQUEST['status_capability_status']);

            if (!$status_capability_status) {
                $status = sanitize_key($status);
                delete_option("presspermit_custom_{$status}_caps");
            }

            $capability_status[$status] = $status_capability_status;

            update_option("presspermit_status_capability_status", $capability_status);
            update_option("presspermit_custom_{$status}_caps", true);  // @todo: eliminate
        }

        // previous versions of PublishPress Statuses handled this status_caps submission directly
        if (defined('PUBLISHPRESS_STATUSES_VERSION') && version_compare(PUBLISHPRESS_STATUSES_VERSION, '1.0.1', '>')) {
            if (isset($_REQUEST['status_caps'])) {
                // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
                foreach ($_REQUEST['status_caps'] as $role_name => $set_status_caps) { // array elements sanitized below
                    $role_name = sanitize_key($role_name);
                    $set_status_caps = array_map('boolval', $set_status_caps);

                    if (!\PublishPress_Functions::isEditableRole($role_name)) {
                        continue;
                    }

                    $role = get_role($role_name);

                    if ($add_caps = array_diff_key(
                        array_filter($set_status_caps),
                        array_filter($role->capabilities)
                    )) {
                        foreach (array_keys($add_caps) as $cap_name) {
                            $cap_name = sanitize_key($cap_name);
                            $role->add_cap($cap_name);
                        }
                    }

                    $set_false_status_caps = array_diff_key($set_status_caps, array_filter($set_status_caps));

                    foreach(array_keys($set_false_status_caps) as $cap_name) {
                        $cap_name = sanitize_key($cap_name);

                        if (!empty($role->capabilities[$cap_name])) {
                            $role->remove_cap($cap_name);
                        }
                    }
                }
            }
        }
    }
}
