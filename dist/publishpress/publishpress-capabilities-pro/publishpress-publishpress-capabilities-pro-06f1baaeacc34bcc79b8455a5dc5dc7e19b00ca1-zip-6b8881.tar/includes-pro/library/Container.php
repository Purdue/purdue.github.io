<?php
/**
 * @package     PublishPress\Capabilities\
 * @author      PublishPress <help@publishpress.com>
 * @copyright   Copyright (C) 2018 PublishPress. All rights reserved.
 * @license     GPLv2 or later
 * @since       1.0.3
 */

namespace PublishPress\Capabilities;

defined('ABSPATH') or die('No direct script access allowed.');

/**
 * Class Container
 */
class Container extends \PublishPress\Pimple\Container
{

}
