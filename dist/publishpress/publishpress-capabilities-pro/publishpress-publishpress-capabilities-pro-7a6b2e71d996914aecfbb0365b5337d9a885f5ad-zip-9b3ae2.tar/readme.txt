=== PublishPress Capabilities Pro : Manage WordPress Permissions and Edit User Roles ===
Contributors: publishpress, kevinB, stevejburge, andergmartins, olatechpro
Author: PublishPress
Author URI: https://publishpress.com
Tags: user roles, capabilities, permissions, authors, editors, post types, taxonomies
Requires at least: 5.5
Requires PHP: 7.2.5
Tested up to: 7.0
Stable tag: 2.45.0
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

PublishPress Capabilities is the best plugin to customize your permissions and user roles. You can control who has access to your WordPress site.

== Description ==

[PublishPress Capabilities](https://publishpress.com/capabilities/) gives you control over all the permissions on your WordPress site. You can customize all the user roles on your site, from Administrators and Editors to Authors, Contributors, Subscribers and custom roles. Each role can have the exact permissions that your site needs.

PublishPress Capabilities allows you to modify existing roles, but you can also create new roles. These roles can be added to single sites or to an entire multisite network.

PublishPress Capabilities is safe to use. Every time you change your site's permissions, PublishPress Capabilities will take a backup that you can restore if anything goes wrong. You can use these backups to migrate your roles and permissions from one site to another.

= Control User Permissions =

PublishPress Capabilities gives you detailed control over all the permissions on your WordPress site. You can customize all the user roles on your site, from Administrator to Subscriber.

With Capabilities, you can choose who can Publish, Read, Edit and Delete content. You can choose permissions for posts, pages, custom content types, categories, tags, and more.
[Click here for your quick start guide to PublishPress Capabilities](https://publishpress.com/knowledge-base/permissions-start/).

= Capabilities for any Post Type =

Many WordPress users have sites with custom post types. This can be done using custom code, a theme, or with a plugin. No matter how your post type is created, PublishPress Capabilities lets you enforce and assign distinct capabilities for your post type.
[Click here to see how to control post type permissions](https://publishpress.com/knowledge-base/custom-post-types-capability/).

= Permissions for Custom Statuses =

This option will appear if you have the [PublishPress](https://publishpress.com/publishpress) plugin installed to create and configure custom statuses. With Capabilities Pro, you can decide which user roles are able to send posts to each status.  For status-specific editing control, also activate [PublishPress Permissions Pro](https://publishpress.com/presspermit) and its Status Control module.
[Click here to see how to manage permissions for statuses](https://publishpress.com/knowledge-base/permissions-for-custom-statuses/).

= Capabilities for any Taxonomy =

The PublishPress Capabilities plugin allows you to add extra permissions to the taxonomies on your site. This feature includes the default Categories and Tags, but also applies to other taxonomies. For example, in WooCommerce you can apply custom permissions to Product categories, Product tags, and Product shipping classes. You can enforce and assign "Manage", "Edit" and "Assign" distinct capabilities for all your taxonomies.
[Click here to learn about taxonomy permissions](https://publishpress.com/knowledge-base/taxonomy-specific-capabilities/).

= Backup and Restore Roles and Capabilities =

PublishPress Capabilities offers you the ability to back up and restore your permissions. This feature is very helpful if you want to test out changes on your site, or if you've installed a new plugin that has changed your site's permissions.

Every time you change your permissions, the PublishPress Capabilities plugin will now automatically create a backup. If you make a mistake, go to the "Backup" menu link and you'll be able to roll back to a previous version.
[Click here to see how to backup permissions](https://publishpress.com/knowledge-base/backup-restore-permissions/).

= Create or Copy User Roles =

With PublishPress Capabilities you can create or copy any existing WordPress user role. These roles can be customized in exactly the same way as the default WordPress roles. These new roles can be added to single sites or to an entire multisite network.
[Click here to see how to create or copy user roles](https://publishpress.com/knowledge-base/create-or-copy-user-roles/).

= Support for Media Library Permissions =

PublishPress Capabilities enables you to decide who can upload, edit and delete files from your site's Media Library. By default, only Administrators are able to delete files in your Media Library. Subscribers and Contributors are not even allowed to upload files. You can customize these permissions for the Media Library and also the Featured Image box.
[Click here to learn about Media Library permissions](https://publishpress.com/knowledge-base/control-media-library-access/).

= Support for WooCommerce Permissions =

We mentioned earlier that PublishPress Capabilities has special support for WooCommerce taxonomies. This is true for the rest of WooCommerce also. With PublishPress Capabilities you can control permissions for WooCommerce products, orders and coupons.
[Click here to learn about WooCommerce permissions](https://publishpress.com/knowledge-base/woocommerce-permissons/).

= WordPress Multisite support =

PublishPress Capabilities allows you to control permissions on a single site or across your whole network. Every time you update permissions in PublishPress Capabilities, you can choose to sync those changes across your multisite network.
[Click here to learn about multisite permissions](https://publishpress.com/knowledge-base/multisite-network/).

= Join PublishPress and get the Pro plugins =

The Pro versions of the PublishPress plugins are well worth your investment. The Pro versions have extra features and faster support. [Click here to join PublishPress](https://publishpress.com/pricing/).

Join PublishPress and you'll get access to these 6 Pro plugins:

* [PublishPress Authors Pro](https://publishpress.com/authors) allows you to add multiple authors and guest authors to WordPress posts.
* [PublishPress Blocks Pro](https://publishpress.com/blocks) has everything you need to build professional websites with the WordPress block editor.
* [PublishPress Capabilities Pro](https://publishpress.com/capabilities) is the plugin to manage your WordPress user roles, permissions, and capabilities.
* [PublishPress Checklists Pro](https://publishpress.com/checklists) enables you to define tasks that must be completed before content is published.
* [PublishPress Permissions Pro](https://publishpress.com/permissions)  is the plugin for advanced WordPress permissions.
* [PublishPress Pro](https://publishpress.com/publishpress) is the plugin for managing and scheduling WordPress content.
* [PublishPress Revisions Pro](https://publishpress.com/revisions) allows you to update your published pages with teamwork and precision.

Together, these plugins are a suite of powerful publishing tools for WordPress. If you need to create a professional workflow in WordPress, with moderation, revisions, permissions and more... then you should try PublishPress.

=  Bug Reports =

Bug reports for PublishPress Capabilities are welcomed in our [repository on GitHub](https://github.com/publishpress/publishpress-capabilities). Please note that GitHub is not a support forum, and that issues that aren't properly qualified as bugs will be closed.

= Follow the PublishPress team =

Follow PublishPress on [Facebook](https://www.facebook.com/publishpress), [Twitter](https://www.twitter.com/publishpresscom) and [YouTube](https://www.youtube.com/publishpress).

== Screenshots ==

1. Control user permissions
2. Create and copy user roles
3. Content permissions
4. Permissions for Custom Statuses
5. Enforce Type-Specific Capabilities
6. Enforce Taxonomy-Specific Capabilities
7. Detailed Taxonomy Capabilities
8. Automatic or Manual Capabilities Backup, Restore
9. Control WooCommerce Capabilities
10. PublishPress Permission integration (showing capabilities from supplemental roles)
11. Multisite support

== Upgrade Notice ==

= 1.5.1 =
Fixed : Non-administrators with user editing capabilities could add new Administrators

= 2.3.1 =
Fixed : Security issue. Please update.

== Changelog ==

The full changelog can be found on [GitHub](https://github.com/publishpress/publishpress-capabilities-pro/blob/master/CHANGELOG.md).
