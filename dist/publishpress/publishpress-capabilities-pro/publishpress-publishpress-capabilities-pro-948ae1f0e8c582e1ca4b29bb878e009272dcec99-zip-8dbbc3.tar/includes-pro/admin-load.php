<?php
namespace PublishPress\Capabilities;

/*
 * PublishPress Capabilities Pro
 * 
 * Admin execution controller: menu registration and other filters and actions that need to be loaded for every wp-admin URL
 * 
 * This module should not include full functions related to our own plugin screens.  
 * Instead, use these filter and action handlers to load other classes when needed.
 * 
 */
class AdminFiltersPro {
    function __construct() {
        add_action('init', [$this, 'versionInfoRedirect'], 1);
        add_action('admin_init', [$this, 'loadUpdater']);

        add_action('admin_enqueue_scripts', [$this, 'adminScripts']);

        // Editor Features: Custom Items
        add_action('admin_init', [$this, 'initPostFeatureCustom']);

        $this->initPostFeatureCustom();

        // If custom statuses are not being defined by PublishPress Statuses or PublishPress Planner < 4.0, display guidance for Statuses install / activation 
        if (!defined('PUBLISHPRESS_STATUSES_VERSION')
        && (!defined('PUBLISHPRESS_VERSION') || !class_exists('PP_Custom_Status'))) {
            require_once(dirname(__FILE__).'/statuses-intro.php');
        }

        add_action('pp_capabilities_editor_features', [$this, 'editorFeaturesUI']);
        add_action('wp_ajax_ppc_submit_feature_gutenberg_by_ajax', [$this, 'ajaxFeaturesRestrictCustomItem']);
        add_action('wp_ajax_ppc_submit_feature_classic_by_ajax', [$this, 'ajaxFeaturesRestrictCustomItem']);
        add_action('wp_ajax_ppc_delete_custom_post_features_by_ajax', [$this, 'ajaxFeaturesClearCustomItem']);
        add_action('wp_ajax_ppc_update_admin_menu_order_by_ajax', [$this, 'ajaxUpdateAdminMenuOrder']); 
        add_action('wp_ajax_ppc_update_admin_menu_title', [$this, 'ajaxUpdateAdminMenuTitle']);
        add_action('wp_ajax_ppc_add_new_admin_menu', [$this, 'ajaxAddNewAdminMenu']);
        add_action('wp_ajax_ppc_delete_admin_menu', [$this, 'ajaxDeleteAdminMenu']);

        // Editor Features: Metaboxes
        add_action('admin_head', [$this, 'initPostFeatureMetaboxes'], 999);

        add_action('publishpress-caps_manager-load', [$this, 'CapsManagerLoad']);
        add_action('admin_print_styles', array($this, 'adminStyles'));

        add_action('admin_init', [$this, 'settingsUI']);
        add_filter('pp_capabilities_settings_options', [$this, 'settingsOption']);

        add_action('publishpress-caps_manager-load', [$this, 'loadStatusesUI']);

        if (!empty($_POST['page']) && ('pp-capabilities-settings' == $_POST['page'])) {
            add_action('init', [$this, 'updateOptions'], 5);
        }

        add_filter('pp_capabilities_sub_menu_lists', [$this, 'actCapabilitiesSubmenus'], 10, 2);

        add_filter('pp_capabilities_dashboard_features', [$this, 'addProFeaturestoDashboard']);

        // Admin Menu Add, Rename and Re-order
        add_filter('submenu_file', [$this, 'customizeAdminMenu'], PHP_INT_MAX - 1);

        //set admin menu and sub menu in 'adminmenu' to support custom menu and also get menu correct order
        add_action('adminmenu', [$this, 'setCapabilitiesAdminMenu'], PHP_INT_MAX - 1);
        //translation
        add_action('init', [$this, 'register_textdomain']);

        //Frontend features pages field
        add_action('pp_capabilities_frontend_features_pages', [$this, 'frontendFeaturesPagesField']);

        //Frontend features post types field
        add_action('pp_capabilities_frontend_features_metabox_post_types', [$this, 'frontendFeaturesPostTypesField']);

        add_action('publishpress-caps_manager_postcaps_table', [$this, 'actPostCapsNote'], 10, 3);

        add_action('admin_menu', [$this, 'addCustomMenu'], PHP_INT_MAX - 100);
    }

    public function actPostCapsNote($cap_type, $item_type, $args) {
        if (!defined('PUBLISHPRESS_STATUSES_VERSION') || (!in_array($cap_type, ['edit', 'delete'])) || ('type' != $item_type)) {
            return;
        }

        if (Pro::presspermitStatusControlActive()) {
            return;
        }
        
        $url = admin_url('admin.php?page=pp-capabilities-settings&pp_tab=capabilities');

        if (!get_option('cme_custom_status_control')) : 
        ?>
        <p class="cme-status-footer cme-custom-status-hints">
            <?php
            printf(
                esc_html__('Note: Control of custom post statuses is %1$sdisabled%2$s.', 'capabilities-pro'),
                '<a href="' . esc_url($url) . '">',
                '</a>'
            );
            ?>
        </p>
        <?php elseif (!Pro::customStatusPostMetaPermissions()) : ?>
        <p class="cme-status-footer cme-custom-status-hints">
            <?php
            printf(
                esc_html__('Note: Status-specific post editing capabilities are %1$sdisabled%2$s.', 'capabilities-pro'),
                '<a href="' . esc_url($url) . '">',
                '</a>'
            );
            ?>
        </p>

        <?php endif;
    }

	public function register_textdomain() {
        //load pro domain
        $domain       = 'capabilities-pro';
        $mofile_custom = sprintf('%s-%s.mo', $domain, get_user_locale());
        $locations = [
        trailingslashit(WP_LANG_DIR . '/' . $domain),
        trailingslashit(WP_LANG_DIR . '/loco/plugins/'),
        trailingslashit(WP_LANG_DIR),
        trailingslashit(plugin_dir_path(CME_FILE) . 'languages'),
            ];

        // Try custom locations in WP_LANG_DIR.
        foreach ($locations as $location) {
            if (load_textdomain($domain, $location . $mofile_custom)) {
                break;
            }
        }

        //load free domain
        $domain       = 'capsman-enhanced';
        $mofile_custom = sprintf('%s-%s.mo', $domain, get_user_locale());
        $locations = [
        trailingslashit(WP_LANG_DIR . '/' . $domain),
        trailingslashit(WP_LANG_DIR . '/loco/plugins/'),
        trailingslashit(WP_LANG_DIR),
        trailingslashit(plugin_dir_path(CME_FILE) . 'languages'),
            ];

        // Try custom locations in WP_LANG_DIR.
        foreach ($locations as $location) {
            if (load_textdomain($domain, $location . $mofile_custom)) {
                break;
            }
        }
}

    public function adminScripts() {
        global $capsman;

        $url = plugins_url( '', CME_FILE );

        wp_register_style('pp_capabilities_pro_admin', $url . '/includes-pro/common/css/admin.css', false, PUBLISHPRESS_CAPS_VERSION);
        wp_enqueue_style('pp_capabilities_pro_admin');

        $suffix = defined('SCRIPT_DEBUG') && SCRIPT_DEBUG ? '.dev' : '';
        $url .= "/includes-pro/common/js/admin{$suffix}.js";
        wp_enqueue_script( 'pp_capabilities_pro_admin', $url, array('jquery', 'jquery-ui-sortable'), PUBLISHPRESS_CAPS_VERSION, true );
        
        wp_localize_script('pp_capabilities_pro_admin', 'ppCapabilitiesPro', [
            'nonce' => wp_create_nonce('ppc-pro-feature-nonce'),
        ]);
    }

    public function settingsUI() {
        require_once(dirname(__FILE__).'/settings-ui.php');
        new Pro_Settings_UI();
    }

    public function settingsOption($settings_options) {

        $settings_options[] = 'cme_display_branding';
        $settings_options[] = 'cme_custom_status_control';
        $settings_options[] = 'cme_custom_status_postmeta_caps';
        $settings_options[] = 'cme_admin_menus_restriction_priority';
        $settings_options[] = 'presspermit_privacy_statuses_enabled';
        $settings_options[] = 'presspermit_custom_privacy_edit_caps';

        return $settings_options;
    }

    function actCapabilitiesSubmenus($sub_menu_pages, $cme_fakefunc) {

        if (!$cme_fakefunc) {
            //add admin menu after profile features menu
            $profile_features_offset = array_search('profile-features', array_keys($sub_menu_pages));
            $profile_features_menu   = [];
            $profile_features_menu['admin-menus'] = [
                'title'             => __('Admin Menus', 'capabilities-pro'),
                'capabilities'      => (is_multisite() && is_super_admin()) ? 'read' : 'manage_capabilities_admin_menus',
                'page'              => 'pp-capabilities-admin-menus',
                'callback'          => [$this, 'ManageAdminMenus'],
                'dashboard_control' => true,
            ];

            $sub_menu_pages = array_merge(
                array_slice($sub_menu_pages, 0, $profile_features_offset),
                $profile_features_menu,
                array_slice($sub_menu_pages, $profile_features_offset, null)
            );
        }

        return $sub_menu_pages;
    }

    function addProFeaturestoDashboard($features) {

            //add admin menu after profile features menu
            $profile_features_offset = array_search('profile-features', array_keys($features));
            $admin_menu_feature   = [];
            $admin_menu_feature['admin-menus'] = [
                'label'        => esc_html__('Admin Menus', 'capabilities-pro'),
                'description'  => esc_html__('Admin Menus allows you to edit the admin menu links and control who has access.', 'capabilities-pro'),
            ];

            $features = array_merge(
                array_slice($features, 0, $profile_features_offset),
                $admin_menu_feature,
                array_slice($features, $profile_features_offset, null)
            );

        return $features;
    }

    /**
	 * Manages admin menu permission
	 *
	 * @hook add_management_page
	 * @return void
	 */
	function ManageAdminMenus ()
	{
        global $capsman;

		if ((!is_multisite() || !is_super_admin()) && !current_user_can('administrator') && !current_user_can('manage_capabilities_admin_menus')) {
            // TODO: Implement exceptions.
		    wp_die('<strong>' . esc_html__('You do not have permission to manage menu restrictions.', 'capabilities-pro') . '</strong>');
		}

		$capsman->generateNames();
		$roles = array_keys($capsman->roles);

		if ( ! isset($capsman->current) ) {
			if ('POST' !== $_SERVER['REQUEST_METHOD'] && !empty($_REQUEST['role'])) {
                $capsman->set_current_role(sanitize_key($_REQUEST['role']));
			}
		}

		if (!isset($capsman->current) || !get_role($capsman->current)) {
			$capsman->current = $capsman->get_last_role();
		}

		if ( ! in_array($capsman->current, $roles) ) {
			$capsman->current = array_shift($roles);
		}

		$ppc_admin_menu_reload = '0';

		if (!empty($_SERVER['REQUEST_METHOD']) && ('POST' == $_SERVER['REQUEST_METHOD']) && isset($_POST['ppc-admin-menu-role']) && !empty($_REQUEST['_wpnonce'])) {
            if (!wp_verify_nonce(sanitize_key($_REQUEST['_wpnonce']), 'pp-capabilities-admin-menus')) {
                wp_die('<strong>' . esc_html__('You do not have permission to manage menu restrictions.', 'capabilities-pro') . '</strong>');
            } else {
                $menu_role = sanitize_key($_POST['ppc-admin-menu-role']);

                $capsman->set_current_role($menu_role);

                //set role admin menu
                $admin_menu_option = !empty(get_option('capsman_admin_menus')) ? get_option('capsman_admin_menus') : [];

                $admin_menu_option[$menu_role] = isset($_POST['pp_cababilities_disabled_menu']) ? array_map('sanitize_text_field', $_POST['pp_cababilities_disabled_menu']) : '';

                //set role admin child menu
                $admin_child_menu_option = !empty(get_option('capsman_admin_child_menus')) ? get_option('capsman_admin_child_menus') : [];
                $admin_child_menu_option[sanitize_key($_POST['ppc-admin-menu-role'])] = isset($_POST['pp_cababilities_disabled_child_menu']) ? array_map('sanitize_text_field', $_POST['pp_cababilities_disabled_child_menu']) : '';

                update_option('capsman_admin_menus', $admin_menu_option, false);
                update_option('capsman_admin_child_menus', $admin_child_menu_option, false);

                //set reload option for menu reflection if user is updating own role
                if(in_array($_POST['ppc-admin-menu-role'], wp_get_current_user()->roles)){
                	$ppc_admin_menu_reload = '1';
                }

                ak_admin_notify(__('Settings updated.', 'capabilities-pro'));
            }
		}

        $url = plugins_url( '', CME_FILE );

        // enqueue css
        wp_enqueue_style('pp-capabilities-pro-admin-menu-css', $url . '/includes-pro/features/admin-menus/assets/css/admin-menus.css', false, PUBLISHPRESS_CAPS_VERSION);
        // enqueue js
        wp_enqueue_script( 'pp-capabilities-pro-admin-menu-js', $url . '/includes-pro/features/admin-menus/assets/js/admin-menus.js', array('jquery', 'jquery-ui-sortable'), PUBLISHPRESS_CAPS_VERSION, true );

        // localize js
        $dashicons = json_decode(file_get_contents(plugin_dir_path(__FILE__) . 'features/admin-menus/assets/icons/dashicons-icons.json'));
        wp_localize_script('pp-capabilities-pro-admin-menu-js', 'ppCapabilitiesProAdminMenus', [
            'saving_menu_order' => __('Saving Menu Order...', 'capabilities-pro'),
            'saving_menu_title' => __('Saving Menu Name...', 'capabilities-pro'),
            'menu_title_empty' => __('Menu Name can not be empty.', 'capabilities-pro'),
            'changeIcon' => __('Change Icon', 'capabilities-pro'),
            'searchIcons' => __('Search icons...', 'capabilities-pro'),
            'iconUpdated' => __('Menu icon updated', 'capabilities-pro'),
            'iconUpdateError' => __('Error updating menu icon', 'capabilities-pro'),
            'duplicateMenuError' => __('Duplicate menu with the menu url already exist', 'capabilities-pro'),
            'duplicateSubMenuError' => __('Duplicate submenu with the menu url already exist', 'capabilities-pro'),
            'dashicons' => $dashicons,
            'nonce' => wp_create_nonce('ppc-pro-feature-nonce')
        ]);

		include ( dirname(__FILE__) . '/features/admin-menus/admin-menus.php' );
	}

    function versionInfoRedirect() {
        if (!empty($_REQUEST['publishpress_caps_refresh_updates']) && current_user_can('activate_plugins')) { // not a security issue, but prevent status refresh by CSRF
            check_admin_referer('publishpress_caps_refresh_updates');
            
            publishpress_caps_pro()->keyStatus(true);
            set_transient('publishpress-caps-refresh-update-info', true, 86400);

            delete_site_transient('update_plugins');
            delete_option('_site_transient_update_plugins');

            $opt_val = get_option('cme_edd_key');
            if (is_array($opt_val) && !empty($opt_val['license_key'])) {
                $plugin_slug = basename(CME_FILE, '.php'); // 'capabilities-pro';
                $plugin_relpath = basename(dirname(CME_FILE)) . '/' . basename(CME_FILE);
                $license_key = $opt_val['license_key'];
                $beta = false;

                delete_option(md5($plugin_slug . $license_key . $beta));
                delete_option('edd_api_request_' . md5($plugin_slug . $license_key . $beta));
                delete_option(md5('edd_plugin_' . sanitize_key($plugin_relpath) . '_' . $beta . '_version_info'));
            }

            wp_update_plugins();

            if (current_user_can('update_plugins')) {
                $url = admin_url('admin.php?page=pp-capabilities-settings&publishpress_caps_refresh_done=1');
                $url = wp_nonce_url($url, 'publishpress_caps_refresh_updates');
                wp_redirect(esc_url_raw($url));
                exit;
            }
        }

        if (!empty($_REQUEST['amp;publishpress_caps_refresh_done']) && !empty($_REQUEST['amp;_wpnonce'])) {
            $_REQUEST['publishpress_caps_refresh_done'] = (int) $_REQUEST['amp;publishpress_caps_refresh_done'];
            $_REQUEST['_wpnonce'] = sanitize_key($_REQUEST['amp;_wpnonce']);
        }

        if (!empty($_REQUEST['publishpress_caps_refresh_done']) && empty($_POST)) {
            check_admin_referer('publishpress_caps_refresh_updates');

            if (current_user_can('activate_plugins')) {
                $url = admin_url('update-core.php');
                wp_redirect(esc_url_raw($url));
                exit;
            }
        }
    }

    function CapsManagerLoad() {
        require_once(dirname(__FILE__).'/manager-ui.php');
        new ManagerUI();
    }

    function loadUpdater() {
        require_once(PUBLISHPRESS_CAPS_ABSPATH . '/includes-pro/library/Factory.php');
        $container = \PublishPress\Capabilities\Factory::get_container();
        return $container['edd_container']['update_manager'];
    }

    function adminStyles() {
        global $plugin_page;

        if (!empty($plugin_page) && (0 == strpos('pp-capabilities', $plugin_page))) {
            wp_enqueue_style('publishpress-caps-pro', plugins_url( '', CME_FILE ) . '/includes-pro/pro.css', [], PUBLISHPRESS_CAPS_VERSION);
            wp_enqueue_style('publishpress-caps-status-caps', plugins_url( '', CME_FILE ) . '/includes-pro/common/css/status-caps.css', [], PUBLISHPRESS_CAPS_VERSION);

            add_thickbox();
        }

        // enqueue global css
        wp_enqueue_style('pp-capabilities-pro-admin-menu-global-css', plugins_url( '', CME_FILE ) . '/includes-pro/features/admin-menus/assets/css/admin-menus-global.css', false, PUBLISHPRESS_CAPS_VERSION);
    }

    function loadStatusesUI() {
        if ((Pro::customStatusPermissionsAvailable() && (get_option('cme_custom_status_control') || Pro::presspermitStatusControlActive()))
        || defined('PUBLISHPRESS_REVISIONS_VERSION')
        ) {
            require_once(dirname(__FILE__).'/admin.php');
            new CustomStatusCapsUI();
        }

        if (Pro::customPrivacyStatusesAvailable() 
        && (defined('PUBLISHPRESS_STATUSES_VERSION') || (defined('PUBLISHPRESS_VERSION') && version_compare(PUBLISHPRESS_VERSION, '3.13', '<') && get_option('presspermit_legacy_status_control')))
        ) {
            require_once(dirname(__FILE__).'/admin-privacy.php');
            new CustomPrivacyCapsUI();
        }
    }

    function updateCapabilitiesOptions() {
        check_admin_referer('capsman-general-manager');
        
        update_option('cme_custom_status_control', (int) !empty($_REQUEST['cme_custom_status_control']));
        update_option('cme_custom_status_postmeta_caps', (int) !empty($_REQUEST['cme_custom_status_postmeta_caps']));

        if (isset($_REQUEST['presspermit_privacy_statuses_enabled'])) {
            update_option('presspermit_privacy_statuses_enabled', (int) !empty($_REQUEST['presspermit_privacy_statuses_enabled']));
        }

        if (isset($_REQUEST['presspermit_custom_privacy_edit_caps'])) {
            update_option('presspermit_custom_privacy_edit_caps', (int) !empty($_REQUEST['presspermit_custom_privacy_edit_caps']));
        }
    }

    function updateOptions() {
        $this->updateCapabilitiesOptions();

        update_option('cme_display_branding', (int) !empty($_REQUEST['cme_display_branding']));
    }

    function editorFeaturesUI() {
        require_once (dirname(__FILE__) . '/features/config/metaboxes-config.php');
        new EditorFeaturesMetaboxesConfig();

        require_once (dirname(__FILE__) . '/features/config/custom-config.php');
        EditorFeaturesCustomConfig::instance();

        ?>
        <script type="text/javascript">
            /* <![CDATA[ */
            jQuery(document).ready(function ($) {

                $('.editor-features-tab').click(function (e) {
                    e.preventDefault();

                    $('.editor-features-custom').hide();
                    var elem = $(this).attr('data-tab') + '-custom';
                    $(elem).show();
                });
            });
            /* ]]> */
        </script>
        <?php
    }

    /**
     * Capture metaboxes for post features
     *
     * @param array $post_types Post type.
     * @param array $elements All elements.
     * @param array $post_disabled All disabled post type element.
     *
     * @since 2.1.1
     */
    function initPostFeatureMetaboxes()
    {
        $screen = get_current_screen();

        if ($screen && !empty($screen->base) && ($screen->base == 'post')) {
            require_once (dirname(__FILE__) . '/features/config/metaboxes-config.php');
            $features_metaboxes = new EditorFeaturesMetaboxesConfig();
            $features_metaboxes->capturePostFeatureMetaboxes($screen->post_type);
        }
    }

    function initPostFeatureCustom() {
        require_once (dirname(__FILE__) . '/features/config/custom-config.php');
        EditorFeaturesCustomConfig::instance();
    }

    /**
     * Ajax callback to add restriction for a custom editor features item.
     *
     * @since 2.1.1
     */
    function ajaxFeaturesRestrictCustomItem()
    {
        require_once (dirname(__FILE__) . '/features/config/custom-config.php');
        EditorFeaturesCustomConfig::addByAjax();
    }

    /**
     * Ajax callback to delete custom-added editor features item restriction.
     *
     * @since 2.1.1
     */
    function ajaxFeaturesClearCustomItem()
    {
        require_once (dirname(__FILE__) . '/features/config/custom-config.php');
        EditorFeaturesCustomConfig::deleteByAjax();
    }

    /**
     * Set admin menu and sub menu in 'adminmenu' to support custom menu and also get menu correct order
     * 
     * I initially set global item here but it has the following limitations:
     * - Restricted menu are not showing in 'Admin menu Restrictions' screen if admin restrict his role
     * - On the pp_capabilities_admin_menu_permission() function, custom menu are not available there
     * 
     * So, storing the data in adminmenu that has complete data is our best option so far.
     *
     * @since 2.3.1
     */
    function setCapabilitiesAdminMenu()
    {
        global $menu, $submenu, $ppc_global_menu, $ppc_global_submenu, $ppc_original_menu, $ppc_original_submenu;

        $ppc_global_menu    = $menu;
        $ppc_global_submenu = $submenu;

        // we only want to update complete menu and on capablities page where menu is not restricted
        if ( current_user_can('manage_capabilities_admin_menus') && isset($_GET['page']) && $_GET['page'] === 'pp-capabilities-admin-menus') 
        {
            // let try and use original menu if stored
            if (is_array($ppc_original_menu)) {
                $stored_menu = $ppc_original_menu;
            } else {
                $stored_menu = $menu;
            }
            if (is_array($ppc_original_submenu)) {
                $stored_submenu = $ppc_original_submenu;
            } else {
                $stored_submenu = $submenu;
            }

            if ( get_option('ppc_admin_menus_menu') !== $stored_menu) {//save menu
                update_option('ppc_admin_menus_menu', $stored_menu);
            }
            if ( get_option('ppc_admin_menus_submenu') !== $stored_submenu) {//save submenu
                update_option('ppc_admin_menus_submenu', $stored_submenu);
            }
        }
    }

    /**
     * Frontend features pages field
     *
     * @since 2.9.0
     */
    function frontendFeaturesPagesField()
    {
        $options = [
          'homepage'      => esc_html__('Homepage', 'capabilities-pro'),
          'archive_pages' => esc_html__('Archive Pages', 'capabilities-pro'),
          'single_pages'  => esc_html__('Single Pages', 'capabilities-pro')
        ];
        ?>
        <select class="frontend-element-new-element-pages chosen-cpt-select frontendelements-form-pages" data-placeholder="<?php esc_attr_e('Select pages...', 'capabilities-pro'); ?>" multiple>
            <?php foreach ($options as $value => $label) : ?>
                <option value="<?php echo esc_attr($value); ?>">
                    <?php echo esc_html($label); ?>
                </option>
            <?php endforeach; ?>
        </select>
        <br />
        <small>
            <?php esc_html_e('You can select page types where this element will be added.', 'capabilities-pro'); ?>
        </small>
    <?php 
    }

    /**
     * Frontend features post types field
     *
     * @since 2.9.0
     */
    function frontendFeaturesPostTypesField()
    { 
        ?>
        <select class="frontend-element-new-element-post-types chosen-cpt-select frontendelements-form-post-types"
            data-placeholder="<?php esc_attr_e('Select post types...', 'capabilities-pro'); ?>"
            multiple>
            <?php foreach (get_post_types(['public' => true], 'objects') as $name => $post_type) :
                if ($name === 'attachment') {
                    continue;
                } ?>
                <option
                    value="<?php echo esc_attr($name); ?>">
                    <?php echo esc_html($post_type->label); ?>
                </option>
            <?php endforeach; ?>
        </select>
        <br />
         <small>
            <?php esc_html_e('This will add a metabox on the post editing screen. You can use this feature to add body classes only for that post.', 'capabilities-pro'); ?>
        </small>
    <?php
    }

    /**
     * Ajax callback to update admin menu order
     *
     * @since 3.0.0
     */
    function ajaxUpdateAdminMenuOrder() 
    {
        $response['status']  = 'error';
        $response['message'] = __('An error occured!', 'capabilities-pro');
        $response['content'] = '';

        // Verify nonce
        if (empty($_POST['nonce']) || !wp_verify_nonce(sanitize_key($_POST['nonce']), 'ppc-pro-feature-nonce')) {
            $response['message'] =  __('Security check failed', 'capabilities-pro');
        } elseif (!current_user_can('manage_capabilities_admin_menus')) {
            $response['message'] =  __('Permission denied', 'capabilities-pro');
        } else {
            $menu_groups    = !empty($_POST['menu_groups']) ? map_deep($_POST['menu_groups'], 'sanitize_text_field') : '';

            if (empty($menu_groups)) {
                $response['message'] = __('Invalid data', 'capabilities-pro');
            } else {
                update_option('ppc_admin_menus_order', $menu_groups);
                $response['status']  = 'success';
                $response['message'] = __('Menu Order Updated.', 'capabilities-pro');
            }
        }

        wp_send_json($response);
    }

    /**
     * Customize admin menu order, names, new menu and parent relationships
     * 
     * @param string $submenu_file The parent file
     * 
     * @return string Modified parent file
     */
    public function customizeAdminMenu($submenu_file = '') {
        global $menu, $submenu, $ppc_original_menu, $ppc_original_submenu;

        // store original menu and submenu before customization
        if (!is_array($ppc_original_menu)) {
            $ppc_original_menu = $menu;
        }
        if (!is_array($ppc_original_submenu)) {
            $ppc_original_submenu = $submenu;
        }

        $user_roles = wp_get_current_user()->roles;

        // get menus for current role
        $role_menu = self::getRoleAdminMenu($menu, $submenu, $user_roles);
        
        // set menu and submenu for current role
        $menu       = $role_menu['menu'];
        $submenu    = $role_menu['submenu'];

        return $submenu_file;
    }

    public static function getRoleAdminMenu($menu, $submenu, $user_roles) {
        
        $enable_menu_renaming  = true;
        $enable_menu_reordering = true;


        if (isset($_GET['page']) && $_GET['page'] === 'pp-capabilities-admin-menus') {

            /**
             * Allow admin to disable menu renaming and reordering via URL parameters using ?disable_menu_renaming=true or ?disable_menu_reordering=true
             */
            if (isset($_GET['disable_menu_renaming']) && $_GET['disable_menu_renaming'] === 'true') {
                $enable_menu_renaming = false;
            }
            if (isset($_GET['disable_menu_reordering']) && $_GET['disable_menu_reordering'] === 'true') {
                $enable_menu_reordering = false;
            }
        }
        
        // Get stored menu settings
        $menu_order = get_option('ppc_admin_menus_order', []);
        $menu_names = get_option('ppc_admin_menus_names', []);


        foreach ($user_roles as $role) {
            // Apply custom menu names
            if (is_array($menu_names) && !empty($menu_names[$role]) && $enable_menu_renaming) {
                // Rename main menu items
                if (!empty($menu_names[$role]['menu'])) {
                    foreach ($menu as $priority => $menu_item) {
                        $menu_id = $menu_item[2] ?? '';
                        if ($menu_id && isset($menu_names[$role]['menu'][$menu_id])) {
                            // Update menu title
                            if (!empty($menu_names[$role]['menu'][$menu_id]['title'])) {
                                $old_name = $menu[$priority][0];
                                $menu[$priority][0] = $menu_names[$role]['menu'][$menu_id]['title'];
                                 // Consider menu with html like count etc in their name. 
                                 if (preg_match('/<[^>]+>/', $old_name)) {
                                    preg_match_all('/<[^>]+>.*?<\/[^>]+>/', $old_name, $htmlParts);
                                    $menu[$priority][0] .= ' ' . join('', $htmlParts[0]);
                                }
                            }
                            
                            // Update icon if set
                            if (!empty($menu_names[$role]['menu'][$menu_id]['icon'])) {
                                $menu[$priority][6] = $menu_names[$role]['menu'][$menu_id]['icon'];
                            }
                        }
                    }
                }

                // Rename submenu items
                if (!empty($menu_names[$role]['submenu'])) {
                    foreach ($submenu as $parent => $submenu_items) {
                        foreach ($submenu_items as $priority => $submenu_item) {
                            $submenu_id = $submenu_item[2] ?? '';
                            if ($submenu_id && isset($menu_names[$role]['submenu'][$submenu_id])) {
                                if (!empty($menu_names[$role]['submenu'][$submenu_id]['title'])) {
                                    $old_name = $submenu[$parent][$priority][0];
                                    $submenu[$parent][$priority][0] = $menu_names[$role]['submenu'][$submenu_id]['title'];
                                    // Consider menu with html like count etc in their name. 
                                    if (preg_match('/<[^>]+>/', $old_name)) {
                                       preg_match_all('/<[^>]+>.*?<\/[^>]+>/', $old_name, $htmlParts);
                                       $submenu[$parent][$priority][0] .= ' ' . join('', $htmlParts[0]);
                                   }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Apply menu ordering if defined
        if (is_array($menu_order) && !empty($menu_order) && $enable_menu_reordering) {
            $new_menu_order = [];
            $new_submenu_order = [];
            $moved_submenus = [];
            
            // Create lookup arrays for faster access of menu and submenu items by their ID
            $menu_lookup = array_column($menu, null, 2);
            $submenu_lookup = [];
            foreach ($submenu as $parent => $items) {
                foreach ($items as $priority => $item) {
                    $submenu_lookup[$item[2]] = [
                        'item' => $item,
                        'parent' => $parent,
                        'priority' => $priority
                    ];
                }
            }
            
            // Process main menu items and their submenus
            foreach (array_keys($menu_order) as $position => $menu_id) {
                if (is_array($menu_id)) {
                    // probably old format with roles
                    continue;
                }
                if (isset($menu_lookup[$menu_id])) {
                    $priority = array_search($menu_lookup[$menu_id], $menu);
                    $new_menu_order[$priority] = $menu_lookup[$menu_id];
                    $new_menu_order[$priority]['position'] = $position;
                    
                    // Process submenu items
                    if (isset($menu_order[$menu_id]) && is_array($menu_order[$menu_id])) {
                        $new_submenu_order[$menu_id] = [];
                        
                        foreach ($menu_order[$menu_id] as $sub_position => $submenu_id) {
                            if (isset($submenu_lookup[$submenu_id])) {
                                $submenu_info = $submenu_lookup[$submenu_id];
                                $new_priority = count($new_submenu_order[$menu_id]) + 1;
                                
                                // Store submenu item in new location
                                $new_submenu_order[$menu_id][$new_priority] = $submenu_info['item'];
                                $new_submenu_order[$menu_id][$new_priority]['position'] = $sub_position;
                                
                                // Track if item was moved from different parent
                                if ($submenu_info['parent'] !== $menu_id) {
                                    $moved_submenus[] = [
                                        'from' => $submenu_info['parent'],
                                        'item' => $submenu_id,
                                        'priority' => $submenu_info['priority']
                                    ];
                                }
                            }
                        }
                    }
                }
            }
            
            /**
             * Add remaining menus that aren't in the custom order and maintain their original position..
             * This is possible when new plugin is activated with new menu.
             */
            foreach ($menu_lookup as $menu_id => $menu_item) {
                $priority = array_search($menu_item, $menu);
                if ($priority !== false && !isset($new_menu_order[$priority])) {
                    $new_menu_order[$priority] = $menu_item;
                    $new_menu_order[$priority]['position'] = $priority;
                }
            }
            
            /**
             * Add remaining submenus that aren't in the custom order
             * and weren't moved to new parents
             */
            foreach ($submenu as $parent => $submenu_items) {
                if (!isset($new_submenu_order[$parent])) {
                    $new_submenu_order[$parent] = [];
                }
                
                foreach ($submenu_items as $priority => $submenu_item) {
                    $submenu_id = $submenu_item[2];
                    
                    // Skip if this submenu ID already exists in new_submenu_order for any parent
                    $already_exists = false;
                    foreach ($new_submenu_order as $p => $items) {
                        foreach ($items as $item) {
                            if ($item[2] === $submenu_id) {
                                $already_exists = true;
                                break 2;
                            }
                        }
                    }
                    
                    // Check if this submenu wasn't moved and doesn't already exist
                    if (!$already_exists) {
                        $was_moved = false;
                        foreach ($moved_submenus as $moved) {
                            if ($moved['item'] === $submenu_id) {
                                $was_moved = true;
                                break;
                            }
                        }
                        
                        // If submenu wasn't moved and isn't already in new order, add it
                        if (!$was_moved) {
                            $new_submenu_order[$parent][$priority] = $submenu_item;
                            $new_submenu_order[$parent][$priority]['position'] = $priority;
                        }
                    }
                }
            }
            
            // Sort menus by position
            if (!empty($new_menu_order)) {
                uasort($new_menu_order, fn($a, $b) => ($a['position'] ?? 9999) <=> ($b['position'] ?? 9999));
                $menu = array_values($new_menu_order);
            }
            
            // Sort and clean up submenus
            if (!empty($new_submenu_order)) {
                // Remove moved items from original locations
                foreach ($moved_submenus as $moved) {
                    unset($submenu[$moved['from']][$moved['priority']]);
                }
                
                // Sort and apply new submenu order
                foreach ($new_submenu_order as $parent => &$items) {
                    uasort($items, fn($a, $b) => ($a['position'] ?? 9999) <=> ($b['position'] ?? 9999));
                    $submenu[$parent] = array_values($items);
                }
            }
        }

        return ['menu' => $menu, 'submenu' => $submenu];
    }

    /**
     * Ajax handler for deleting menu items
     */
    public function ajaxDeleteAdminMenu() {
        
        $response['status']  = 'error';
        $response['message'] = __('An error occured!', 'capabilities-pro');
        $response['content'] = '';

        // Verify nonce and capabilities
        if (empty($_POST['nonce']) || !wp_verify_nonce(sanitize_key($_POST['nonce']), 'ppc-pro-feature-nonce')) {
            $response['message'] =  __('Security check failed', 'capabilities-pro');
        } elseif (!current_user_can('manage_capabilities_admin_menus')) {
            $response['message'] =  __('Permission denied', 'capabilities-pro');
        } else {
            $menu_type      = !empty($_POST['menu_type']) ? sanitize_text_field($_POST['menu_type']) : '';
            $menu_slug      = !empty($_POST['menu_slug']) ? sanitize_text_field($_POST['menu_slug']) : '';

            $custom_admin_menus = (array) get_option('ppc_admin_menus_custom_menus', []);
 
            if ($menu_type == 'menu') {
                if (array_key_exists($menu_slug, $custom_admin_menus['menus'])) {
                    unset($custom_admin_menus['menus'][$menu_slug]);
                }
            } else {
                if (array_key_exists($menu_slug, $custom_admin_menus['submenus'])) {
                    unset($custom_admin_menus['submenus'][$menu_slug]);
                }
            }

            // update new menu
            update_option('ppc_admin_menus_custom_menus', $custom_admin_menus);

            $response['status']  = 'success';
            $response['message'] = __('Menu deleted successfully.', 'capabilities-pro');
        }

        wp_send_json($response);
    }

    /**
     * Ajax handler for adding new menu items
     */
    public function ajaxAddNewAdminMenu() {
        
        $response['status']  = 'error';
        $response['message'] = __('An error occured!', 'capabilities-pro');
        $response['content'] = '';

        // Verify nonce and capabilities
        if (empty($_POST['nonce']) || !wp_verify_nonce(sanitize_key($_POST['nonce']), 'ppc-pro-feature-nonce')) {
            $response['message'] =  __('Security check failed', 'capabilities-pro');
        } elseif (!current_user_can('manage_capabilities_admin_menus')) {
            $response['message'] =  __('Permission denied', 'capabilities-pro');
        } else {
            $form_menu_type      = !empty($_POST['form_menu_type']) ? sanitize_text_field($_POST['form_menu_type']) : '';
            $menu_type   = !empty($_POST['menu_type']) ? sanitize_text_field($_POST['menu_type']) : '';
            $menu_position = !empty($_POST['menu_position']) ? sanitize_text_field($_POST['menu_position']) : '';
            $menu_position_after    = !empty($_POST['menu_position_after']) ? sanitize_text_field($_POST['menu_position_after']) : '';
            $menu_parent    = !empty($_POST['menu_parent']) ? sanitize_text_field($_POST['menu_parent']) : '';
            $menu_data        = !empty($_POST['menu_data']) ? map_deep($_POST['menu_data'], 'sanitize_text_field') : [];
            $menu_order        = !empty($_POST['menu_order']) ? map_deep($_POST['menu_order'], 'sanitize_text_field') : [];

            $custom_admin_menus = !empty(get_option('ppc_admin_menus_custom_menus')) ? (array) get_option('ppc_admin_menus_custom_menus', []) : [];
            
            $new_menu = [
                'form_menu_type' => $form_menu_type,
                'menu_type' => $menu_type,
                'menu_position' => $menu_position,
                'menu_position_after' => $menu_position_after,
                'menu_data' => $menu_data,
            ];

            if ($menu_type == 'menu') {
                $custom_admin_menus['menus'][$menu_data[2]] = $new_menu;
            } else {
                $new_menu['menu_parent'] = $menu_parent;
                $custom_admin_menus['submenus'][$menu_data[2]] = $new_menu;
            }

            // update new menu
            update_option('ppc_admin_menus_custom_menus', $custom_admin_menus);

            // update menu order
            update_option('ppc_admin_menus_order', $menu_order);

            $response['status']  = 'success';
            $response['redirect']  = admin_url('admin.php?page=pp-capabilities-admin-menus');
            $response['message'] = __('New menu added successfully. Reloading page...', 'capabilities-pro');
        }

        wp_send_json($response);
    }

    /**
     * Ajax handler for renaming menu items
     */
    public function ajaxUpdateAdminMenuTitle() {
        $response['status']  = 'error';
        $response['message'] = __('An error occured!', 'capabilities-pro');
        $response['content'] = '';

        // Verify nonce and capabilities
        if (empty($_POST['nonce']) || !wp_verify_nonce(sanitize_key($_POST['nonce']), 'ppc-pro-feature-nonce')) {
            $response['message'] =  __('Security check failed', 'capabilities-pro');
        } elseif (!current_user_can('manage_capabilities_admin_menus')) {
            $response['message'] =  __('Permission denied', 'capabilities-pro');
        } else {
            $menu_id      = !empty($_POST['menu_id']) ? sanitize_text_field($_POST['menu_id']) : '';
            $menu_title   = !empty($_POST['menu_title']) ? sanitize_text_field($_POST['menu_title']) : '';
            $current_role = !empty($_POST['current_role']) ? sanitize_text_field($_POST['current_role']) : '';
            $menu_type    = !empty($_POST['menu_type']) ? sanitize_text_field($_POST['menu_type']) : '';
            $menu_icon    = !empty($_POST['menu_icon']) ? sanitize_text_field($_POST['menu_icon']) : '';
            $scope        = !empty($_POST['scope']) ? sanitize_text_field($_POST['scope']) : 'role';

            if (empty($menu_id) || empty($menu_title)) {
                $response['message'] = __('Invalid data', 'capabilities-pro');
            } else {
                $admin_menus_names = !empty(get_option('ppc_admin_menus_names')) ? (array) get_option('ppc_admin_menus_names', []) : [];
                
                if ($scope === 'all') {
                    // Apply to all roles
                    foreach (wp_roles()->roles as $role_name => $role_info) {
                        self::updateMenuAndSubmenuNames($admin_menus_names, $role_name, $menu_id, $menu_type, $menu_title, $menu_icon);
                    }
                    $response['message'] = __('Menu Name Updated for all roles.', 'capabilities-pro');
                } else {
                    // Apply to current role only
                    self::updateMenuAndSubmenuNames($admin_menus_names, $current_role, $menu_id, $menu_type, $menu_title, $menu_icon);
                    $response['message'] = __('Menu Name Updated.', 'capabilities-pro');
                }

                update_option('ppc_admin_menus_names', $admin_menus_names);

                $response['menu_title'] = $menu_title;
                $response['status']  = 'success';
                $response['message'] = __('Menu Name Updated.', 'capabilities-pro');
            }
        }

        wp_send_json($response);
    }

    /**
     * Helper function to update both menu and submenu names
     */
    private static function updateMenuAndSubmenuNames(&$admin_menus_names, $role, $menu_id, $menu_type, $menu_title, $menu_icon) {
        // Initialize arrays if they don't exist
        if (!isset($admin_menus_names[$role])) {
            $admin_menus_names[$role] = ['menu' => [], 'submenu' => []];
        }
        if (!isset($admin_menus_names[$role]['menu'])) {
            $admin_menus_names[$role]['menu'] = [];
        }
        if (!isset($admin_menus_names[$role]['submenu'])) {
            $admin_menus_names[$role]['submenu'] = [];
        }

        // Update both menu and submenu entries with the same ID
        if ($menu_type === 'menu') {
            $admin_menus_names[$role]['menu'][$menu_id] = ['title' => $menu_title, 'icon' => $menu_icon];
        } else {
            $admin_menus_names[$role]['submenu'][$menu_id] = ['title' => $menu_title];
        }
    }

    public function addCustomMenu() {
        global $menu, $submenu, $ppc_original_menu, $ppc_original_submenu;
        $custom_menus = get_option('ppc_admin_menus_custom_menus', []);

        if (!empty($custom_menus['menus'])) {
            foreach ($custom_menus['menus'] as $menu_id => $menu_data) {
                $menu_icon = isset($menu_data['menu_data'][6]) ? $menu_data['menu_data'][6] : '';
                ppc_add_menu_page(
                    $menu_data['menu_data'][0],
                    $menu_data['menu_data'][0],
                    $menu_data['menu_data'][1],
                    $menu_data['menu_data'][2],
                    '',
                    $menu_icon,
                    $menu_data['menu_position'],
                    $menu_data
                );
            }
        }

        if (!empty($custom_menus['submenus'])) {
            foreach ($custom_menus['submenus'] as $submenu_id => $submenu_data) {
                ppc_add_submenu_page(
                    $submenu_data['menu_parent'],
                    $submenu_data['menu_data'][0],
                    $submenu_data['menu_data'][0],
                    $submenu_data['menu_data'][1],
                    $submenu_id,
                    '',
                    $submenu_data['menu_position'],
                    $submenu_data
                );
            }
        }

        /**
         * I need original menu with their registered position
         * number and was able to get it here.
         */
        if (!is_array($ppc_original_menu)) {
            $ppc_original_menu = $menu;
        }
        if (!is_array($ppc_original_submenu)) {
            $ppc_original_submenu = $submenu;
        }
    }
}