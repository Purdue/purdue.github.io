<?php
/*
 * PublishPress Capabilities Pro
 *
 * Pro admin functions with broad scope, which are not contained within a class
 */

add_action('admin_menu', 'pp_capabilities_admin_menu_permission', 999);

add_filter('pp_capabilities_backup_sections', 'pp_capabilities_pro_backup_sections');
add_action('pp_capabilities_after_role_copied', 'pp_capabilities_pro_after_role_copied', 10, 2);

require_once (dirname(__FILE__) . '/features/custom.php');
\PublishPress\Capabilities\EditorFeaturesCustom::instance();

require_once (dirname(__FILE__) . '/features/metaboxes.php');
\PublishPress\Capabilities\EditorFeaturesMetaboxes::instance();

//admin features css hide integration
require_once (dirname(__FILE__) . '/features/admin-features-css-hide.php');
\PublishPress\Capabilities\AdminFeaturesCssHide::instance();

//admin features block url integration
require_once (dirname(__FILE__) . '/features/admin-features-block-url.php');
\PublishPress\Capabilities\AdminFeaturesBlockUrl::instance();


function pp_capabilities_pro_backup_sections($backup_sections){

    //Admin Features Pro
    $backup_sections['capsman_admin_features_backup']['options'][] = 'ppc_admin_feature_block_url_custom_data';
    $backup_sections['capsman_admin_features_backup']['options'][] = 'ppc_admin_feature_css_hide_custom_data';

    //Editor Features Pro
    $backup_sections['capsman_editor_features_backup']['options'][] = 'ppc_feature_post_gutenberg_custom_data';
    $backup_sections['capsman_editor_features_backup']['options'][] = 'ppc_feature_post_classic_custom_data';

    //Admin Menu
    $admin_menu_options = ['capsman_admin_menus', 'capsman_admin_child_menus', 'ppc_admin_menus_order', 'ppc_admin_menus_names', 'ppc_admin_menus_custom_menus'];
    $backup_sections['capsman_admin_menu_backup']['label'] = esc_html__('Admin Menu', 'capabilities-pro');
    foreach($admin_menu_options as $admin_menu_option){
        $backup_sections['capsman_admin_menu_backup']['options'][] = $admin_menu_option;
    }
    

    return $backup_sections;
}

function pp_capabilities_pro_after_role_copied($role_slug, $copied_role) {

    //Copy Admin Menu
    $admin_menu_option = !empty(get_option('capsman_admin_menus')) ? get_option('capsman_admin_menus') : [];
    if (is_array($admin_menu_option) && array_key_exists($copied_role, $admin_menu_option)) {
        $admin_menu_option[$role_slug] = $admin_menu_option[$copied_role];
        update_option('capsman_admin_menus', $admin_menu_option, false);
    }
    $admin_child_menu_option = !empty(get_option('capsman_admin_child_menus')) ? get_option('capsman_admin_child_menus') : [];
    if (is_array($admin_child_menu_option) && array_key_exists($copied_role, $admin_child_menu_option)) {
        $admin_child_menu_option[$role_slug] = $admin_child_menu_option[$copied_role];
        update_option('capsman_admin_child_menus', $admin_child_menu_option, false);
    }
    $admin_menus_names_option = !empty(get_option('ppc_admin_menus_names')) ? get_option('ppc_admin_menus_names') : [];
    if (is_array($admin_menus_names_option) && array_key_exists($copied_role, $admin_menus_names_option)) {
        $admin_menus_names_option[$role_slug] = $admin_menus_names_option[$copied_role];
        update_option('ppc_admin_menus_names', $admin_menus_names_option, false);
    }
}

function pp_capabilities_admin_menu_permission()
{
    global $menu, $submenu;
    global $admin_global_menu, $admin_global_submenu;

    if (is_multisite() && is_super_admin() && !defined('PP_CAPABILITIES_RESTRICT_SUPER_ADMIN')) {
        return;
    }

    if (!pp_capabilities_feature_enabled('admin-menus')) {
        return;
    }

    $ppc_global_menu     = (array)get_option('ppc_admin_menus_menu');
    $ppc_global_submenu  = (array)get_option('ppc_admin_menus_submenu');

    //let add a fallback value just incase
    if(!empty($ppc_global_menu)){
        $admin_global_menu = $ppc_global_menu;
    }else{
        $admin_global_menu 	  = (array)$GLOBALS['menu'];
    }
    if(!empty($ppc_global_submenu)){
        $admin_global_submenu = $ppc_global_submenu;
    }else{
        $admin_global_submenu = (array)$GLOBALS['submenu'];
    }

    /**
     * We need to use global menu when not on capabilities 
     * admin menu page to have current role(e.g author) menus 
     * instead of saved menu which could be for administrator role.
     */
    if (!isset($_GET['page']) || (isset($_GET['page']) && $_GET['page'] !== 'pp-capabilities-admin-menus')) {
        $admin_global_menu    = (array)$GLOBALS['menu'];
        $admin_global_submenu = (array)$GLOBALS['submenu'];
    }
    

    if (is_object($admin_global_submenu)) {
        $admin_global_submenu = get_object_vars($admin_global_submenu);
    }

    if (!isset($admin_global_menu) || empty($admin_global_menu)) {
        $admin_global_menu = $menu;
    }

    if (!isset($admin_global_submenu) || empty($admin_global_submenu)) {
        $admin_global_submenu = $submenu;
    }

    //return if not admin page
    if (!is_admin()) {
        return;
    }

    //return if it's ajax request
    if (defined('DOING_AJAX') && DOING_AJAX) {
        return;
    }

    $remove_menu = true;
    //We need to exclude restriction on Admin Menu Restrictions and use css instead due to new ways of getting menus to support custom menus
    if (isset($_GET['page']) && $_GET['page'] === 'pp-capabilities-admin-menus') {
        $remove_menu = false;
    }

    $disabled_menu 		 	 = '';
    $disabled_child_menu 	 = '';
    $user_roles			 	 = wp_get_current_user()->roles;

    // Support plugin integrations by allowing additional role-based limitations to be applied to user based on external criteria
    $user_roles = apply_filters('pp_capabilities_admin_menu_apply_role_restrictions', $user_roles, compact('menu', 'submenu'));

    $admin_menu_option = !empty(get_option('capsman_admin_menus')) 
    ? array_intersect_key((array)get_option('capsman_admin_menus'), array_fill_keys($user_roles, true)) : [];

    $admin_child_menu_option = !empty(get_option('capsman_admin_child_menus')) 
    ? array_intersect_key((array)get_option('capsman_admin_child_menus'), array_fill_keys($user_roles, true)) : [];

    /* 
     * PublishPress Permissions: Restrict Nav Menus for a Permission Group
     * (Integrate PublishPress Capabilities Pro functionality).
     *
     * Copy into functions.php, modifying $restriction_role and $permission_group_ids to match your usage.
     *
     * note: Restriction_role can be an extra role that you create just for these menu restrictions.
     *       Configure Capabilities > Nav Menus as desired for that role.
     */
    /*
    add_filter('pp_capabilities_admin_menu_apply_role_restrictions', 
        function($roles) {
            if (function_exists('presspermit')) {
                $permission_group_ids = [12, 14, 15];   // group IDs to restrict
                $restriction_role = 'subscriber';       // role that has restrictions defined by Capabilities > Nav Menus

                if (array_intersect(
                    array_keys(presspermit()->getUser()->groups['pp_group']), 
                    $permission_group_ids
                )) {
                    $roles []= $restriction_role;
                }
            }

            return $roles;
        }
    );
    */

    //extract disabled menu for roles user belong
    $disabled_menu_array = [];
    $disabled_child_menu_array = [];

    foreach ($admin_menu_option as $disabled_menus) {
        $disabled_menu_array = array_merge($disabled_menu_array, (array) $disabled_menus);
    }

    foreach ($admin_child_menu_option as $disabled_menus) {
        $disabled_child_menu_array = array_merge($disabled_child_menu_array, (array) $disabled_menus);
    }

    // Case of multiple user roles: If restriction priority is disabled, don't prevent access if any user role is unrestricted 
    if (count($user_roles) > 1 && !get_option('cme_admin_menus_restriction_priority', 1)) {
        foreach ($disabled_menu_array as $disabled_menu) {
            foreach ($user_roles as $role) {
                if (empty($admin_menu_option[$role]) || (!in_array($disabled_menu, $admin_menu_option[$role]))) {
                    $disabled_menu_array = array_diff($disabled_menu_array, (array) $disabled_menu);
                    continue 2;
                }
            }
        }

        foreach ($disabled_child_menu_array as $disabled_menu) {
            foreach ($user_roles as $role) {
                if (empty($admin_child_menu_option[$role]) || (!in_array($disabled_menu, $admin_child_menu_option[$role]))) {
                    $disabled_child_menu_array = array_diff($disabled_child_menu_array, (array) $disabled_menu);
                    continue 2;
                }
            }
        }
    }

    // if users.php menu is disabled, also disable profile.php
    if (in_array('users.php', $disabled_menu_array)) {
        $disabled_menu_array []= 'profile.php';
    }

    // Include yoast seo menu and submenu for all slug
    if (in_array('wpseo_dashboard', $disabled_menu_array)) {
        $disabled_menu_array []= 'wpseo_workouts';
    }

    // deal with discrepancy between users.php > profile.php submenu location stored by Administrator vs. profile.php > profile.php loaded by limited users
    if (in_array('users.php15', $disabled_child_menu_array)) {
        if (empty($admin_global_submenu['users.php']) || empty($admin_global_submenu['users.php'][15])) {
            $disabled_child_menu_array[]= 'profile.php5';
        }
    }

    global $removed_menu_items, $removed_submenu_items;
    $removed_menu_items      = [];
    $removed_submenu_items   = [];
    foreach ($admin_global_menu as $key => $item) {
        if (isset($item[2])) {
            $menu_slug = $item[2];
            $manage_capabilities_menu = (in_array($menu_slug, ['pp-capabilities-roles', 'pp-capabilities-dashboard']) && (current_user_can('manage_capabilities') || current_user_can('manage_capabilities_admin_menus'))) ? true : false;
 
            //remove menu and prevent page access if set
            if (!$manage_capabilities_menu && in_array($menu_slug, $disabled_menu_array)) {
                if($remove_menu){
                    remove_menu_page($menu_slug);
                }
                pp_capabilities_admin_menu_access($menu_slug);
                $removed_menu_items []= $menu_slug;
                unset($submenu[$menu_slug]);
            }

            $check_slugs = [$menu_slug];
            if ('users.php' == $menu_slug) {
                $check_slugs []= 'profile.php';
            }

            foreach($check_slugs as $menu_slug) {
                //remove menu and prevent page access if set
                if (isset($admin_global_submenu) && !empty($admin_global_submenu[$menu_slug])) {
                    foreach ($admin_global_submenu[$menu_slug] as $subindex => $subitem) {
                        $sub_menu_value = $menu_slug . $subindex;

                        if (in_array($sub_menu_value, $disabled_child_menu_array)) {
                            if (isset($subitem[2])) {
                                if($remove_menu){
                                    remove_submenu_page($menu_slug, $subitem[2]);

                                    if (in_array(strtolower($subitem[1]), ['customize', 'customizer']) && !empty($_SERVER['REQUEST_URI'])) {
                                        /**
                                         * To use remove_submenu_page to remove theme customizer, 
                                         * the url must match what is being exactly linked in the 
                                         * admin for that function to work.
                                         * 
                                         * See related issue: https://github.com/publishpress/PublishPress-Capabilities/issues/290
                                         */
                                        remove_submenu_page( $menu_slug, 'customize.php?return=' . urlencode(esc_url_raw($_SERVER['REQUEST_URI'])));
                                    }
                                }
                                pp_capabilities_admin_menu_access($subitem[2]);
                                $removed_submenu_items[$menu_slug] = $subitem[2];
                            }
                            unset($menu[$menu_slug]);
                        }
                    }
                }
            }
        }

        /**
         * We need to force JavaScript removal of all menus for 
         * some custom menu coming from Menu Editor plugin that's not 
         * available in global
         */
        $removed_menu_items = $disabled_menu_array;
    }
    
    /**
     * due to conflict with custom menu which makes this function run earlier, 
     * we need to provide an additional measure to remove custom menus just 
     * incase they're added late. This is only UI related as 
     * pp_capabilities_admin_menu_access() will always block access to the 
     * page irrespective of then they added the menu
     *
     * @since 2.3.1
     */
     add_action('admin_footer', 'pp_capabilities_admin_menu_script');
}

function pp_capabilities_admin_menu_script(){
    global $removed_menu_items, $removed_submenu_items;
    ?>
    <script type="text/javascript">
     (function ($) {
        $(document).ready(function ($) {
            <?php 
            foreach($removed_menu_items as $menu_slug) {
                
                /**
                 * Note, we cannot escape these slug using 
                 * esc_url or esc_url_raw as it's adding 
                 * http to url thereby causing functionalilty issue.
                 */
                echo "$(\"#adminmenu li a[href='" . esc_attr($menu_slug) . "']\").closest('li').remove(); ";
                //plugins that has admin.php as slugs doesn't include whole url
                echo "$(\"#adminmenu li a[href='" . 'admin.php?page=' . esc_attr($menu_slug) . "']\").closest('li').remove(); ";
                //some plugins add fake slugs as placeholder
                echo "$(\"#adminmenu li a[href='" . '/admin/' . esc_attr($menu_slug) . "']\").closest('li').remove(); ";
            }

            foreach($removed_submenu_items as $menu_slug => $submenu_url) {
                echo "$(\"#adminmenu li a[href='" . esc_url_raw($menu_slug) . "']\").closest('li').find(\"ul li a[href='" . esc_url_raw($submenu_url) . "']\").closest('li').remove(); ";
            }
            ?>
        })
    })(jQuery)
    </script> 
    <?php     
}

function pp_capabilities_admin_menu_access($slug)
{
    $url = (isset($_SERVER['REQUEST_URI'])) ? esc_url_raw($_SERVER['REQUEST_URI']) : '';
    $url = basename($url);
    $url = htmlspecialchars($url);

    if (is_multisite() && is_super_admin() && !defined('PP_CAPABILITIES_RESTRICT_SUPER_ADMIN')) {
        return true;
    }

    if (!isset($url)) {
        return false;
    }

    $uri = wp_parse_url($url);

    if (!isset($uri['path'])) {
        return false;
    }

    if (!isset($uri['query']) && strpos($uri['path'], $slug) !== false) {
        add_action('load-' . $slug, 'pp_capabilities_admin_menu_access_denied');
        return true;
    }

    if ($slug === $url || ($uri['path'] === 'customize.php' && strpos($slug, $uri['path']) !== false)) {
        add_action('load-' . basename($uri['path']), 'pp_capabilities_admin_menu_access_denied');
        return true;
    }

    if ($url == "admin.php?page=$slug") {
        pp_capabilities_admin_menu_access_denied();
    }
}

function pp_capabilities_admin_menu_access_denied()
{
    $forbidden = esc_attr__('You do not have permission to access this page.', 'capabilities-pro');
    wp_die(esc_html($forbidden));
}

function ppc_process_admin_menu_title($title)
{
    if (!empty($title)) {
        // Match and replace nested HTML tags and their entire content
        $title = preg_replace('/<[^>]+>.*?<\/[^>]+>/s', '', $title);
        $title = preg_replace('/<[^>]+>/s', '', $title); // Remove orphan tags if any
    }

    return $title;
}

/**
 * Clone copy of WordPress add_menu_page with support for capabilities separator and class
 * 
 * Adds a top-level menu page.
 *
 * This function takes a capability which will be used to determine whether
 * or not a page is included in the menu.
 *
 * The function which is hooked in to handle the output of the page must check
 * that the user has the required capability as well.
 *
 * @since 1.5.0
 *
 * @global array $menu
 * @global array $admin_page_hooks
 * @global array $_registered_pages
 * @global array $_parent_pages
 *
 * @param string    $page_title The text to be displayed in the title tags of the page when the menu is selected.
 * @param string    $menu_title The text to be used for the menu.
 * @param string    $capability The capability required for this menu to be displayed to the user.
 * @param string    $menu_slug  The slug name to refer to this menu by. Should be unique for this menu page and only
 *                              include lowercase alphanumeric, dashes, and underscores characters to be compatible
 *                              with sanitize_key().
 * @param callable  $callback   Optional. The function to be called to output the content for this page.
 * @param string    $icon_url   Optional. The URL to the icon to be used for this menu.
 *                              * Pass a base64-encoded SVG using a data URI, which will be colored to match
 *                                the color scheme. This should begin with 'data:image/svg+xml;base64,'.
 *                              * Pass the name of a Dashicons helper class to use a font icon,
 *                                e.g. 'dashicons-chart-pie'.
 *                              * Pass 'none' to leave div.wp-menu-image empty so an icon can be added via CSS.
 * @param int|float $position   Optional. The position in the menu order this item should appear.
 * @param array $menu_data original menu data from form (Added by Capabilities)
 * @return string The resulting page's hook_suffix.
 */
function ppc_add_menu_page( $page_title, $menu_title, $capability, $menu_slug, $callback = '', $icon_url = '', $position = null, $menu_data = [] ) {
	global $menu, $admin_page_hooks, $_registered_pages, $_parent_pages;

	$menu_slug = plugin_basename( $menu_slug );

	$admin_page_hooks[ $menu_slug ] = sanitize_title( $menu_title );

	$hookname = get_plugin_page_hookname( $menu_slug, '' );

	if ( ! empty( $callback ) && ! empty( $hookname ) && current_user_can( $capability ) ) {
		add_action( $hookname, $callback );
	}

	if ( empty( $icon_url ) ) {
		$icon_url   = 'dashicons-admin-generic';
		$icon_class = 'menu-icon-generic ';
	} else {
		$icon_url   = set_url_scheme( $icon_url );
		$icon_class = '';
	}

    if (!empty($menu_data['form_menu_type']) && $menu_data['form_menu_type'] == 'menu-separator') {
	    $new_menu = array( '', $capability, $menu_slug, '', $menu_data['menu_data'][4], $icon_url );
    } else {
	    $new_menu = array( $menu_title, $capability, $menu_slug, $page_title, 'menu-top ' . $icon_class . $hookname, $hookname, $icon_url );
    }

	if ( null !== $position && ! is_numeric( $position ) ) {
		_doing_it_wrong(
			__FUNCTION__,
			sprintf(
				/* translators: %s: add_menu_page() */
				__( 'The seventh parameter passed to %s should be numeric representing menu position.' ),
				'<code>add_menu_page()</code>'
			),
			'6.0.0'
		);
		$position = null;
	}

	if ( null === $position || ! is_numeric( $position ) ) {
		$menu[] = $new_menu;
	} elseif ( isset( $menu[ (string) $position ] ) ) {
		$collision_avoider = base_convert( substr( md5( $menu_slug . $menu_title ), -4 ), 16, 10 ) * 0.00001;
		$position          = (string) ( $position + $collision_avoider );
		$menu[ $position ] = $new_menu;
	} else {
		/*
		 * Cast menu position to a string.
		 *
		 * This allows for floats to be passed as the position. PHP will normally cast a float to an
		 * integer value, this ensures the float retains its mantissa (positive fractional part).
		 *
		 * A string containing an integer value, eg "10", is treated as a numeric index.
		 */
		$position          = (string) $position;
		$menu[ $position ] = $new_menu;
	}

	$_registered_pages[ $hookname ] = true;

	// No parent as top level.
	$_parent_pages[ $menu_slug ] = false;

	return $hookname;
}

/**
 * Clone copy of WordPress add_submenu_page with support for capabilities separator and class
 * 
 * Adds a submenu page.
 *
 * This function takes a capability which will be used to determine whether
 * or not a page is included in the menu.
 *
 * The function which is hooked in to handle the output of the page must check
 * that the user has the required capability as well.
 *
 * @since 1.5.0
 * @since 5.3.0 Added the `$position` parameter.
 *
 * @global array $submenu
 * @global array $menu
 * @global array $_wp_real_parent_file
 * @global bool  $_wp_submenu_nopriv
 * @global array $_registered_pages
 * @global array $_parent_pages
 *
 * @param string    $parent_slug The slug name for the parent menu (or the file name of a standard
 *                               WordPress admin page).
 * @param string    $page_title  The text to be displayed in the title tags of the page when the menu
 *                               is selected.
 * @param string    $menu_title  The text to be used for the menu.
 * @param string    $capability  The capability required for this menu to be displayed to the user.
 * @param string    $menu_slug   The slug name to refer to this menu by. Should be unique for this menu
 *                               and only include lowercase alphanumeric, dashes, and underscores characters
 *                               to be compatible with sanitize_key().
 * @param callable  $callback    Optional. The function to be called to output the content for this page.
 * @param int|float $position    Optional. The position in the menu order this item should appear.
 * @param array $submenu_data original sub menu data from form (Added by Capabilities)
 * @return string|false The resulting page's hook_suffix, or false if the user does not have the capability required.
 */
function ppc_add_submenu_page( $parent_slug, $page_title, $menu_title, $capability, $menu_slug, $callback = '', $position = null, $submenu_data = [] ) {
	global $submenu, $menu, $_wp_real_parent_file, $_wp_submenu_nopriv,
		$_registered_pages, $_parent_pages;

	$menu_slug   = plugin_basename( $menu_slug );
	$parent_slug = plugin_basename( $parent_slug );

	if ( isset( $_wp_real_parent_file[ $parent_slug ] ) ) {
		$parent_slug = $_wp_real_parent_file[ $parent_slug ];
	}

	if ( ! current_user_can( $capability ) ) {
		$_wp_submenu_nopriv[ $parent_slug ][ $menu_slug ] = true;
		return false;
	}

	/*
	 * If the parent doesn't already have a submenu, add a link to the parent
	 * as the first item in the submenu. If the submenu file is the same as the
	 * parent file someone is trying to link back to the parent manually. In
	 * this case, don't automatically add a link back to avoid duplication.
	 */
	if ( ! isset( $submenu[ $parent_slug ] ) && $menu_slug !== $parent_slug ) {
		foreach ( (array) $menu as $parent_menu ) {
			if ( $parent_menu[2] === $parent_slug && current_user_can( $parent_menu[1] ) ) {
				$submenu[ $parent_slug ][] = array_slice( $parent_menu, 0, 4 );
			}
		}
	}


    if (!empty($submenu_data['form_menu_type']) && $submenu_data['form_menu_type'] == 'submenu-separator') {
	    $new_sub_menu = array( '', $capability, $menu_slug, '', $submenu_data['menu_data'][4] );
    } else {
	    $new_sub_menu = array( $menu_title, $capability, $menu_slug, $page_title );
    }

	if ( null !== $position && ! is_numeric( $position ) ) {
		_doing_it_wrong(
			__FUNCTION__,
			sprintf(
				/* translators: %s: add_submenu_page() */
				__( 'The seventh parameter passed to %s should be numeric representing menu position.' ),
				'<code>add_submenu_page()</code>'
			),
			'5.3.0'
		);
		$position = null;
	}

	if (
		null === $position ||
		( ! isset( $submenu[ $parent_slug ] ) || $position >= count( $submenu[ $parent_slug ] ) )
	) {
		$submenu[ $parent_slug ][] = $new_sub_menu;
	} else {
		// Test for a negative position.
		$position = max( $position, 0 );
		if ( 0 === $position ) {
			// For negative or `0` positions, prepend the submenu.
			array_unshift( $submenu[ $parent_slug ], $new_sub_menu );
		} else {
			$position = absint( $position );
			// Grab all of the items before the insertion point.
			$before_items = array_slice( $submenu[ $parent_slug ], 0, $position, true );
			// Grab all of the items after the insertion point.
			$after_items = array_slice( $submenu[ $parent_slug ], $position, null, true );
			// Add the new item.
			$before_items[] = $new_sub_menu;
			// Merge the items.
			$submenu[ $parent_slug ] = array_merge( $before_items, $after_items );
		}
	}

	// Sort the parent array.
	ksort( $submenu[ $parent_slug ] );

	$hookname = get_plugin_page_hookname( $menu_slug, $parent_slug );
	if ( ! empty( $callback ) && ! empty( $hookname ) ) {
		add_action( $hookname, $callback );
	}

	$_registered_pages[ $hookname ] = true;

	/*
	 * Backward-compatibility for plugins using add_management_page().
	 * See wp-admin/admin.php for redirect from edit.php to tools.php.
	 */
	if ( 'tools.php' === $parent_slug ) {
		$_registered_pages[ get_plugin_page_hookname( $menu_slug, 'edit.php' ) ] = true;
	}

	// No parent as top level.
	$_parent_pages[ $menu_slug ] = $parent_slug;

	return $hookname;
}

